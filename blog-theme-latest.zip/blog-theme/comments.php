<?php
/**
 * The template for displaying comments
 *
 * The area of the page that contains both current comments
 * and the comment form.
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */

/*
 * If the current post is protected by a password and
 * the visitor has not yet entered the password we will
 * return early without loading the comments.
 */
if ( post_password_required() ) {
	return;
}
?>
	<div class="comments-form">
            <div id="respond" class="comment-respond">
		<?php if ( have_comments() ) : ?>
                <h3 class="comments-title">
                    <?php
                        printf( _nx( 'Comment (%1$s)', 'Comments (%1$s)', get_comments_number(), 'comments title', 'osum' ),
                            number_format_i18n( get_comments_number() ), get_the_title() );
                    ?>
                </h3>
                <ol class="comment-list">
                    <?php
                        wp_list_comments( array(
                            'type'      	=> 'comment',
                            'avatar_size'	=> 120,
                            'callback'		=> 'osum_comment',
							
                        ) );
                    ?>
                </ol><!-- .comment-list -->
            <?php osum_comment_nav(); ?>
        <?php else:
			echo '<h2>'.__('No Comments','osum').'</h2>';
		endif; // have_comments() ?>
        <?php
            // If comments are closed and there are comments, let's leave a little note, shall we?
            if ( ! comments_open() && get_comments_number() && post_type_supports( get_post_type(), 'comments' ) ) :
        ?>
            <p class="no-comments"><?php _e( 'Comments are closed.', 'osum' ); ?></p>
        <?php endif; ?>
            		</div>

<div class="comments-form">
			<?php
			$commenter = wp_get_current_commenter();
				$req = get_option( 'require_name_email' );
				$aria_req = ( $req ? " aria-required='true'" : '' );
				$required_fields_mark = ' ' .__('Required fields are marked %s', 'osum');
            	$required_text = sprintf($required_fields_mark , '<span class="required">*</span>' );
				$fields =  array(
					'author' 	=>	'<p class="comment-form-author">
										<input id="author" name="author" type="text" placeholder="'.__( 'Name', 'osum' ).'" 
										value="' . esc_attr( $commenter['comment_author'] ) .'" size="30"' . $aria_req . ' />
									</p>',
				  	'email' 	=>	'<p class="comment-form-email">
										<input id="email" name="email" type="text"  placeholder="'.__( 'Email', 'osum' ).'"	
										value="' . esc_attr(  $commenter['comment_author_email'] ) .'" size="30"' . $aria_req . ' />
									</p>',

								);
				$args = array(
				'fields' => apply_filters( 'comment_form_default_fields', $fields ),

				  'id_form'           => 'commentform',
				  'id_submit'         => 'submit',
				  'class_submit'      => 'submit',
				  'name_submit'       => 'submit',
				  'title_reply'       => __( 'Leave a Reply','osum' ),
				  'title_reply_to'    => __( 'Leave a Reply to %s','osum' ),
				  'cancel_reply_link' => __( 'Cancel Reply','osum' ),
				  'label_submit'      => __( 'Submit Now','osum' ),
				  'format'            => 'xhtml',
				
					'comment_field'	=>  '<p class="comment-form-comment">
											<textarea id="comment" name="comment" cols="45" rows="8" aria-required="true" 
												placeholder="'.__( 'Type your message here', 'osum' ).'">' .'</textarea>
										</p>',				
				  'must_log_in' 	=> '<p class="must-log-in">' .
					sprintf(
					  __( 'You must be <a href="%s">logged in</a> to post a comment.','osum' ),
					  wp_login_url( apply_filters( 'the_permalink', get_permalink() ) )
					) . '</p>',
				
				  'logged_in_as' => '<p class="logged-in-as">' .
					sprintf(
					__( 'Logged in as <a href="%1$s">%2$s</a>. <a href="%3$s" title="Log out of this account">Log out?</a>','osum' ),
					  admin_url( 'profile.php' ),
					  $user_identity,
					  wp_logout_url( apply_filters( 'the_permalink', get_permalink( ) ) )
					) . '</p>',
				
				  'comment_notes_before' => '',
				
				  'comment_notes_after' => '',
				
				);
 			 	comment_form($args);
 			 ?>
</div>
</div>