<?php
/**
 * The template for displaying archive pages
 *
 * Used to display archive-type pages if nothing more specific matches a query.
 * For example, puts together date-based pages if no date.php file exists.
 *
 * If you'd like to further customize these archive views, you may create a
 * new template file for each one. For example, tag.php (Tag archives),
 * category.php (Category archives), author.php (Author archives), etc.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */

get_header(); 

global $osum_options;

	$osum_layout = isset($osum_options['sidebar_layout']) ? $osum_options['sidebar_layout'] : 'full_width';
	$osum_sidebar  = isset($osum_options['sidebar'])? $osum_options['sidebar'] : '';
	$oms_layout_cls	= ($osum_layout == 'full_width') ? 'fw-col-md-12' : 'fw-col-md-8';
    //$oms_layout  = isset($post_metadata['osum_sidebar_layout'])? $post_metadata['osum_sidebar_layout'] : 'full_width';
    //$oms_layout_cls = ($oms_layout == 'full_width') ? 'fw-col-lg-12 fw-col-md-12 fw-col-sm-12 fw-col-xs-12' : 'fw-col-lg-8 fw-col-md-8 fw-col-sm-8 fw-col-xs-12';

    $category_posts  = isset($osum_options['category_posts'])? $osum_options['category_posts'] : '';

/* if( $category_posts == 'true'):
    $query = array( 'post_type' => 'post','posts_per_page' => 2 );
    $osm_query = new WP_Query( $query );
?>
    <div class="recent-posts">
        <div class="category-posts">
            <div class="fw-row">
                <?php if ( $osm_query->have_posts() ) :
                    // Start the Loop.
                        while ( $osm_query->have_posts() ) : $osm_query->the_post();
                        ?>
                            <div class="fw-col-lg-6 fw-col-md-6 fw-col-sm-6 fw-col-xs-12">
                                <article>
                                    <figure>
                                        <?php
                                            $osum_post_class =  'default-post';
                                            if($osum_post_options == 'audio'){
                                                echo '<figure><iframe width="100%" height="450" scrolling="no" frameborder="no" src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/'.$osum_audio_url.'&amp;auto_play=false&amp;hide_related=false&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false&amp;visual=true"></iframe></figure>';
                                            }elseif($osum_post_options == 'video'){
                                                $osum_video_url = isset($post_metadata['osum_video_url'])? $post_metadata['osum_video_url'] : '';
                                                $video  = wp_oembed_get($osum_video_url);
                                                echo '<div class="blog-video">'.$video.'</div>';
                                            }elseif($osum_post_options == 'slider'){
                                                echo $slider =  fw()->extensions->get('slider')->render_slider($osum_post_gallery, array('width'  =>'1170','height' => '530'));
                                            }else{
                                                
                                                if(has_post_thumbnail($post->ID)):
                                                    
                                                    osum_post_thumbnail('size-200x150');
                                                else:
                                                    $osum_post_class = 'full-post';
                                                    // echo osum_author_meta();
                                                endif;
                                            }
                                        ?>
                                    </figure>
                                    <div class="post-summary">
                                        <div class="date"><?php echo osum_get_date(); ?></div>
                                        <?php the_title( sprintf( '<h3 class="post-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h3>' ); ?>
                                        <a class="readmore_btn" href="<?php the_permalink(); ?>">
                                            read more <i class="lnr lnr-chevron-right"></i><i class="lnr lnr-chevron-right"></i>
                                        </a>
                                    </div>
                                </article>
                            </div>
                        <?php
                        endwhile;
                    endif;
                ?>
            </div>
        </div>
    </div>
<?php endif; */
?>
<div class="cat_slider grid-view">
    <div class="fw-row">
        <div class="fw-col-lg-8 fw-col-md-8 fw-col-sm-8 fw-col-xs-12">
            <!-- <div class="page-title">
                <?php
                    //single_cat_title( '<h2>', '</h2>' );
                ?>
            </div> -->
            <div class="category-section">
                <?php if ( have_posts() ) :
                    // Start the Loop.
                    while ( have_posts() ) : the_post(); ?>
                        <div class="item">
                            <div class="post-thumb">
                                <?php the_post_thumbnail('slider');?>
                            </div>
                            <div class="post-details">
                                <div class="post-options">
                                    <ul>
                                        <li>
                                            <?php 
                                                $categories_list = get_the_category_list( _x( ', ', 'Used between list items, there is a space after the comma.', 'osum' ) );
                                                if ( $categories_list ) {
                                                    echo $categories_list;
                                                }
                                            ?>
                                        </li>
                                        <!-- <li><i class="fa fa-eye"></i> <?php echo getPostViews(get_the_ID()); ?></li> -->
                                    </ul>
                                </div>
                                <h3 class="post-title"><a href="<?php the_permalink(); ?>"><?php echo substr(get_the_title(),0,50 ); ?></a></h3>
                                <div class="post-options">
                                    <ul>
                                        <li>
                                            <?php echo get_the_date( 'M d, Y' ); ?>
                                        </li>
                                    </ul>
                                </div>
                                <div class="post-text">
                                    <?php echo apply_filters('the_content', substr(get_the_content(), 0, 160) ); ?>
                                    <?php  if(!post_password_required()) echo '<a href="'.get_the_permalink().'" class="read_more">'.__('Read Story','osum').'</a>'; ?>
                                    <?php
                                        /* translators: %s: Name of current post */
                                        /*the_content( sprintf(
                                            __( 'Continue reading %s', 'osum' ),
                                            the_title( '<span class="screen-reader-text">', '</span>', false )
                                        ) );*/

                                        wp_link_pages( array(
                                            'before'      => '<div class="page-links"><span class="page-links-title">' . __( 'Pages:', 'osum' ) . '</span>',
                                            'after'       => '</div>',
                                            'link_before' => '<span>',
                                            'link_after'  => '</span>',
                                            'pagelink'    => '<span class="screen-reader-text">' . __( 'Page', 'osum' ) . ' </span>%',
                                            'separator'   => '<span class="screen-reader-text">, </span>',
                                        ) );
                                    ?>
                                </div>
                            </div>
                        </div>
                        <?php
                    endwhile;
                endif;
                ?>
            </div>
        </div>
        <div class="fw-col-lg-4 fw-col-md-4 fw-col-sm-4 fw-col-xs-12">
            <div class="sidebar-widgets">
                <?php dynamic_sidebar( 'sidebar-1' ); ?>
            </div>
        </div>
    </div>
    <div class="divider"></div>
</div>
<?php get_footer(); ?>
