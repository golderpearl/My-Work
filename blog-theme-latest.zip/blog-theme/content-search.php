<?php ?>
<article id="post-<?php the_ID(); ?>" <?php post_class('blogpost'); ?>>
    <figure>
    	<?php osum_post_thumbnail('size-415x233');?>
    	<div class="cat pink"><?php osum_catlist(); ?></div>
    </figure>
    <div class="text-details">
		<?php the_title( sprintf( '<h3 class="post-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h3>' ); ?>
		<div class="date"><?php osum_get_date(); ?></div><?php 
			the_excerpt(); 
			echo osum_read_more();
		?>
	</div>
</article>
