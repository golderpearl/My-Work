<?php get_header();
    global $post;

    $post_metadata = get_post_meta($post->ID,'osum_meta_key',true);
    $osum_sidebar = isset($post_metadata['osum_sidebar'])? $post_metadata['osum_sidebar'] : '';
    $oms_layout  = isset($post_metadata['osum_sidebar_layout'])? $post_metadata['osum_sidebar_layout'] : 'full_width';
    $oms_layout_cls	= ($oms_layout == 'full_width') ? 'osum-full-width' : 'col-lg-8 col-md-8 col-sm-8 col-xs-12';	
?>
<div class="<?php echo $oms_layout_cls; ?>">
    <?php
    // Start the loop.
    while ( have_posts() ) : the_post();

        // Include the page content template.
        get_template_part( 'content', 'page' );

        // If comments are open or we have at least one comment, load up the comment template.
        if ( comments_open() || get_comments_number() ) :
          //  comments_template();
        endif;

    // End the loop.
    endwhile;
    ?>
</div>
     
<?php get_footer(); ?>