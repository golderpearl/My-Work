<?php
/**
 * The template for displaying archive pages
 *
 * Used to display archive-type pages if nothing more specific matches a query.
 * For example, puts together date-based pages if no date.php file exists.
 *
 * If you'd like to further customize these archive views, you may create a
 * new template file for each one. For example, tag.php (Tag archives),
 * category.php (Category archives), author.php (Author archives), etc.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */

get_header(); 
	$osum_layout = isset($osum_options['sidebar_layout']) ? $osum_options['sidebar_layout'] : 'full_width';
	$osum_sidebar  = isset($osum_options['sidebar'])? $osum_options['sidebar'] : '';
	$osum_layout = 'full_width';

	$oms_layout_cls	= ($osum_layout == 'full_width') ? 'col-lg-12 col-md-12 col-sm-12 col-xs-12' : 'col-lg-8 col-md-8 col-sm-8 col-xs-12';
?>
	<div class="search-listing fw-container category-area">
     	<div class="row">
			<?php if ( is_active_sidebar( $osum_sidebar ) and $osum_layout == 'left_sidebar' ) { ?>
                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                    <div class="sidebar">
                    <?php dynamic_sidebar( $osum_sidebar ); ?>
                </div>
                </div>
            <?php } ?>
    <div class="page-title">
		<?php
					single_cat_title( '<h2>', '</h2>' );
				?>

			</div>
              <?php
                                the_archive_description( '<div class="taxonomy-description">', '</div>' );
                            ?>
		<div class="<?php echo $oms_layout_cls; ?>">
                <div class="flexslider">
                    <ul class="slides">
                    	<?php if ( have_posts() ) : ?>
                          
						<?php
                            // Start the Loop.
                            while ( have_posts() ) : the_post();
							?>
							<li id="post-<?php the_ID(); ?>" class="post">
                        <div class="post-thumb">
                            <?php the_post_thumbnail('size-750x480');?>
                            <div class="caption">
                            <?php $categories_list = get_the_category_list( _x( ', ', 'Used between list items, there is a space after the comma.', 'osum' ) );
                            if ( $categories_list ) {
                                    echo $categories_list;
                            }
                            ?>
                            <div class="bottom-section">
                                <div class="date"><?php echo osum_get_date(); ?></div>
                                <h3><a href="<?php the_permalink(); ?>"><?php echo substr(get_the_title(),0,50 ); ?></a></h3>
                            </div>    
                            </div>
                        </div>
                     </li>
							<?php
                        
                            
                            endwhile;
                           endif;
                    ?>
                    </ul>
                </div>
				<div class="blog-section categories-section">
                	<div class="cat_posts">
					<?php if ( have_posts() ) : ?>
                          
						<?php
                            // Start the Loop.
                            while ( have_posts() ) : the_post();
                        
                            /*
                            * Include the Post-Format-specific template for the content.
                            * If you want to override this in a child theme, then include a file
                            * called content-___.php (where ___ is the Post Format name) and that will be used instead.
                            */
                                get_template_part( 'content', get_post_format() );
                            // End the loop.
                            endwhile;
                           // Previous/next page navigation.
                            the_posts_pagination( array(
								'type'	=>	'list',
								'prev_text'          => __( 'Previous page', 'osum' ),
                                'next_text'          => __( 'Next page', 'osum' ),
                                'before_page_number' => '',
                            ) );
                        
                            // If no content, include the "No posts found" template.
                        else :
		                    get_template_part( 'content', 'none' );
							
						endif;
                    ?>
                    	</div>      	
                </div>
            </div>
    		
        
            <?php if ( is_active_sidebar( $osum_sidebar )  and $osum_layout == 'right_sidebar') { ?>
                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                    <div class="sidebar">
                    <?php dynamic_sidebar( $osum_sidebar ); ?>
                </div>
                </div>
            <?php } ?>
            </div>
    </div>	
<?php get_footer(); ?>
