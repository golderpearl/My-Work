jQuery(document).ready(function(){
    if ( jQuery('#fw-edit-options-modal-all_cats').prop(':checked') ) {
        jQuery('#fw-edit-options-modal-category').css('display', 'none');
    } else {
        jQuery('#fw-edit-options-modal-category').css('display', 'block');
    }
});