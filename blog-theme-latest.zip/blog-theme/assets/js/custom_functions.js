function main_slider () {
    "use strict";
    jQuery('.flexslider').flexslider({
        animation: "slide",
        prevText: "<i class='lnr lnr-chevron-left'></i>",
        nextText: "<i class='lnr lnr-chevron-right'></i>",
        controlNav: false,
    });
}

function loading () {
    "use strict";
    jQuery('.loading-page').fadeOut(400);
}

function gototop() {
    "use strict";
    //Click event to scroll to top
    jQuery('.scrollToTop').on("click", function(){
        jQuery('html, body').animate({scrollTop : 0},800);
        return false;
    });
}

function categorySlider() {
    var owl = jQuery(".cat_slider .owl-carousel");
    owl.owlCarousel({
        items : 3,
        itemsDesktop :      [1000,3],
        itemsDesktopSmall : [900,3],
        itemsTablet:        [768,3],
        itemsMobile :       [650,2],
        itemsMobile :       [450,1],
        navigation:         true,
        navigationText:     ["<i class='lnr lnr-chevron-left'></i>","<i class='lnr lnr-chevron-right'></i>"],
        pagination:         false,
        margin:             20,
    });
}

function page_scroling() {

    "use strict";
    // Page scroll
    jQuery("html").niceScroll({
        horizrailenabled:false,
        cursorcolor:"#000",
        background: "#e6e6e6",
        cursorborderradius: "0px",
        cursorwidth: "15px",
        cursorborder: "",
        cursoropacitymax:0.7,
        boxzoom:false,
        touchbehavior:false
    });

}

function navbar_scrolling() {

    "use strict";
    // Nav scroll
    jQuery("ul.menu-items").niceScroll({
        horizrailenabled:false,
        cursorcolor:"#000",
        background: "#e6e6e6",
        cursorborderradius: "0px",
        cursorwidth: "15px",
        cursorborder: "",
        cursoropacitymax:0.7,
        boxzoom:false,
        touchbehavior:false
    });

}

function osum_mc(theme_url,counter,admin_url){
    'use strict';
    $ = jQuery;
    $('#btn_newsletter_'+counter).hide();
    $('#process_'+counter).html('<div id="process_newsletter_'+counter+'" style="width:168px;" class="bg-clr"><i class="spinner icon icon-spinner4"></i></div>');
    $.ajax({
        type:'POST', 
        url: admin_url,
        data:$('#mcform_'+counter).serialize()+'&action=osum_ajax_mailchimp', 
        success: function(response) {
            $('#mcform_'+counter).get(0).reset();
            $('#newsletter_mess_'+counter).fadeIn(600);
            $('#newsletter_mess_'+counter).html(response);
            $('#btn_newsletter_'+counter).fadeIn(600);
            $('#process_'+counter).html('');
        }
    });
}

function resize() {
    if (window.innerWidth < 980 ) {
        navbar_scrolling();
        jQuery('a.menu-toggle').on('click', function(event) {
            event.preventDefault();
            jQuery(this).next('div.menu-items').addClass('opened');
            return false
        });
        jQuery('a#close-menu').on('click', function(event) {
            event.preventDefault();
            jQuery(this).parent().parent('div.menu-items').removeClass('opened');
            return false
        });
        jQuery('div.menu-items ul li.menu-item-has-children > a').on('click', function(event) {
            event.preventDefault();
            jQuery(this).next('ul.sub-menu').toggleClass('opened');
            return false
        });
        
        var windowHeight = jQuery(window).height() - 100;
        jQuery('ul.menu-items').css('height', windowHeight );
        navbar_scrolling();
        
    }else {
        jQuery('ul.menu-items').css('height', 'auto');
    };
}

// Functions callout here.
jQuery(document).ready(function($) {
    //categorySlider();
    //page_scroling();
});

jQuery(window).load(function(){
    main_slider();
    loading();
    resize();
    jQuery(window).resize(resize);
});