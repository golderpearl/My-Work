<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
} ?>
	<?php if($atts['layout'] == 'horizontal'): ?>
		<div class="callout-text">
		  <h3><?php echo $atts['message']; ?></h3>
		  <a href="<?php echo esc_attr($atts['button_link']); ?>" class="fw-btn fw-btn-1 os_btn" target="<?php echo esc_attr($atts['button_target']); ?>">
			  <?php echo $atts['button_label']; ?>
		  </a>
		</div>
<?php 
	else: 
		echo '<div class="fw-container"><div class="middle-area">
				  <h2>'.$atts['message'].'</h2>
				  <a href="'.esc_url($atts['button_link']).'" class="fw-btn fw-btn-1 buynow_btn" target="'.esc_attr($atts['button_target']).'">'.$atts['button_label'].'</a>
		</div></div>';
	endif;
?>