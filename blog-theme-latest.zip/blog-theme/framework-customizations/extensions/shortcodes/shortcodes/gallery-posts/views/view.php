<?php if (!defined('FW')) die('Forbidden');

/**
 * @var $atts The shortcode attributes
 */

   extract( shortcode_atts( array(
      'title'		=> '',
 	  'post_per_page' 	=> '10'
    ), $atts ) );

	$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;  
   	$query = array( 'post_type' => 'post','posts_per_page' => 2);
	$osm_query = new WP_Query( $query );
	$GLOBALS['wp_query']->max_num_pages = $osm_query->max_num_pages;
	echo '<div class="categories-section pattern">
			<div class="fw-container">';
		echo '<div class="category-title"><h2>'.$atts['title'].'</h2></div>';
		if ( $osm_query->have_posts() ) : 
			// Start the loop.
			?>
            <script type="text/javascript">
				jQuery(document).ready(function($){
			   		jQuery(".owl-carousel.fullpage").owlCarousel({
						navigation : 		true,
				
						slideSpeed : 		300,
				
						paginationSpeed : 	400,
				
						singleItem: 		true,
				
						navigationText: 	["<i class='lnr lnr-chevron-left'></i>","<i class='lnr lnr-chevron-right'></i>"],
				
						pagination: 		false,
				});
		});
	</script>
	<?php
			if($osm_query->have_posts()):
 					echo '<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 post-slider"><div class="flexslider"><ul class="slides">';
					while (  $osm_query->have_posts() ) :  $osm_query->the_post();
					?>
					<li id="post-<?php the_ID(); ?>" class="post">
                        <div class="post-thumb">
                            <?php the_post_thumbnail('size-556x470');?>
                            <div class="caption">
                            <?php $categories_list = get_the_category_list( _x( ', ', 'Used between list items, there is a space after the comma.', 'osum' ) );
                            if ( $categories_list ) {
                                    echo $categories_list;
                            }
                            ?>
                            <div class="bottom-section">
                                <div class="date"><?php echo osum_get_date(); ?></div>
                                <h3><a href="<?php the_permalink(); ?>"><?php echo substr(get_the_title(),0,50 ); ?></a></h3>
                            </div>    
                            </div>
                        </div>
                     </li>
					<?php

				endwhile;
					echo '</ul></div></div>';	
					endif;
 					$loopcount = 1;
			$counter = 1;
	$query = array( 'post_type' => 'post','posts_per_page' => $post_per_page,'paged' => $paged ,'offset'     =>3);
	$osm_query = new WP_Query( $query );	
			if($osm_query->have_posts()):	
			echo '<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 bottom-sidebar"><div id="owl-demo3" class="owl-carousel fullpage owl-theme"><div class="item"><div class="row">';

			while (  $osm_query->have_posts() ) :  $osm_query->the_post();
				//if($counter == 1){ echo '<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 sidebar">';}
				 echo '<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 sidebar">';
				get_template_part( 'galleries', 'slider' );
				echo '</div>';
				//if($loopcount%2 == '0'){ echo '</div><div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 sidebar">';  }
				if($loopcount%4 == '0'){ echo '</div></div><div class="item"><div class="row">'; $counter=0;}
			$loopcount++;
			$counter++;
				// End the loop.
			endwhile;
			echo '</div></div></div></div>';
			endif;

		  else :
			  get_template_part( 'content', 'none' );
		  endif;	
	


		echo '</div></div>';