<?php if (!defined('FW')) die('Forbidden');

$options = array(
	'title' 	=> array(
		'label'   	=> __('Title', 'unyson'),
		'desc'    	=> __('Write section title', 'unyson'),
		'type'   	=> 'text',
		'value'		=> ''
	),
	'post_per_page' => array(
		'label'  	=> __('Post Per Page', 'unyson'),
		'desc'    	=> __('Write some text', 'unyson'),
		'type'    	=> 'text',
		'value'		=> '10'
	
	)
	

);