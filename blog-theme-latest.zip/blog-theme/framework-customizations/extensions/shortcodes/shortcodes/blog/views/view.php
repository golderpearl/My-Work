<?php if (!defined('FW')) die('Forbidden');

/**
 * @var $atts The shortcode attributes
 */
$text = $atts['text'];
$text_color = $atts['text_color'];
   extract( shortcode_atts( array(
      'title'		=> '',
      'category'	=> '',
      'layout' 		=> 'list',
	  'post_per_page' 	=> '10',
	  'show_pagination' => 'yes'
   ), $atts ) );
   	$idObj = get_category_by_slug($category); 
 	$category_id = $idObj->term_id;
  	$category_link = get_category_link( $category_id );
	$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;  
   	$query = array( 'post_type' => 'post','category_name' => $category,'posts_per_page' => $post_per_page,'paged' => $paged );
	$osm_query = new WP_Query( $query );
	$GLOBALS['wp_query']->max_num_pages = $osm_query->max_num_pages;
	
	if($layout == 'slider'):
		echo '<div class="cat_slider '.$layout.'-view">';
			$section_title = $atts['title'];
			if ($section_title != '') {
				echo '<div class="section-title"><h2>'.$section_title.'</h2></div>';
			}
			if ( $osm_query->have_posts() ) : 
				// Start the loop.
				?>
	            <script type="text/javascript">
					jQuery(document).ready(function($){
				    	var owl = jQuery(".cat_slider .owl-carousel");
						owl.owlCarousel({
							items : 3,
							itemsDesktop :      [1000,3],
							itemsDesktopSmall : [900,3],
							itemsTablet:        [768,3],
							itemsTabletSmall :  [767,2],
							itemsMobile :       [450,1],
							navigation:         true,
							navigationText:     ["<i class='lnr lnr-chevron-left'></i>","<i class='lnr lnr-chevron-right'></i>"],
							pagination:         false,
							margin:             20,
						});
					});
				</script>
				<?php
				$counter = 0;
				echo '<div id="owl-demo'.$counter.'" class="owl-carousel owl-theme">';
					while (  $osm_query->have_posts() ) :  $osm_query->the_post();

						get_template_part( 'content', 'slider' );
					
						// End the loop.
					endwhile;
				echo '</div>';
				$counter++;
		  	else :
				  get_template_part( 'content', 'none' );
		  	endif;
	 	echo "</div>";
	elseif($layout == 'most_viewed'):
		$most_viewed = new WP_Query( array(
			'post_type' => 'post',
			'category_name' => $category,
			'posts_per_page' => $post_per_page,
			'paged' => $paged,
		    'meta_key' => 'post_views_count',
		    'orderby' => 'meta_value_num',
		    'posts_per_page' => 5
		) );
		echo '<div class="cat_slider '.$layout.'-view">';
			$section_title = $atts['title'];
			if ($section_title != '') {
				echo '<div class="section-title"><h2>'.$section_title.'</h2></div>';
			}
			if ( $most_viewed->have_posts() ) : 
				// Start the loop.
				?>
	            <script type="text/javascript">
					jQuery(document).ready(function($){
				    	var owl = jQuery(".cat_slider .owl-carousel");
						owl.owlCarousel({
							items : 3,
							itemsDesktop :      [1000,3],
							itemsDesktopSmall : [900,3],
							itemsTablet:        [768,3],
							itemsTabletSmall :  [767,2],
							itemsMobile :       [450,1],
							navigation:         true,
							navigationText:     ["<i class='lnr lnr-chevron-left'></i>","<i class='lnr lnr-chevron-right'></i>"],
							pagination:         false,
							margin:             20,
						});
					});
				</script>
				<?php
				$counter = 0;
				echo '<div id="owl-demo'.$counter.'" class="owl-carousel owl-theme">';
				while (  $most_viewed->have_posts() ) :  $most_viewed->the_post();
					get_template_part( 'content', 'most-viewed' );
					// End the loop.
				endwhile;
				echo '</div>';
				$counter++;
		  	else :
				  get_template_part( 'content', 'none' );
		  	endif;
	 	echo "</div>";
	elseif($layout == 'grid'):
		echo '<div class="cat_slider '.$layout.'-view"><div class="category-section">';
			$section_title = $atts['title'];
			if ($section_title != '') {
				echo '<div class="section-title"><h2>'.$section_title.'</h2></div>';
			}
			if ( $osm_query->have_posts() ) : 
				// Start the loop.
				while (  $osm_query->have_posts() ) :  $osm_query->the_post();

					get_template_part( 'content', 'grid' );
				
					// End the loop.
				endwhile;
			else :
				  get_template_part( 'content', 'none' );
			endif;
		echo '</div></div>';

	elseif($layout == 'list'):
		echo '<div class="'.$layout.'-view"><div class="category-section">';
			$section_title = $atts['title'];
			if ($section_title != '') {
				echo '<div class="section-title"><h2>'.$section_title.'</h2></div>';
			}
			if ( $osm_query->have_posts() ) : 
				// Start the loop.
				while (  $osm_query->have_posts() ) :  $osm_query->the_post();

					get_template_part( 'content', 'list' );
				
					// End the loop.
				endwhile;
			else :
				  get_template_part( 'content', 'none' );
			endif;
		echo '</div></div>';
	endif;
	?>