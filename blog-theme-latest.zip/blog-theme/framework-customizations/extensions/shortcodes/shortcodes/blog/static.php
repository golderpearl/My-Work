<?php if (!defined('FW')) die('Forbidden');

$shortcodes_extension = fw_ext('shortcodes');
wp_enqueue_style(
	'fw-blog-post-script',
	$shortcodes_extension->get_declared_URI('/shortcodes/blog/static/js/script.js'),
	array('blog-post')
);

