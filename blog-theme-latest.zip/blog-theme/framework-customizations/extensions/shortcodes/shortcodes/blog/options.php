<?php if (!defined('FW')) die('Forbidden');

$options = array(
	'title' 	=> array(
		'label'   	=> __('Title', 'unyson'),
		'desc'    	=> __('Write section title', 'unyson'),
		'type'   	=> 'text',
		'value'		=> ''
	),
	/* 'all_cats' => array(
		'label' => __('Select Categories', 'unyson'),
		'type'  => 'checkbox',
		'value' => true, // checked/unchecked
		'attr'  => array( 'class' => 'all-categories' ),
		'id'	=> 'all_categories',
		'desc'  => __('', 'unyson'),
		'help'  => __('', 'unyson'),
		'text'  => __('Select All Categories', 'unyson'),
	), */
	'category' => array(
		'label'   => __('Category', 'unyson'),
		'id'	  => 'blog_categories',
		'desc'    => __('Choose the category', 'unyson'),
		'type'    => 'select',
		'choices' 	=> osum_get_catlist('category'),
		'value'		=> ''
	),
	'layout' => array(
		'label'   => __('Layout', 'unyson'),
		'desc'    => __('Choose the text color', 'unyson'),
		'type'    => 'select',
		'choices' 	=> array(
			'list'			=> __('List', 'unyson'),
			'grid' 			=> __('Grid', 'unyson'),
			'most_viewed' 	=> __('Most Viewed', 'unyson'),
			'slider' 		=> __('Slider', 'unyson')
		),
		'value'		=> 'grid'
	),	
	'post_per_page' => array(
		'label'  	=> __('Post Per Page', 'unyson'),
		'desc'    	=> __('Write some text', 'unyson'),
		'type'    	=> 'text',
		'value'		=> '10'
	
	),
	'show_pagination' => array(
		'label'   => __('Show Pagination', 'unyson'),
		'desc'    => __('Choose the text color', 'unyson'),
		'type'    => 'select',
		'choices' 	=> array(
			'yes'	=> __('Yes', 'unyson'),
			'no' 	=> __('No', 'unyson')
		),
		'value'		=> 'yes'
	),
	

);