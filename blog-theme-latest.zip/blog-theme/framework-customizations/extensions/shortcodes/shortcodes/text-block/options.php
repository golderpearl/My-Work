<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$options = array(
	'title' 	=> array(
		'label'   	=> __('Title', 'unyson'),
		'desc'    	=> __('Write section title', 'unyson'),
		'type'   	=> 'text',
		'value'		=> ''
	),
	'text' => array(
		'type'   => 'wp-editor',
		'teeny'  => true,
		'reinit' => true,
		'label'  => __( 'Content', 'fw' ),
		'desc'   => __( 'Enter some content for this texblock', 'fw' )
	),
	'editor_class' 	=> array(
		'label'   	=> __('Add Class', 'unyson'),
		'desc'    	=> __('', 'unyson'),
		'type'   	=> 'text',
		'value'		=> ''
	),
);
