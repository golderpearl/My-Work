<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

/**
 * @var array $atts
 */
$section_title = $atts['title'];
	
?>
<div class="content-area <?php echo esc_attr( $atts['editor_class'] ); ?>">
	<?php
		if ($section_title != '') {
			echo '<div class="page-title"><h1>'.$section_title.'</h1></div>';
		}
	?>
	<?php echo do_shortcode( $atts['text'] ); ?>
</div>