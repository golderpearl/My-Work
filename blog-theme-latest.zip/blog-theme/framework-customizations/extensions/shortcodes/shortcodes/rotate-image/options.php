<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$options = array(
	'image' => array(
		'label' => __( 'Rotate Image', 'fw' ),
		'desc'  => __( 'Either upload a new, or choose an existing image from your media library', 'fw' ),
		'type'  => 'upload'
	),
	'name'  => array(
		'label' => __( 'Rotate Image Name', 'fw' ),
		'desc'  => __( 'Name of the Rotate Image', 'fw' ),
		'type'  => 'text',
		'value' => ''
	),
	'position'         => array(
		'label' => __( 'Select Position', 'fw' ),
		'desc'  => __( 'Option Rotate Position', 'fw' ),
		'type'  => 'select',
		'choices'=> array(
			'left'		=>'Rotate Left',
			'none'		=>'Rotate None',
			'right'		=>'Rotate Right'
		)
	)
);