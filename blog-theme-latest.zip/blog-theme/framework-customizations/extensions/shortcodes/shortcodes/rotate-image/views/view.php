<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

if ( !empty( $atts['image'] ) ) {
	$image = $atts['image']['url'];
}
?>
<!-- <div class="image-section"> -->
	<?php if( $atts['position'] == 'left' ) { ?>
	    <div class="rotate-left">
	        <img src="<?php echo esc_attr($image); ?>" alt="<?php echo esc_attr($atts['name']); ?>"/>
	    </div>
	<?php } ?>
	<?php if( $atts['position'] == 'none' ) { ?>
	    <div class="rotatenone">
	        <img src="<?php echo esc_attr($image); ?>" alt="<?php echo esc_attr($atts['name']); ?>"/>
	    </div>
	<?php } ?>
	<?php if( $atts['position'] == 'right' ) { ?>
	    <div class="rotate-right">
	        <img src="<?php echo esc_attr($image); ?>" alt="<?php echo esc_attr($atts['name']); ?>"/>
	    </div>
	<?php } ?>
<!-- </div> -->