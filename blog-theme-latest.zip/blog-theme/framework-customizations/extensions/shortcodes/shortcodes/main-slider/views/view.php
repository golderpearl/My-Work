<?php if (!defined('FW')) die('Forbidden');

/**
 * @var $atts The shortcode attributes
 */
   extract( shortcode_atts( array(
      'title'			=> '',
	  'category' 		=> ''
    ), $atts ) );

	$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;  
   	$query = array( 'post_type' => 'post','category_name' => $category,'posts_per_page' => 1);
	$osm_query = new WP_Query( $query );
	$GLOBALS['wp_query']->max_num_pages = $osm_query->max_num_pages;
	echo '<div class="posts-section">';
			// Start the loop.
				//	echo '<div class="category-title"><h2>'.$atts['title'].'</h2></div>';
			?>
			<div class="post-slider">
				<div class="flexslider">
					<ul class="slides">
						<?php
						   	$query = array( 'post_type' => 'post','category_name' => $category,'post__in' => get_option('sticky_posts'));
							$osm_query = new WP_Query( $query );
							if($osm_query->have_posts()):	
								while (  $osm_query->have_posts() ) :  $osm_query->the_post();
									?>
									<li id="post-<?php the_ID(); ?>" <?php post_class('post'); ?>>
										<div class="img-post">
											<?php the_post_thumbnail( 'slider' ); //echo get_the_post_thumbnail('slider'); ?>
										</div>
										<div class="caption">
											<div class="cat">
												<?php $categories_list = get_the_category_list( _x( ', ', 'Used between list items, there is a space after the comma.', 'osum' ) );
													if ( $categories_list ) {
														echo $categories_list;
													}
												?>
											</div>
											<h3 class="post-title">
												<a href="<?php the_permalink(); ?>"><?php echo substr(get_the_title(),0,50 ); ?></a>
											</h3>
											<p><?php echo substr(get_the_content(), 0, 81) ?></p>
											<a href="<?php the_permalink(); ?>" class="readmore_btn">Read More</a>
										</div><?php //echo osum_get_date(); ?>
									</li>
								<?php
	                            // End the loop.
	                           	endwhile;
	                        endif;
						?>
					</ul>
				</div>
			</div>
		</div>