<?php if (!defined('FW')) die('Forbidden');

$options = array(
	'title' 	=> array(
		'label'   	=> __('Title', 'unyson'),
		'desc'    	=> __('Write section title', 'unyson'),
		'type'   	=> 'text',
		'value'		=> ''
	),
	'category' => array(
		'label'   => __('Category', 'unyson'),
		'desc'    => __('Choose the category', 'unyson'),
		'type'    => 'select',
		'choices' 	=> osum_get_catlist('category'),
		'value'		=> ''
	),
	'posts_per_page' 	=> array(
		'label'   	=> __('Posts per Page', 'unyson'),
		'desc'    	=> __('Set Posts per Page', 'unyson'),
		'type'   	=> 'text',
		'value'		=> ''
	),
);