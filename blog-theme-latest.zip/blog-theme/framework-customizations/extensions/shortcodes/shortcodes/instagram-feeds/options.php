<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$options = array(
	'layout'         => array(
		'label' => __( 'Layout', 'fw' ),
		'desc'  => __( 'Option Team Title', 'fw' ),
		'type'  => 'select',
		'choices'=> array(
			'large_grid_view'	=>	'Large Grid View',
			'small_grid_view'	=>	'Small Grid View'
		)
	),
	'instagra_title'  => array(
		'label' => __( 'Instagram Label', 'fw' ),
		'desc'  => __( '', 'fw' ),
		'type'  => 'text',
		'value' => 'Follow Me & Share Your Love'
	),
	'instagra_posts'  => array(
		'label' => __( 'Display Posts', 'fw' ),
		'desc'  => __( '', 'fw' ),
		'type'  => 'text',
		'value' => '8'
	),
	'button_label'  => array(
		'label' => __( 'Button Label', 'fw' ),
		'desc'  => __( '', 'fw' ),
		'type'  => 'text',
		'value' => 'Follow @Aaital'
	),
	'button_link'   => array(
		'label' => __( 'Instagram Link', 'fw' ),
		'desc'  => __( 'Where should your button link to', 'fw' ),
		'type'  => 'text',
		'value' => 'https://www.instagram.com/aaital/'
	),
	'button_target' => array(
		'type'    => 'switch',
		'label'   => __( 'Open Link in New Window', 'fw' ),
		'desc'    => __( 'Select here if you want to open the linked page in a new window', 'fw' ),
		'right-choice' => array(
			'value' => '_blank',
			'label' => __('Yes', 'fw'),
		),
		'left-choice' => array(
			'value' => '_self',
			'label' => __('No', 'fw'),
		),
	),
);