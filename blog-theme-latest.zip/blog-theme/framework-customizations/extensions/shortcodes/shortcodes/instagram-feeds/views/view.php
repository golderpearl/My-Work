<?php if ( ! defined( 'FW' ) ) {
		die( 'Forbidden' );
}
global $osum_options;

//var_dump($atts);
$osum_instagram = (isset($osum_options['instagram']) and $osum_options['instagram'] <> '') ? $osum_options['instagram'] : '';
$osum_instagramuser = (isset($osum_options['instagram_user']) and $osum_options['instagram_user'] <> '') ? $osum_options['instagram_user'] : '';
$instagram_posts = (isset($osum_options['instagram_posts']) and $osum_options['instagram_posts'] <> '') ? $osum_options['instagram_posts'] : '';

// use this instagram access token generator http://instagram.pixelunion.net/
//$access_token="6950361203.1677ed0.1bf7bb4e781c43a98dd1a6fe0fb2ccdf";
$access_token = $osum_instagramuser;
$photo_count = $atts['instagra_posts'];

$json_link="https://api.instagram.com/v1/users/self/media/recent/?";
$json_link.="access_token={$access_token}&count={$photo_count}";

$json = file_get_contents($json_link);
$obj = json_decode($json, true, 512, JSON_BIGINT_AS_STRING);
//var_dump($obj['data']);

//var_dump($atts);
if( !empty( $obj['data'] ) ){ ?>

	<div class="instagram-posts">
		<div class="fw-container">
			<?php if($atts['layout'] == 'large_grid_view') { ?>
				<div class="<?php echo $atts['layout']; ?>">
					<div class="insta-title">
						<h2>@aaital</h2>
						<?php if( !empty($atts['instagra_title']) ) { ?>
							<h3><?php echo $atts['instagra_title']; ?></h3>
						<?php } ?>
						<?php if( !empty($atts['button_label']) ) { ?>
							<a href="<?php echo esc_attr($atts['button_link']); ?>" class="follow-btn" target="<?php echo esc_attr($atts['button_target']); ?>">
								<?php echo $atts['button_label']; ?>
							</a>
						<?php } ?>
					</div>
					<?php
					?>
					<ul>
						<?php
							foreach ($obj['data'] as $post) {
								$pic_text=$post['caption']['text'];
								$pic_link=$post['link'];
								$pic_alt=$post['tags'][0];
								$pic_like_count=$post['likes']['count'];
								$pic_comment_count=$post['comments']['count'];
								$pic_src=str_replace("http://", "https://", $post['images']['low_resolution']['url']);
								$pic_created_time=date("F j, Y", $post['caption']['created_time']);
								$pic_created_time=date("F j, Y", strtotime($pic_created_time . " +1 days"));

								echo "<li>";        
									echo "<a href='{$pic_link}' target='_blank'>";
										echo "<img class='img-responsive photo-thumb' src='{$pic_src}' alt='{$pic_alt}'>";
									echo "</a>";
								echo "</li>";
							}
						?>
					</ul>
				</div>
			<?php } elseif($atts['layout'] == 'small_grid_view'){ ?>
				<div class="<?php echo $atts['layout']; ?>">
					<ul>
						<?php
							foreach ($obj['data'] as $post) {
								$pic_text=$post['caption']['text'];
								$pic_link=$post['link'];
								$pic_alt=$post['tags'][0];
								$pic_like_count=$post['likes']['count'];
								$pic_comment_count=$post['comments']['count'];
								$pic_src=str_replace("http://", "https://", $post['images']['standard_resolution']['url']);
								$pic_created_time=date("F j, Y", $post['caption']['created_time']);
								$pic_created_time=date("F j, Y", strtotime($pic_created_time . " +1 days"));

								echo "<li>";        
										echo "<a href='{$pic_link}' target='_blank'>";
											echo "<img class='img-responsive photo-thumb' src='{$pic_src}' alt='{$pic_alt}'>";
										echo "</a>";
										echo '<div class="insta-title absolute">';
												if( !empty($atts['instagra_title']) ) {
													echo '<h3>' . $atts['instagra_title'] . '</h3>';
												}
												if( !empty($atts['button_label']) ) {
													echo '
													<h3>
														<a href="' . esc_attr($atts['button_link']) . '" target="' . esc_attr($atts['button_target']) . '">
															' . $atts['button_label'] . '<img src="' .get_template_directory_uri() . '/assets/images/insta.png" alt=""> @aaital
														</a>
													</h3>';
												}
												echo '
										</div>';
								echo "</li>";
							}
						?>
					</ul>
				</div>
			<?php } ?>
		</div>
	</div>
<?php } ?>