<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array();

$cfg['page_builder'] = array(
	'title'       => __( 'Instagram Feeds', 'fw' ),
	'description' => __( 'Add Instagram Feeds', 'fw' ),
	'tab'         => __( 'Content Elements', 'fw' )
);