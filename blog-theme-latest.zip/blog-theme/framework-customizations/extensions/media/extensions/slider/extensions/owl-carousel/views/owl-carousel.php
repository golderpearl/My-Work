<?php if (!defined('FW')) die('Forbidden'); ?>

<?php if (isset($data['slides'])): ?>
	<script type="text/javascript">


		jQuery(document).ready(function ($) {
			var sync1 = jQuery("#sync1.owl-carousel");
			var sync2 = jQuery("#sync2.owl-carousel");
			sync1.owlCarousel({
		
				items : 1,
				margin: 0,
		
				slideSpeed : 1000,
		
				navigation: true,
		
				navigationText:     ["<i class='lnr lnr-chevron-left'></i>","<i class='lnr lnr-chevron-right'></i>"],
		
				pagination:false,
		
				afterAction : syncPosition,
		
				responsiveRefreshRate : 200,
		
			});
			sync2.owlCarousel({
		
				items : 8,
		
				itemsDesktop      : [1200,5],
		
				itemsDesktopSmall     : [970,4],
		
				itemsTablet       : [768,3],
		
				itemsMobile       : [479,2],
		
				pagination:false,
		
				responsiveRefreshRate : 100,
		
				afterInit : function(el){
		
				  el.find(".owl-item").eq(0).addClass("synced");
		
				}

   	 	});
	    jQuery("#sync2").on("click", ".owl-item", function(e){

        e.preventDefault();

        var number = jQuery(this).data("owlItem");

        sync1.trigger("owl.goTo",number);

    });
		    function syncPosition(el){

        var current = this.currentItem;

        jQuery("#sync2")

            .find(".owl-item")

            .removeClass("synced")

            .eq(current)

            .addClass("synced")

        if(jQuery("#sync2").data("owlCarousel") !== undefined){

            center(current)

        }

    }
	    function center(number){

        var sync2visible = sync2.data("owlCarousel").owl.visibleItems;

        var num = number;

        var found = false;

        for(var i in sync2visible){

            if(num === sync2visible[i]){

                var found = true;

            }

        }



        if(found===false){

            if(num>sync2visible[sync2visible.length-1]){

                sync2.trigger("owl.goTo", num - sync2visible.length+2)

            }else{

                if(num - 1 === -1){

                    num = 0;

                }

                sync2.trigger("owl.goTo", num);

            }

        } else if(num === sync2visible[sync2visible.length-1]){

            sync2.trigger("owl.goTo", sync2visible[1])

        } else if(num === sync2visible[0]){

            sync2.trigger("owl.goTo", num-1)

        }

    }
		});
	</script>
	<div class="post-slider">
         <div id="sync1" class="owl-carousel">
            <?php foreach ($data['slides'] as $slide): ?>
            <div class="item">
                <figure>
                    <img src="<?php echo esc_attr(fw_resize($slide['src'], $dimensions['width'], $dimensions['height'], true)); ?>"
                       alt="<?php echo esc_attr($slide['title']) ?>" />

					</figure>
            </div>
            <?php endforeach; ?>
        </div>
        <div id="sync2" class="owl-carousel">
        	 <?php foreach ($data['slides'] as $slide): ?>
              <div class="item"><img src="<?php echo esc_attr(fw_resize($slide['src'], '90', '90', true)); ?>"
                             alt="<?php echo esc_attr($slide['title']) ?>" /></div>
              <?php endforeach; ?>
          </div>
    </div>

<?php endif; ?>
