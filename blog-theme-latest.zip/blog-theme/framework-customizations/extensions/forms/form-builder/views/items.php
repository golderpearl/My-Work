<?php if (!defined('FW')) die('Forbidden');
/**
 * @var string $items_html
 */
?>
<ul>
	<?php echo $items_html ?>
</ul>