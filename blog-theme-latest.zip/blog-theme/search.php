<?php
/**
 * The template for displaying search results pages.
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */

get_header(); 

	$osum_layout = isset($osum_options['sidebar_layout']) ? $osum_options['sidebar_layout'] : 'full_width';
	$osum_sidebar  = isset($osum_options['sidebar'])? $osum_options['sidebar'] : '';
	$oms_layout_cls	= ($osum_layout == 'full_width') ? 'col-lg-12 col-md-12 col-sm-12 col-xs-12' : 'col-lg-8 col-md-8 col-sm-8 col-xs-12';	

?>
	<div class="fw-container search-listing">
    <div class="page-title">
    	<h2><?php printf( __( 'Result for <span>“%s”</span>', 'twentyfifteen' ), get_search_query() ); ?></h2>
	</div>
		<div class="row">
        	<?php if ( is_active_sidebar( $osum_sidebar ) and $osum_layout == 'left_sidebar' ) { ?>
                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                    <div class="sidebar">
                    <?php dynamic_sidebar( $osum_sidebar ); ?>
                </div>
                </div>
            <?php } ?>
    		<div class="<?php echo $oms_layout_cls; ?>">
				<div class="blog-section">
					<?php if ( have_posts() ) : 
                        // Start the loop.
                        while ( have_posts() ) : the_post(); ?>
            
                            <?php
                            /*
                             * Run the loop for the search to output the results.
                             * If you want to overload this in a child theme then include a file
                             * called content-search.php and that will be used instead.
                             */
                            get_template_part( 'content', 'search' );
            
                        // End the loop.
                        endwhile;
            
                        // Previous/next page navigation.
                       /* the_posts_pagination( array(
                            'prev_text'          => __( 'Previous page', 'osum' ),
                            'next_text'          => __( 'Next page', 'osum' ),
                            'before_page_number' => '',
                        ) );*/
            
                    // If no content, include the "No posts found" template.
                    else :
                        get_template_part( 'content', 'none' );
            
                    endif;
                    ?>
                </div>
            </div>
            <?php if ( is_active_sidebar( $osum_sidebar )  and $osum_layout == 'right_sidebar') { ?>
                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                    <div class="sidebar">
                    <?php dynamic_sidebar( $osum_sidebar ); ?>
                </div>
                </div>
            <?php } ?>

        </div>
    </div>	
<?php get_footer(); ?>