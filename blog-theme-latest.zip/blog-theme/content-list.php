<?php
/**
 * The default template for displaying content
 *
 * Used for both single and index/archive/search.
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */

 global $post;

?>

<article id="post-<?php the_ID(); ?>" <?php post_class('blogpost'); ?>>
	<?php
		// Post thumbnail.
		/* if(is_single()){
			osum_post_thumbnail('size-1170x495');
			the_title( '<h1 class="page-title">', '</h1>' );
			?>
            <div class="post-options">
                <div class="category-section">
					<?php osum_post_meta(); ?>
    				<?php edit_post_link( __( 'Edit', 'osum' ), '<span class="edit-link">', '</span>' ); ?>
               	</div>
                <div class="social-sharing">
                    <ul>
                        <li><a href="#"><i class="icon icon-facebook"></i></a></li>
                        <li><a href="#"><i class="icon icon-google-plus"></i></a></li>
                        <li><a href="#"><i class="icon icon-linkedin"></i></a></li>
                        <li><a href="#"><i class="icon icon-twitter"></i></a></li>
                    </ul>
                </div>
            </div>
            <div class="post-text">
                <?php
                    the_content( sprintf(
                        __( 'Continue reading %s', 'osum' ),
                        the_title( '<span class="screen-reader-text">', '</span>', false )
                    ) );
                    wp_link_pages( array(
                        'before'      => '<div class="page-links"><span class="page-links-title">' . __( 'Pages:', 'osum' ) . '</span>',
                        'after'       => '</div>',
                        'link_before' => '<span>',
                        'link_after'  => '</span>',
                        'pagelink'    => '<span class="screen-reader-text">' . __( 'Page', 'osum' ) . ' </span>%',
                        'separator'   => '<span class="screen-reader-text">, </span>',
                    ) );
                ?>
            </div>
            <div class="social-sharing">
                <ul>
                    <li><a href="#"><i class="icon icon-facebook"></i></a></li>
                    <li><a href="#"><i class="icon icon-google-plus"></i></a></li>
                    <li><a href="#"><i class="icon icon-linkedin"></i></a></li>
                    <li><a href="#"><i class="icon icon-twitter"></i></a></li>
                </ul>
            </div>
            
           <?php
		}else{ */
            if($osum_post_options == 'video_url'):?>
                <a class="play" href="<?php echo the_permalink(); ?>">
                    <img alt="" src="<?php echo get_template_directory_uri();?>/assets/images/play.png">
                </a>
            <?php endif;
			osum_post_thumbnail('blog-listing'); 
			/* if ( post_password_required() || is_attachment() || ! has_post_thumbnail() ) {
                return;
            }
            if (has_post_thumbnail( $post->ID ) ): 
                if ( is_single() ) : ?>
                    <?php $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'single-post-thumbnail' ); ?>
                    <div class="post-thumbnail">
                        <?php  the_post_thumbnail('blog-listing'); ?>
                    </div><!-- .post-thumbnail -->
                <?php else : ?>
                    <a class="post-thumbnail" href="<?php the_permalink(); ?>" aria-hidden="true">
                        <?php
                            echo get_the_post_thumbnail( get_the_ID(), 'blog-listing', array( 'alt' => get_the_title() ) );
                            //the_post_thumbnail( 'blog-listing', array( 'alt' => get_the_title() ) );
                        ?>
                    </a>
                <?php 
                endif; // End is_singular()
            endif; */ ?>
			<div class="blog-post-details">
                <div class="cat">
                    <?php $categories_list = get_the_category_list( _x( ', ', 'Used between list items, there is a space after the comma.', 'osum' ) );
                        if ( $categories_list ) {
                            echo $categories_list;
                        }
                    ?>
                </div>
                <div class="fw-row">
                    <div class="fw-col-md-7 fw-col-sm-7 fw-col-xs-12">
                        <h2 class="post-title">
                            <a href="<?php echo esc_url( get_permalink() ); ?>" rel="bookmark">
                                <?php echo apply_filters('the_title', substr(get_the_title(), 0, 75) ); ?>
                            </a>
                        </h2>
                        <div class="post-options">
                            <ul>
                                <li>
                                    <?php echo get_the_date( 'M d, Y' ); ?>
                                </li>
                            </ul>
                        </div>
                        <div class="post-text">
                            <?php echo apply_filters('the_content', substr(get_the_content(), 0, 120) ); ?>
                            <?php  if(!post_password_required()) echo '<a href="'.get_the_permalink().'" class="read_more">'.__('Read more','osum').'</a>'; ?>
                            <?php
                                /* translators: %s: Name of current post */
                                /* the_content( sprintf(
                                    __( 'Continue reading %s', 'osum' ),
                                    the_title( '<span class="screen-reader-text">', '</span>', false )
                                ) ); */

                                wp_link_pages( array(
                                    'before'      => '<div class="page-links"><span class="page-links-title">' . __( 'Pages:', 'osum' ) . '</span>',
                                    'after'       => '</div>',
                                    'link_before' => '<span>',
                                    'link_after'  => '</span>',
                                    'pagelink'    => '<span class="screen-reader-text">' . __( 'Page', 'osum' ) . ' </span>%',
                                    'separator'   => '<span class="screen-reader-text">, </span>',
                                ) );
                            ?>
                        </div>
                    </div>
                </div>
            </div>
			<?php
		//}
	?>
</article><!-- #post-## -->