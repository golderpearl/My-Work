<?php
function osum_post_thumbnail_html($html, $post_id, $post_thumbnail_id, $size, $attr) {
    $src = wp_get_attachment_image_src(get_post_thumbnail_id(), $size);
    $html = '<img src="" alt="" data-src="' . $src['0'] . '" data-alt="" class="post-thumbnail" />';
    return $html;
}
add_filter('post_thumbnail_html', 'osum_post_thumbnail_html', 99, 5);
?>