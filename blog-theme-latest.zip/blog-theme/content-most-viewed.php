<?php 
	$post_metadata = get_post_meta($post->ID,'osum_meta_key',true);
	$osum_post_options = isset($post_metadata['osum_post_options'])? $post_metadata['osum_post_options'] : '';

?>
<div id="post-<?php the_ID(); ?>" <?php post_class('item'); ?>>
    <div class="post-thumb">
    	<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('size-370x226');?></a>
        <?php if($osum_post_options == 'video_url'):?>
            <a class="play" href="#">
                <img alt="" src="<?php echo get_template_directory_uri();?>/assets/images/play.png">
            </a>
        <?php endif; ?>
    </div>
    <div class="post-details">
        <div class="post-options">
            <ul>
                <li>
                    <?php echo get_the_date( 'M d, Y' ); ?>
                </li>
                <li><i class="fa fa-eye"></i><?php echo getPostViews(get_the_ID()); ?></li>
            </ul>
        </div>                                 
        <h3 class="post-title"><a href="<?php the_permalink(); ?>"><?php echo substr(get_the_title(),0,50 ); ?></a></h3>
        <a class="readmore_btn" href="<?php the_permalink(); ?>">read more <i class="lnr lnr-chevron-right"></i><i class="lnr lnr-chevron-right"></i></a>
        <?php //echo osum_read_more(); ?>
    </div>
</div>