<?php
/**
 * The default template for displaying content
 *
 * Used for both single and index/archive/search.
 *
 */
 	global $post;
 	$post_metadata = get_post_meta($post->ID,'osum_meta_key',true);
	$osum_post_options = isset($post_metadata['post_options']) ? $post_metadata['post_options'] : 'image';
    $osum_audio_url     = isset($post_metadata['audio_url']) ? $post_metadata['audio_url'] : '';
    $osum_video_url     = isset($post_metadata['video_url']) ? $post_metadata['video_url'] : '';
    $osum_post_gallery  = isset($post_metadata['post_gallery']) ? $post_metadata['post_gallery'] : '';

    $osum_post_options = isset($post_metadata['osum_post_options'])? $post_metadata['osum_post_options'] : '';
    $osum_post_gallery = isset($post_metadata['osum_post_gallery'])? $post_metadata['osum_post_gallery'] : '';;
	

?>
<?php if(is_single()) { ?>
    <article id="post-<?php the_ID(); ?>" <?php post_class('item'); ?>>
        <?php
			if($osum_post_options == 'audio'){
                echo '<figure><iframe width="100%" height="450" scrolling="no" frameborder="no" src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/'.$osum_audio_url.'&amp;auto_play=false&amp;hide_related=false&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false&amp;visual=true"></iframe></figure>';
            }elseif($osum_post_options == 'video'){
                $osum_video_url = isset($post_metadata['osum_video_url'])? $post_metadata['osum_video_url'] : '';
                $video  = wp_oembed_get($osum_video_url);
                echo '<div class="blog-video">'.$video.'</div>';
            }elseif($osum_post_options == 'slider'){
                echo $slider =  fw()->extensions->get('slider')->render_slider($osum_post_gallery, array('width'  =>'1170','height' => '530'));
            }else{
				osum_post_thumbnail('size-1170x484');
			}
			the_title( '<h2 class="page-title">', '</h2>' );
		?>
        <div class="post-options">
            <div class="category-section">
				<?php osum_post_meta(); ?>
           	</div>
            <div class="social-sharing">
                <ul>    
                	<li class="facebook">
                    	<a href="https://www.facebook.com/sharer.php?u=<?php the_permalink(); ?>" class="post_share_facebook" onclick="javascript:window.open(this.href,
					      '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=220,width=600');return false;">
                          <i class="icon icon-facebook"></i>
                        </a>
                     </li>
					<li class="twitter">
                    	<a href="https://twitter.com/share?url=<?php the_permalink(); ?>&text=<?php echo urlencode(get_the_title()); ?>" onclick="javascript:window.open(this.href,
					      '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=260,width=600');return false;" class="product_share_twitter">
                          <i class="icon icon-twitter"></i>
                        </a>
					</li>
                    <li class="googleplus">
                    	<a href="https://plus.google.com/share?url=<?php the_permalink(); ?>" onclick="javascript:window.open(this.href,
					      '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;">
                          <i class="icon icon-google-plus"></i>
                         </a></li>
					    <li class="pinterest"><a href="https://pinterest.com/pin/create/button/?url=<?php the_permalink(); ?>&media=<?php if(function_exists('the_post_thumbnail')) echo wp_get_attachment_url(get_post_thumbnail_id()); ?>&description=<?php echo get_the_title(); ?>" onclick="javascript:window.open(this.href,
					      '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=320,width=600');return false;"><i class="fa-pinterest"></i><i class="fa-pinterest"></i></a></li>
                        <li class="linkedin">
                        	<a href="http://www.linkedin.com/shareArticle?mini=true&url=<?php the_permalink(); ?>&title=<?php echo get_the_title(); ?>&summary=<?php echo strip_tags(substr(get_the_excerpt(),'25')); ?>" onclick="javascript:window.open(this.href,
                                                  '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=320,width=600');return false;">
                             <i class="icon icon-linkedin"></i>
                            </a>
                         </li>
                </ul>
            </div>
        </div>
        <div class="post-text">
            <?php
                /* translators: %s: Name of current post */
                the_content( sprintf(
                    __( 'Continue reading %s', 'osum' ),
                    the_title( '<span class="screen-reader-text">', '</span>', false )
                ) );
                wp_link_pages( array(
                    'before'      => '<div class="page-links"><span class="page-links-title">' . __( 'Pages:', 'osum' ) . '</span>',
                    'after'       => '</div>',
                    'link_before' => '<span>',
                    'link_after'  => '</span>',
                    'pagelink'    => '<span class="screen-reader-text">' . __( 'Page', 'osum' ) . ' </span>%',
                    'separator'   => '<span class="screen-reader-text">, </span>',
                ) );
            ?>
        </div>
    </article>
<?php }else{ ?>
    <article id="post-<?php the_ID(); ?>" <?php post_class('item'); ?>>
        <figure>
            <?php
                $osum_post_class =  'default-post';
                if($osum_post_options == 'audio'){
                    echo '<figure><iframe width="100%" height="450" scrolling="no" frameborder="no" src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/'.$osum_audio_url.'&amp;auto_play=false&amp;hide_related=false&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false&amp;visual=true"></iframe></figure>';
                }elseif($osum_post_options == 'video'){
                    $osum_video_url = isset($post_metadata['osum_video_url'])? $post_metadata['osum_video_url'] : '';
                    $video  = wp_oembed_get($osum_video_url);
                    echo '<div class="blog-video">'.$video.'</div>';
                }elseif($osum_post_options == 'slider'){
                    echo $slider =  fw()->extensions->get('slider')->render_slider($osum_post_gallery, array('width'  =>'1170','height' => '530'));
                }else{
                    echo '<div class="post-thumb">';
                    
                    if(has_post_thumbnail($post->ID)):
                        
                        osum_post_thumbnail('size-200x150');
                    else:
                    $osum_post_class = 'full-post';
                    // echo osum_author_meta();

                    endif;
                    echo '</div>';
                }
            ?>
        </figure>
        <div class="post-summary <?php echo $osum_post_class; ?>">
            <div class="date"><?php echo get_the_date( 'M d, Y' ); ?></div>
            <?php the_title( sprintf( '<h3 class="post-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h3>' ); ?>
            <a class="readmore_btn" href="<?php the_permalink(); ?>">read more <i class="lnr lnr-chevron-right"></i><i class="lnr lnr-chevron-right"></i></a>
            <?php  
                // if(!post_password_required()){
                //     echo '<a href="'.get_the_permalink().'" class="readmore-btn">'.__('Read more','osum').'</a>'; 
                //     wp_link_pages( array(
                //         'before'      => '<div class="page-links"><span class="page-links-title">' . __( 'Pages:', 'osum' ) . '</span>',
                //         'after'       => '</div>',
                //         'link_before' => '<span>',
                //         'link_after'  => '</span>',
                //         'pagelink'    => '<span class="screen-reader-text">' . __( 'Page', 'osum' ) . ' </span>%',
                //         'separator'   => '<span class="screen-reader-text">, </span>',
                //     ) );
                // }
            ?>
        </div>
    </article>
<?php } ?>