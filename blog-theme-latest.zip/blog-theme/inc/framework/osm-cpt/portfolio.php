<?php
/**
* @ Register Post Type Portfolio
*/
	$portfolio_permalinks = get_option( 'sf_portfolio_permalinks' );
	
	$args = array(
	    "label" 						=> __('Portfolio Categories', "osum"), 
	    "singular_label" 				=> __('Portfolio Category', "osum"), 
	    'public'                        => true,
	    'hierarchical'                  => true,
	    'show_ui'                       => true,
	    'show_in_nav_menus'             => false,
	    'args'                          => array( 'orderby' => 'term_order' ),
		'rewrite' 						=> array(
					    					'slug'         => empty( $portfolio_permalinks['category_base'] ) ? __( 'portfolio-category', 'osum' ) : $portfolio_permalinks['category_base'],
					    					'with_front'   => false,
					    					'hierarchical' => true,
					    	            ),
	    'query_var'                     => true
	);
	
	register_taxonomy( 'portfolio-category', 'portfolio', $args );
	
	    
	add_action('init', 'portfolio_register');  
	  
	function portfolio_register() {
		
		$portfolio_permalinks = get_option( 'sf_portfolio_permalinks' );
		
		$portfolio_permalink = empty( $portfolio_permalinks['portfolio_base'] ) ? __( 'portfolio', 'osum' ) : $portfolio_permalinks['portfolio_base'];
		
	    $labels = array(
	        'name' => __('Portfolio', "osum"),
	        'singular_name' => __('Portfolio Item', "osum"),
	        'add_new' => __('Add New', "osum"),
	        'add_new_item' => __('Add New Portfolio Item', "osum"),
	        'edit_item' => __('Edit Portfolio Item', "osum"),
	        'new_item' => __('New Portfolio Item', "osum"),
	        'view_item' => __('View Portfolio Item', "osum"),
	        'search_items' => __('Search Portfolio', "osum"),
	        'not_found' =>  __('No portfolio items have been added yet', "osum"),
	        'not_found_in_trash' => __('Nothing found in Trash', "osum"),
	        'parent_item_colon' => ''
	    );
			
	    $args = array(  
	        'labels' => $labels,  
	        'public' => true,  
	        'show_ui' => true,
	        'show_in_menu' => true,
	        'show_in_nav_menus' => false,
	        'menu_icon' => 'dashicons-format-image',
	        'hierarchical' => false,
	        'rewrite' => $portfolio_permalink != "portfolio" ? array(
	        				'slug' => untrailingslashit( $portfolio_permalink ),
	        				'with_front' => false,
	        				'feeds' => true )
	        			: false,
	        'supports' => array('title', 'editor',),
	        'has_archive' => true,
	        'taxonomies' => array('portfolio-category')
	       );  
	  
	    register_post_type( 'portfolio' , $args );  
	}  
	
	add_filter("manage_edit-portfolio_columns", "portfolio_edit_columns");   
	  
	function portfolio_edit_columns($columns){  
	        $columns = array(  
	            "cb" => "<input type=\"checkbox\" />",  
	            "thumbnail" => "",
	            "title" => __("Portfolio Item", "osum"),
	            "description" => __("Description", "osum"),
	            "portfolio-category" => __("Categories", "osum") 
	        );  
	  
	        return $columns;  
	}

?>