<?php

/** 
 * @Mailchimp List
 */
if ( ! function_exists( 'osum_mailchimp_list' ) ) {
	function osum_mailchimp_list($apikey){
		$mailchimp_list = '';
		if($apikey <> ''){
			$MailChimp = new MailChimp($apikey);
			$mailchimp_list = $MailChimp->call('lists/list');
		}
		return $mailchimp_list;
	}
}
/** 
 * @custom mail chimp form
 */
if ( ! function_exists( 'osum_mailchimp' ) ) {
	function osum_mailchimp(){
		global $osum_options;
		$counter = rand(423,23343490);
		$newsletter_title       = (isset($osum_options['newsletter_title']) and $osum_options['newsletter_title'] <> '') ? $osum_options['newsletter_title'] : '';
    $newsletter_text       = (isset($osum_options['newsletter_text']) and $osum_options['newsletter_text'] <> '') ? $osum_options['newsletter_text'] : '';
 		?>
        
        <div class="newsletter">
             	<div class="title">
					       <h2><?php echo $newsletter_title; ?></h2>
				          <p><?php echo $newsletter_text; ?></p>
              </div>
              <form action="javascript:osum_mc('<?php echo get_template_directory_uri()?>','<?php echo esc_js($counter); ?>','<?php echo admin_url('admin-ajax.php'); ?>')" id="mcform_<?php echo intval($counter);?>" method="post">
                  <div id="newsletter_mess_<?php echo intval($counter);?>" style="display:none" class="osm-status"></div>
                    <input id="osum_listid" type="hidden" name="osum_listid" value="<?php if(isset($osum_options['mc_list'])){ echo esc_attr($osum_options['mc_list']); }?>" />
                      <input id="mc_email" type="text" name="mc_email" value="<?php _e('Enter Email Address','osum'); ?>" onblur="if(this.value == '') { this.value ='<?php _e('Enter Email Address','osum'); ?>'; }" onfocus="if(this.value =='<?php _e('Enter Email Address','osum'); ?>') { this.value = ''; }"  />
                    
                   		<input type="submit" id="btn_newsletter_<?php echo intval($counter);?>" name="submit" value="<?php _e('Subscribe','osum'); ?>"  />
                    	<div id="process_<?php echo intval($counter);?>" class="osum-loader"></div>
                  
              </form>
 	</div>
        <?php
        
		$counter++;
	}
}
/** 
 * @custom mail chimp form
 */
if ( ! function_exists( 'osum_mcpopup' ) ) {
	function osum_mcpopup(){
		global $osum_options;
		$counter = rand(423,23343490);
		
 		?>
		<div class="newsletter-popup" id="welcome_popup">
            <div class="popup-inner-section">
                <a href="#" class="close-newsletter"><i class="lnr lnr-cross"></i></a>
                <div class="title-page">
                    <h1>Realistic<span>Media</span></h1>
                </div>
                <div class="newsletter-desc">
                    <h2>Join our newsletter to get daily updates around the world</h2>
                </div>
              	<form action="javascript:osum_mc('<?php echo get_template_directory_uri()?>','<?php echo esc_js($counter); ?>','<?php echo admin_url('admin-ajax.php'); ?>')" id="mcform_<?php echo intval($counter);?>" method="post">
                  	<div id="newsletter_mess_<?php echo intval($counter);?>" style="display:none" class="osm-status"></div>
                     	<input id="osum_listid" type="hidden" name="osum_listid" value="<?php if(isset($osum_options['mc_list'])){ echo esc_attr($osum_options['mc_list']); }?>" />
						<input id="mc_email" type="email" name="mc_email" value="<?php _e('Enter Email Address','osum'); ?>" onblur="if(this.value == '') { this.value ='<?php _e('Signup weekly newsletter','osum'); ?>'; }" onfocus="if(this.value =='<?php _e('Signup weekly newsletter','osum'); ?>') { this.value = ''; }"  />
                    	<label for="">
                        	<input type="submit" id="btn_newsletter_<?php echo intval($counter);?>" name="submit" value="<?php _e('Subscribe now','osum'); ?>">
                        	<i class="lnr lnr-arrow-right"></i>
                    	</label>
                    	<div id="process_<?php echo intval($counter);?>" class="osum-loader"></div>
                </form>
                <p>Don’t worry we will never share your email address </p>
            </div>
		</div>
        
        <?php
        
		$counter++;
	}
}