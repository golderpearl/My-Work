<?php

class social_networking extends WP_Widget {
	// constructor
	function social_networking() {
		// constructor
	        //parent::WP_Widget(false, $name = __('Fatafo: Photo Widget', 'osumthemes') );
	        $widget_ops = array('classname' => 'social-networking', 'description' => __( 'Social Profiles.', 'osumthemes' ) );
            $this->WP_Widget('social_networking', 'OSUM - ' . __( 'Fatafo: Social Profiles Widget', 'osumthemes' ), $widget_ops);
	}

	// widget form creation
	function form($instance) {
		$instance = wp_parse_args( (array) $instance, $defaults );
		// Check values
		if( $instance) {
		    $title = esc_attr($instance['title']);
		    $facebook = esc_attr($instance['facebook']);
		    $google_plus = esc_attr($instance['google_plus']);
		    $linkedin = esc_attr($instance['linkedin']);
		    $twitter = esc_attr($instance['twitter']);
		    $instagram = esc_attr($instance['instagram']);
		    $pinterest = esc_attr($instance['pinterest']);
		} else {
		    $title = '';
		    $facebook = '';
		    $google_plus = '';
		    $linkedin = '';
		    $twitter = '';
		    $instagram = '';
		    $pinterest = '';
		}
		?>
		<p>
			<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Widget Title', 'osumthemes'); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" />
		</p>



		<p>

			<label for="<?php echo $this->get_field_id('facebook'); ?>"><?php _e('Facebook:', 'osumthemes'); ?></label>

			<input class="widefat" id="<?php echo $this->get_field_id('facebook'); ?>" name="<?php echo $this->get_field_name('facebook'); ?>" type="text" value="<?php echo $facebook; ?>" />

		</p>



		<p>

			<label for="<?php echo $this->get_field_id('google_plus'); ?>"><?php _e('Google Plus:', 'osumthemes'); ?></label>

			<input class="widefat" id="<?php echo $this->get_field_id('google_plus'); ?>" name="<?php echo $this->get_field_name('google_plus'); ?>" type="text" value="<?php echo $google_plus; ?>" />

		</p>



		<p>

			<label for="<?php echo $this->get_field_id('linkedin'); ?>"><?php _e('Linkedin:', 'osumthemes'); ?></label>

			<input class="widefat" id="<?php echo $this->get_field_id('linkedin'); ?>" name="<?php echo $this->get_field_name('linkedin'); ?>" type="text" value="<?php echo $linkedin; ?>" />

		</p>



		<p>

			<label for="<?php echo $this->get_field_id('twitter'); ?>"><?php _e('Twitter:', 'osumthemes'); ?></label>

			<input class="widefat" id="<?php echo $this->get_field_id('twitter'); ?>" name="<?php echo $this->get_field_name('twitter'); ?>" type="text" value="<?php echo $twitter; ?>" />

		</p>



		<p>

			<label for="<?php echo $this->get_field_id('instagram'); ?>"><?php _e('Instagram:', 'osumthemes'); ?></label>

			<input class="widefat" id="<?php echo $this->get_field_id('instagram'); ?>" name="<?php echo $this->get_field_name('instagram'); ?>" type="text" value="<?php echo $instagram; ?>" />

		</p>



		<p>

			<label for="<?php echo $this->get_field_id('pinterest'); ?>"><?php _e('Pinterest:', 'osumthemes'); ?></label>

			<input class="widefat" id="<?php echo $this->get_field_id('pinterest'); ?>" name="<?php echo $this->get_field_name('pinterest'); ?>" type="text" value="<?php echo $pinterest; ?>" />

		</p>

	<?php

	}



	// update widget

	function update($new_instance, $old_instance) {

	      $instance = $old_instance;

	      // Fields

	      $instance['title'] = strip_tags($new_instance['title']);

	      $instance['facebook'] = strip_tags($new_instance['facebook']);

	      $instance['google_plus'] = strip_tags($new_instance['google_plus']);

	      $instance['linkedin'] = strip_tags($new_instance['linkedin']);

	      $instance['twitter'] = strip_tags($new_instance['twitter']);

	      $instance['instagram'] = strip_tags($new_instance['instagram']);

	      $instance['pinterest'] = strip_tags($new_instance['pinterest']);

	     return $instance;

	}



	// display widget

	function widget($args, $instance) {

		// these are the widget options

		$title = apply_filters('widget_title', $instance['title']);

		$facebook = $instance['facebook'];

		$google_plus = $instance['google_plus'];

		$linkedin = $instance['linkedin'];

		$twitter = $instance['twitter'];

		$instagram = $instance['instagram'];

		$pinterest = $instance['pinterest'];



		extract($args, EXTR_SKIP);



		echo $before_widget;

		// Display the widget



	   	// Check if title is set

	   	if ( $title ) {

	      	echo $before_title . $title . $after_title;

	   	}



	   	echo '<ul>';



	   	// Check if text is set

	   	if( $facebook ) {

	      	echo '<li><a target="_blank" href="'.$facebook.'"><i class="fa fa-facebook"></i></a></li>';

	   	}

	   	if( $google_plus ) {

	      	echo '<li><a target="_blank" href="'.$google_plus.'"><i class="fa fa-google-plus"></i></a></li>';

	   	}

	   	if( $linkedin ) {

	      	echo '<li><a target="_blank" href="'.$linkedin.'"><i class="fa fa-linkedin"></i></a></li>';

	   	}

	   	if( $twitter ) {

	      	echo '<li><a target="_blank" href="'.$twitter.'"><i class="fa fa-twitter"></i></a></li>';

	   	}

	   	if( $instagram ) {

	      	echo '<li><a target="_blank" href="'.$instagram.'"><i class="fa fa-instagram"></i></a></li>';

	   	}

	   	if( $pinterest ) {

	      	echo '<li><a target="_blank" href="'.$pinterest.'"><i class="fa fa-pinterest"></i></a></li>';

	   	}



	   	echo '</ul>';

	   	echo $after_widget;

	}

}



// register widget

add_action('widgets_init', create_function('', 'return register_widget("social_networking");'));