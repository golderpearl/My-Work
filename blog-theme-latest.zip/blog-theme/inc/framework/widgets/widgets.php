<?php

include 'author_wgt.php';
include 'contactus_wgt.php';
include 'recentpost_wgt.php';
include 'instagram_wgt.php';
//include 'author_profile_wdgt.php';
//include 'subscriber_wgt.php';
//include 'tabpost_wgt.php';
//include 'recentvideos_wgt.php';
//include 'recentphotos_wgt.php';
//include 'recentpost_wgt.php';
//include 'twitter_wgt.php';
//include 'social_wgt.php';

add_action( 'widgets_init', 'osum_register_widgets' ); // function to load my widget
function osum_register_widgets() {

	register_widget( 'author_wgt' );
	register_widget( 'recentpost_wgt' );
	register_widget( 'instagram_wgt' );
	register_widget( 'contactus_wgt' );
	//register_widget( 'author_profile_wdgt' );
	//register_widget( 'subscriber_wgt' );
	//register_widget( 'recentvideos_wgt' );
	//register_widget( 'recentphotos_wgt' );
	//register_widget( 'tabpost_wgt' );
	//register_widget( 'twitter_wgt' );
	//register_widget( 'social_wgt' );

}