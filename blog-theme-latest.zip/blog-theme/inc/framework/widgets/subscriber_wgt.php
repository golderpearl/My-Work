<?php

	class subscriber_wgt extends WP_Widget{
	    function subscriber_wgt() {
			$widget_ops = array( 'classname' => 'widget_newsletter', 'description' => __('A widget for newsletter subscribe', 'osum') );
			$control_ops = array( 'width' => 300, 'height' => 350, 'id_base' => ' widget_newsletter' );
			$this->__construct( 'subscriber-widget', __('Subscriber Widget', 'osum'), $widget_ops, $control_ops );
    	}
		function widget( $args, $instance ){
			global $osum_options;
			$counter = rand(423,23343490);
			extract( $args );
			$title = apply_filters('widget_title', $instance['title'] );
			$description 	= $instance['description'];
			echo $before_widget;
 
			// Display the widget title 
			if ( $title )
				$title = '<h3 class="widget-title">'.$title.'</h3>';
				//echo $before_title . $title . $after_title;
			?>
				<div class="newsletter">
					<p><?php echo $description; ?></p>
					<form action="javascript:osum_mc('<?php echo get_template_directory_uri()?>','<?php echo esc_js($counter); ?>','<?php echo admin_url('admin-ajax.php'); ?>')" id="mcform_<?php echo intval($counter);?>" method="post">
						<div id="newsletter_mess_<?php echo intval($counter);?>" style="display:none"></div>
						<input id="osum_listid" type="hidden" name="osum_listid" value="<?php if(isset($osum_options['mc_list'])){ echo esc_attr($osum_options['mc_list']); }?>" />
						<input type="text" onblur="if (this.value == '') (this.value='Enter Email Address')" onfocus="if(this.value == '') { this.value ='<?php _e('Enter Email Address','osum'); ?>'; }" value="<?php _e('Enter Email Address','osum'); ?>" id="mc_email" name="mc_email">
						<input type="submit" id="btn_newsletter_<?php echo intval($counter);?>" value="<?php _e('Subscribe','osum'); ?>">
						<div id="process_<?php echo intval($counter);?>"></div>
					</form>
				</div>
              <?php
				 
			//Display the name 
			 
			echo $after_widget;
		}
		function update( $new_instance, $old_instance ) {
			$instance = $old_instance;

			//Strip tags from title and name to remove HTML
			$instance['title'] 	= strip_tags( $new_instance['title'] );
			$instance['description'] = strip_tags( $new_instance['description'] );
			return $instance;
		}
				/* Widget settings */
		function form( $instance ) {
			//Set up some default widget settings.
			$defaults = array( 'title' => '', 'description' => '' );
			$instance = wp_parse_args( (array) $instance, $defaults );
			?>
            <p>
				<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e('Title:', 'osum'); ?></label>
				<input id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" type="text" style="width:100%;" />
			</p>            
 			<p>
				<label for="<?php echo $this->get_field_id( 'description' ); ?>"><?php _e('Description:', 'osum'); ?></label>
                <textarea id="<?php echo $this->get_field_id( 'description' ); ?>" name="<?php echo $this->get_field_name( 'description' ); ?>" style="width:100%;"  ><?php echo $instance['description']; ?></textarea>
			</p>
            <?php
		
		
		}
	} 

?>