<?php
	class recentphotos_wgt extends WP_Widget{
	    function recentphotos_wgt() {
			$widget_ops = array( 'classname' => 'featured_photos', 'description' => __('A widget that displays the latest gallery posts ', 'osum') );
			$control_ops = array( 'width' => 300, 'height' => 350, 'id_base' => 'recentphotos-widget' );
			$this->__construct( 'recentphotos-widget', __('Latest Gallery Posts Widget', 'osum'), $widget_ops, $control_ops );
    	}
		function widget( $args, $instance ){
			global $post;
			extract( $args );
			$title = apply_filters('widget_title', $instance['title'] );
			 $postcount 	= (int)$instance['postcount'];
			echo $before_widget;
 			echo '<div class="featured-video search-listing ">';
			// Display the widget title 
			if ( $title )
				echo $before_title . $title . $after_title;
				wp_reset_postdata();
				$query = array( 'post_type' => 'post','posts_per_page' => $postcount,'meta_key' => 'osum_post_options', 'meta_value' => 'slider','ignore_sticky_posts' => 1,'order'=>'ASC' );
				$osum_query = new WP_Query( $query );
				$postcounter = 0;
				if ( $osum_query->have_posts() ) : 
				// Start the loop.
					while (  $osum_query->have_posts() ) :  $osum_query->the_post();
					$osum_view_count = get_post_meta($post->ID,'osum_view_count',true);
					if($postcounter == 0){
						
						?>
						<article>
							<?php 
								if(has_post_thumbnail()):
									echo '<figure>';
										echo the_post_thumbnail(array(280,280),true);
										echo '<a class="cat pink" href="#">Videos</a>';
										echo '</figure>';
								endif;
							?>
										<div class="video-details">
											<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
											<div class="video-options">
										<ul>
											<li><i class="icon icon-play2"></i><span>Date :</span> <?php echo get_the_date('m:n:y'); ?></li>
											<li><i class="icon icon-eye"></i><span>Views:</span> <?php echo $osum_view_count; ?></li>
										</ul>
									</div>
										</div>
									</article>
						<?php
					}else{
						?>
						<article class="post">
							<?php 
								if(has_post_thumbnail()):
									echo '<figure>';
										echo the_post_thumbnail(array(81,81),true);
										echo '</figure>';
								endif;
							?>
										<div class="text-details">
											<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
											<div class="video-options">
										<ul>
											<li><i class="icon icon-play2"></i><span>Date :</span> <?php echo get_the_date('m:n:y'); ?></li>
											<li><i class="icon icon-eye"></i><span>Views:</span> <?php echo $osum_view_count; ?></li>
										</ul>
									</div>
										</div>
									</article>
						<?php 
					}
					// End the loop.
					$postcounter++;
					endwhile;
					wp_reset_postdata();
		  		else :
			 		 get_template_part( 'content', 'none' );
		 		endif;	
				echo '</div>';		
			echo $after_widget;
		}
		function update( $new_instance, $old_instance ) {
			$instance = $old_instance;
		 
			//Strip tags from title and name to remove HTML
			$instance['title'] 	= strip_tags( $new_instance['title'] );
			$instance['postcount'] = strip_tags( $new_instance['postcount'] );
			
			return $instance;
		}
		/* Widget settings */
		function form( $instance ) {
			//Set up some default widget settings.
			$defaults = array( 'title' => '','postcount' => '3' );
			$instance = wp_parse_args( (array) $instance, $defaults );
			?>
            <p>
				<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e('Title:', 'osum'); ?></label>
				<input id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" type="text" style="width:100%;" />
			</p>
 			
            <p>
				<label for="<?php echo $this->get_field_id( 'postcount' ); ?>"><?php _e('Show Posts:', 'osum'); ?></label>
				<input id="<?php echo $this->get_field_id( 'postcount' ); ?>" name="<?php echo $this->get_field_name( 'postcount' ); ?>" value="<?php echo absint($instance['postcount']); ?>" type="text"style="width:100%;" />
			</p> 
  			
            <?php
		
		
		}
	} 

?>