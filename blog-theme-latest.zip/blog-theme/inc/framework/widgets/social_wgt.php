<?php

	class social_wgt extends WP_Widget{
	    function social_wgt() {
			$widget_ops = array( 'classname' => 'social-network', 'description' => __('A widget that displays the contact information ', 'osum') );
			$control_ops = array( 'width' => 300, 'height' => 350, 'id_base' => 'example-widget' );
			$this->__construct( 'example-widget', __('Social Profiles Widget', 'osum'), $widget_ops, $control_ops );
    	}
		function widget( $args, $instance ){
			extract( $args );
			
			// these are the widget options
			$title = apply_filters('widget_title', $instance['title']);
			$facebook = $instance['facebook'];
			$google_plus = $instance['google_plus'];
			$linkedin = $instance['linkedin'];
			$twitter = $instance['twitter'];
			$instagram = $instance['instagram'];
			$pinterest = $instance['pinterest'];
			echo $before_widget;

			// Display the widget title 
			if ( $title )
				echo $before_title . $title . $after_title;
			echo '<ul>';
			   	// Check if text is set
			   	if( !$facebook == '' ) {
			      	echo '<li><a target="_blank" href="'.$instance['facebook'].'"><i class="fa fa-facebook"></i></a></li>';
			   	}
			   	if( $google_plus ) {
			      	echo '<li><a target="_blank" href="'.$instance['google_plus'].'"><i class="fa fa-google-plus"></i></a></li>';
			   	}
			   	if( $linkedin ) {
			      	echo '<li><a target="_blank" href="'.$linkedin.'"><i class="fa fa-linkedin"></i></a></li>';
			   	}
			   	if( $twitter ) {
			      	echo '<li><a target="_blank" href="'.$twitter.'"><i class="fa fa-twitter"></i></a></li>';
			   	}
			   	if( $instagram ) {
			      	echo '<li><a target="_blank" href="'.$instagram.'"><i class="fa fa-instagram"></i></a></li>';
			   	}
			   	if( $pinterest ) {
			      	echo '<li><a target="_blank" href="'.$pinterest.'"><i class="fa fa-pinterest"></i></a></li>';
			   	}
		   	echo '</ul>';
				 
			echo $after_widget;
		}
		function update( $new_instance, $old_instance ) {
			$instance = $old_instance;
		 	
			//Strip tags from title and name to remove HTML
			$instance['title'] = strip_tags($new_instance['title']);
			$instance['facebook'] = strip_tags($new_instance['facebook']);
			$instance['google_plus'] = strip_tags($new_instance['google_plus']);
			$instance['linkedin'] = strip_tags($new_instance['linkedin']);
			$instance['twitter'] = strip_tags($new_instance['twitter']);
			$instance['instagram'] = strip_tags($new_instance['instagram']);
			$instance['pinterest'] = strip_tags($new_instance['pinterest']);

			return $instance;
		}
		function form( $instance ) {
			//Set up some default widget settings.
			// Check values
			/*if( $instance) {
			    $title = esc_attr($instance['title']);
			    $facebook = esc_attr($instance['facebook']);
			    $google_plus = esc_attr($instance['google_plus']);
			    $linkedin = esc_attr($instance['linkedin']);
			    $twitter = esc_attr($instance['twitter']);
			    $instagram = esc_attr($instance['instagram']);
			    $pinterest = esc_attr($instance['pinterest']);
			}
			else {
			    $title = '';
			    $facebook = '';
			    $google_plus = '';
			    $linkedin = '';
			    $twitter = '';
			    $instagram = '';
			    $pinterest = '';
			}*/

			$defaults = array( 'title' => 'Follow Us', 'facebook' => 'http://facebook.com/', 'twitter' => 'http://twitter.com/', 'google_plus' => 'http://plus.google.com/', 'instagram' => 'http://instagram.com/', 'pinterest' => 'http://pinterest.com/', 'linkedin' => 'http://linkedin.com/' );
			$instance = wp_parse_args( (array) $instance, $defaults );

			echo "<pre>";
			var_dump($instance);
			echo "</pre>";
			?>
            <p>
				<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Widget Title', 'osumthemes'); ?></label>
				<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $instance['title']; ?>" />
			</p>
			<p>
				<label for="<?php echo $this->get_field_id('facebook'); ?>"><?php _e('Facebook:', 'osumthemes'); ?></label>
				<input class="widefat" id="<?php echo $this->get_field_id('facebook'); ?>" name="<?php echo $this->get_field_name('facebook'); ?>" type="text" value="<?php echo $instance['facebook']; ?>" />
			</p>
			<p>
				<label for="<?php echo $this->get_field_id('google_plus'); ?>"><?php _e('Google Plus:', 'osumthemes'); ?></label>
				<input class="widefat" id="<?php echo $this->get_field_id('google_plus'); ?>" name="<?php echo $this->get_field_name('google_plus'); ?>" type="text" value="<?php echo $instance['google_plus']; ?>" />
			</p>
			<p>
				<label for="<?php echo $this->get_field_id('linkedin'); ?>"><?php _e('Linkedin:', 'osumthemes'); ?></label>
				<input class="widefat" id="<?php echo $this->get_field_id('linkedin'); ?>" name="<?php echo $this->get_field_name('linkedin'); ?>" type="text" value="<?php echo $instance['linkedin']; ?>" />
			</p>
			<p>
				<label for="<?php echo $this->get_field_id('twitter'); ?>"><?php _e('Twitter:', 'osumthemes'); ?></label>
				<input class="widefat" id="<?php echo $this->get_field_id('twitter'); ?>" name="<?php echo $this->get_field_name('twitter'); ?>" type="text" value="<?php echo $instance['twitter']; ?>" />
			</p>
			<p>
				<label for="<?php echo $this->get_field_id('instagram'); ?>"><?php _e('Instagram:', 'osumthemes'); ?></label>
				<input class="widefat" id="<?php echo $this->get_field_id('instagram'); ?>" name="<?php echo $this->get_field_name('instagram'); ?>" type="text" value="<?php echo $instance['instagram']; ?>" />
			</p>
			<p>
				<label for="<?php echo $this->get_field_id('pinterest'); ?>"><?php _e('Pinterest:', 'osumthemes'); ?></label>
				<input class="widefat" id="<?php echo $this->get_field_id('pinterest'); ?>" name="<?php echo $this->get_field_name('pinterest'); ?>" type="text" value="<?php echo $instance['pinterest']; ?>" />
			</p>
            <?php
		}
	}
