<?php
	class twitter_wgt extends WP_Widget{
	    function twitter_wgt() {
			$widget_ops = array( 'classname' => 'widget_twitter', 'description' => __('A widget for latest tweet', 'osum') );
			$control_ops = array( 'width' => 300, 'height' => 350, 'id_base' => 'twitter-widget' );
			$this->__construct( 'twitter-widget', __('Latest tweet', 'osum'), $widget_ops, $control_ops );
    	}
		function widget( $args, $instance ){
			global $osum_options;
			extract( $args );
			$title 	= apply_filters('widget_title', $instance['title'] );
			$username 		= $instance['username'];
			$tweetcount 	= $instance['tweetcount'];
			echo $before_widget;
			require_once get_template_directory() . '/inc/framework/osm-twitter/twitteroauth.php';                    
			$consumerkey = $osum_options['consumer_key'];
			$consumersecret = $osum_options['consumer_secret'];
			$accesstoken = $osum_options['access_token'];
			$accesstokensecret = $osum_options['access_token_secret'];
			$connection = new TwitterOAuth($consumerkey, $consumersecret, $accesstoken, $accesstokensecret);                    
			$tweets = $connection->get("https://api.twitter.com/1.1/statuses/user_timeline.json?screen_name=".$username."&count=".$tweetcount);                    
			
			// Display the widget title 
			if ( $title )
				echo $before_title . $title . $after_title;
				 if(!is_wp_error($tweets) and is_array($tweets)){
                        $rand_id = rand(5, 300);                        
                        $return .= "";
                            foreach($tweets as $tweet) {
                                $text = $tweet->{'text'};
                                foreach($tweet->{'user'} as $type => $userentity) {
                                    if($type == 'profile_image_url') {    
                                        $profile_image_url = $userentity;
                                    } else if($type == 'screen_name'){
                                        $screen_name = '<a href="https://twitter.com/' . $userentity . '" target="_blank" class="colrhover" title="' . $userentity . '">@' . $userentity . '</a>';
                                    }
                                }
                                foreach($tweet->{'entities'} as $type => $entity) {
                                if($type == 'urls') {                        
                                    foreach($entity as $j => $url) {
                                        $display_url = '<a href="' . $url->{'url'} . '" target="_blank" title="' . $url->{'expanded_url'} . '">' . $url->{'display_url'} . '</a>';
                                        $update_with = 'Read more at '.$display_url;
                                        $text = str_replace('Read more at '.$url->{'url'}, '', $text);
                                        $text = str_replace($url->{'url'}, '', $text);
                                    }
                                } else if($type == 'hashtags') {
                                    foreach($entity as $j => $hashtag) {
                                        $update_with = '<a href="https://twitter.com/search?q=%23' . $hashtag->{'text'} . '&amp;src=hash" target="_blank" title="' . $hashtag->{'text'} . '">#' . $hashtag->{'text'} . '</a>';
                                        $hashtag->{'text'};
                                        $text = str_replace('#'.$hashtag->{'text'}, $update_with, $text);
                                    }
                                } else if($type == 'user_mentions') {
                                        foreach($entity as $j => $user) {
                                              $update_with = '<a href="https://twitter.com/' . $user->{'screen_name'} . '" target="_blank" title="' . $user->{'name'} . '">@' . $user->{'screen_name'} . '</a>';
                                              $text = str_replace('@'.$user->{'screen_name'}, $update_with, $text);
                                        }
                                    }
                                } 
                                $large_ts = time();
                                $n = $large_ts - strtotime($tweet->{'created_at'});
                                $return .="<li>";
                                $return .= $text;
                                //$return .= "<p><i class='icon-twitter2'></i><a href='https://twitter.com/" . $username . "'>".$username."</a></p>";
                                $return .= "</li>";
                        }                    
                $return .= "";
                if(isset($profile_image_url) && $profile_image_url <> ''){$profile_image_url = '<div class="osum-logo"><img src="'.$profile_image_url.'" alt=""></div>';} else {$profile_image_url = '';}
                $return .= '';
                echo '<div class="twitter-feeds"><div class="tweets"><ul>'.$return.'</ul></div>';
				echo $profile_image_url;
				echo '</div>';                
         }else{
            if(isset($tweets->errors[0]) && $tweets->errors[0] <> ""){
                echo '<div class="error-msg">'.$tweets->errors[0]->message.". Please enter valid Twitter API Keys </div>";
            }else{
                echo '<div class="error-msg">';
                    cs_fnc_no_result_found(false);
                echo '</div>';
            }
		 }
				
				 
			//Display the name 
			 
			echo $after_widget;
		}
		function update( $new_instance, $old_instance ) {
			$instance = $old_instance;
		 
			//Strip tags from title and name to remove HTML
			$instance['title'] 	= strip_tags( $new_instance['title'] );
			$instance['username'] = strip_tags( $new_instance['username'] );
			$instance['tweetcount'] = strip_tags( $new_instance['tweetcount'] );
			return $instance;
		}
		function form( $instance ) {		
		/* Widget settings */
			//Set up some default widget settings.
			$defaults = array( 'title' => '', 'username' => '','tweetcount' => 1 );
			$instance = wp_parse_args( (array) $instance, $defaults );
			?>
            <p>
				<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e('Title:', 'osum'); ?></label>
				<input id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" type="text" style="width:100%;" />
			</p>            
 			<p>
				<label for="<?php echo $this->get_field_id( 'username' ); ?>"><?php _e('User Name:', 'osum'); ?></label>
                <input id="<?php echo $this->get_field_id( 'username' ); ?>" name="<?php echo $this->get_field_name( 'username' ); ?>" value="<?php echo $instance['username']; ?>" type="text" style="width:100%;" />
			</p>
  			<p>
				<label for="<?php echo $this->get_field_id( 'tweetcount' ); ?>"><?php _e('Show Tweets:', 'osum'); ?></label>
                <input id="<?php echo $this->get_field_id( 'tweetcount' ); ?>" name="<?php echo $this->get_field_name( 'tweetcount' ); ?>" value="<?php echo $instance['tweetcount']; ?>" type="text" style="width:100%;" />
			</p>           <?php
		
		
		
		}
	} 

?>