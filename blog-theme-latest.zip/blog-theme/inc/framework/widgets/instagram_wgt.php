<?php

	class instagram_wgt extends WP_Widget{
	    function instagram_wgt() {
			$widget_ops = array( 'classname' => 'widget_instagram', 'description' => __('A widget that displays instagram images', 'osum') );
			$control_ops = array( 'width' => 300, 'height' => 350, 'id_base' => 'instagram-widget' );
			$this->__construct( 'instagram-widget', __('Instagram Widget', 'osum'), $widget_ops, $control_ops );
    	}
		function widget( $args, $instance ){
			extract( $args );
			$title = apply_filters('widget_title', $instance['title'] );
			$username 		= $instance['username'];
			$images_count	= $instance['images_count'];
			$username = 'osumthemes';
			echo $before_widget;
 
			// Display the widget title 
			if ( $title )
				echo $before_title . $title . $after_title;
			echo '<div class="instagram-photos" ><ul>';
			$refresh_hour = 1;
			$images_number = 6;
			$images_data = instagram_data( 'user', $refresh_hour, $images_number, false );
			if ( is_array( $images_data ) && !empty( $images_data ) ) {
				shuffle( $images_data );
				$output = '';
				foreach ( $images_data as $image_data ) {
					$template_args['link_to'] = 'http://instagram.com/'.$username;
					$template_args['image'] 		= $image_data['url_medium'];
					$template_args['username']      = $username;
					$output .= get_insta_template( 'slider', $template_args );
				}
			}else{
				echo '</ul><div class="error-msg"><p>There is no image in instagram account</p></div>';
			}
			echo $output;
				echo '</ul></div>';
				 
			//Display the name 
			 
			echo $after_widget;
		}
		function update( $new_instance, $old_instance ) {
			$instance = $old_instance;
		 
			//Strip tags from title and name to remove HTML
			$instance['title'] 	= strip_tags( $new_instance['title'] );
			$instance['username'] 	= strip_tags( $new_instance['username'] );
			$instance['images_count'] = strip_tags( $new_instance['images_count'] );
			return $instance;
		}
				/* Widget settings */
		function form( $instance ) {
			//Set up some default widget settings.
			$defaults = array( 'title' => '', 'username' => '','images_count' => '' );
			$instance = wp_parse_args( (array) $instance, $defaults );
			?>
            <p>
				<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e('Title:', 'osum'); ?></label>
				<input id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" type="text" style="width:100%;" />
			</p>            
            <p>
				<label for="<?php echo $this->get_field_id( 'username' ); ?>"><?php _e('Username:', 'osum'); ?></label>
				<input id="<?php echo $this->get_field_id( 'username' ); ?>" name="<?php echo $this->get_field_name( 'username' ); ?>" value="<?php echo $instance['username']; ?>" type="text" style="width:100%;" />
			</p>
 			<p>
				<label for="<?php echo $this->get_field_id( 'images_count' ); ?>"><?php _e('Show Images:', 'osum'); ?></label>
				<input id="<?php echo $this->get_field_id( 'images_count' ); ?>" name="<?php echo $this->get_field_name( 'images_count' ); ?>" value="<?php echo $instance['images_count']; ?>" type="text" style="width:100%;" />
			</p>
            <?php
		}
	} 

?>