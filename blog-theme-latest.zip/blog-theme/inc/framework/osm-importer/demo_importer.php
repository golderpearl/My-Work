<?php
/**
 *
 * @Import XML File For Theme Demo
 */
if ( ! function_exists( 'osum_demo_importer' ) ) {
	function osum_demo_importer(){
	$import = get_option('osum_import_demo');
						
	if(isset($_REQUEST['demo']) && $_REQUEST['demo']=='demo-data'){
		require_once ABSPATH . 'wp-admin/includes/import.php';
 		if ( !defined('WP_LOAD_IMPORTERS') ) define('WP_LOAD_IMPORTERS', true);
			$osum_demoimport_error = false;
 			if ( !class_exists( 'WP_Importer' ) ) {
				$osum_import_class = ABSPATH . 'wp-admin/includes/class-wp-importer.php';
				if ( file_exists( $osum_import_class ) ){
					require_once $osum_import_class;
				}
				else{
					$osum_demoimport_error = true;
				}
			}
		
		if ( !class_exists( 'WP_Import' ) ) {
			$osum_import_class = get_template_directory() . '/inc/framework/osm-importer/wordpress-importer.php';
			if ( file_exists( $osum_import_class ) )
				require_once $osum_import_class;
			else
				$osum_demoimport_error = true;
		}
		
		if($osum_demoimport_error){
 			echo __( 'Error.', 'osum' ) . '</p>';
			die();
		}else{
 			if(!is_file( get_template_directory() . '/inc/framework/osm-importer/demo.xml')){
				echo '<div class="osm-status osm-notice"><p>' . __( 'Sorry, there has been an error.', 'osum' ) . '<br />';
				echo __( 'The file does not exist, please try again.', 'osum' ) . '</p></div>';
			}else{
				if(!get_option('osum_import_demo')){
					update_option('osum_import_demo','success');
	
				$osum_demo_import 				   = new WP_Import();
				$osum_demo_import->fetch_attachments = true;
				$osum_demo_import->import(get_template_directory() . '/inc/framework/osm-importer/demo.xml');
			}else{
				echo '<div class="osm-status osm-notice"><p>'.__('Data already imported,please reset data base and try again.','osum').'</p></div>';
			}
	  }
	}
  }
?>
	<div class="outer-wrap osum-notice">
   		<h2 class="title">Import Dummy Data</h2>
		<div class="inner-content">
			<p>If you want to import dummy data, just need to click on Import Data button.
             If you want to remove demo data,please use wordpress database reset plugin.</p>
		</div>
        <form method="post">
        	<input name="import-data"  type="submit" value="Import Data" id="submit" class="import-btn" />
            <input type="hidden" name="demo" value="demo-data" />
        </form>
	</div>
  <?php
	}
}