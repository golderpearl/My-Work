<?php
 	global $osum_options;
	class osumRegisterSidebar{
 		public function __construct(){
			$this->osum_register_sidebar();

		}
		public function osum_register_sidebar(){
			global $osum_options;
		  	if(isset($osum_options['sidebar_list']) && sizeof($osum_options['sidebar_list']) > 0 && $osum_options['sidebar_list'] <> ''){
			  foreach($osum_options['sidebar_list'] as $sidebar) {
				  register_sidebar( array(
					  'name' =>  $sidebar,
					  'id' => $this->generateSlug($sidebar, 45),
					  'before_widget' => '<aside id="%1$s" class="widget %2$s">',
					  'after_widget' => "</aside>",
					  'before_title' => '<h3 class="widget-title">',
					  'after_title' => '</h3>',
		  
				  ) );
			  }
		  }
		}
		public function generateSlug($phrase, $maxLength){
		  $result = strtolower($phrase);
		
		  $result = preg_replace("/[^a-z0-9\s-]/", "", $result);
		  $result = trim(preg_replace("/[\s-]+/", " ", $result));
		  $result = trim(substr($result, 0, $maxLength));
		  $result = preg_replace("/\s/", "-", $result);
		
		  return $result;
		}	
}
	global $osum_register_sidebar;
	$osum_register_sidebar =  new osumRegisterSidebar();

?>