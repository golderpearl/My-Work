<?php
function osum_post_thumbnail_html($html, $post_id, $post_thumbnail_id, $size, $attr) {
    $id = get_post_thumbnail_id(); // gets the id of the current post_thumbnail (in the loop)
    $src = wp_get_attachment_image_src($id, $size); // gets the image url specific to the passed in size (aka. custom image size)
    $alt = get_the_title($id); // gets the post thumbnail title

        $html = '<img src="' . $src[0] . '" alt="' . $alt . '" class="wp-post-thumbnail" />';
   

    return $html;
}
add_filter('post_thumbnail_html', 'osum_post_thumbnail_html', 99, 5);
add_filter('the_category', 'osum_the_category');
function osum_the_category($cat_list)
{
    return str_ireplace('<a', '<a class="cat"', $cat_list);
}
function add_oembed_soundcloud(){
wp_oembed_add_provider( 'http://soundcloud.com/*', 'http://soundcloud.com/oembed' );
}
add_action('init','add_oembed_soundcloud');?>