<?php global $osum_options; 
function osum_theme_color(){
	global $osum_options; 
	  $theme_color = (isset($osum_options['theme_color']) and $osum_options['theme_color'] <> '') ? $osum_options['theme_color'] : '#000000';
	  $nav_color = (isset($osum_options['nav_color']) and $osum_options['nav_color'] <> '') ? $osum_options['nav_color'] : '#000000';

 ?>
<style type="text/css">
.social-network ul li a:hover, a:hover, .copyrights a, .content-area input[type="text"]:focus, .content-area input[type="email"]:focus, .content-area textarea:focus, .post-summary .post-title > a:hover, .post-details h3.post-title > a:hover, .post-options ul li a:hover, .field-text > input[type="text"]:focus, .field-text > input[type="email"]:focus, .field-textarea > textarea:focus, .contact-info ul li i, .fw-iconbox-image i, .footer-menu ul li a:hover, .logged-in-as > a, .cat_slider .owl-buttons > div:hover, .osm-status {
	color: <?php echo $theme_color; ?>;
}


.content-area ul li input[type="submit"], .osum-submit-btn > input[type="submit"], .newsletter input[type="submit"], .bg-clr {
	background-color: <?php echo $theme_color; ?>;
}


.content-area input[type="text"]:focus, .content-area input[type="email"]:focus, .content-area textarea:focus, .field-text > input[type="text"]:focus,
.field-text > input[type="email"]:focus, .field-textarea > textarea:focus, .content-area ul li input[type="submit"], .osum-submit-btn > input[type="submit"],
.newsletter input[type="submit"], .newsletter input[type="text"]:focus {
	border-color: <?php echo $theme_color; ?>;
}

{
	border-color: transparent <?php echo $theme_color; ?>;
}

/* .cat_menu {
	background-color: <?php echo $nav_color; ?>;
} */
</style>
<?php } ?>