<?php
/**
 * Custom template tags for Twenty Fifteen
 *
 * Eventually, some of the functionality here could be replaced by core features.
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */

if ( ! function_exists( 'osum_comment_nav' ) ) :
/**
 * Display navigation to next/previous comments when applicable.
 *
 * @since Twenty Fifteen 1.0
 */
function osum_comment_nav() {
	// Are there comments to navigate through?
	if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) :
	?>
	<nav class="navigation comment-navigation" role="navigation">
		<h2 class="screen-reader-text"><?php _e( 'Comment navigation', 'osum' ); ?></h2>
		<div class="nav-links">
			<?php
				if ( $prev_link = get_previous_comments_link( __( 'Older Comments', 'osum' ) ) ) :
					printf( '<div class="nav-previous">%s</div>', $prev_link );
				endif;

				if ( $next_link = get_next_comments_link( __( 'Newer Comments', 'osum' ) ) ) :
					printf( '<div class="nav-next">%s</div>', $next_link );
				endif;
			?>
		</div><!-- .nav-links -->
	</nav><!-- .comment-navigation -->
	<?php
	endif;
}
endif;


if ( ! function_exists( 'osum_taglist' ) ) :
	function osum_taglist(){
		$tags_list = get_the_tag_list( '', _x( ' ', 'Used between list items, there is a space after the comma.', 'osum' ) );
			if ( $tags_list ) {
				printf( '<div class="tags">%1$s</div>',	$tags_list
				);
			}
	}
endif;
if ( ! function_exists( 'osum_catlist' ) ) :
	function osum_catlist(){
		$categories_list = get_the_category_list( _x( ', ', 'Used between list items, there is a space after the comma.', 'osum' ) );
			if ( $categories_list ) {
 				echo $categories_list;
			}
	}
endif;
if ( ! function_exists( 'osum_post_meta' ) ) :
/**
 * Prints HTML with meta information for the categories, tags.
 *
 * @since Twenty Fifteen 1.0
 */
function osum_post_meta() {
	if ( is_sticky() && is_home() && ! is_paged() ) {
		printf( '<span class="sticky-post">%s</span>', __( 'Featured', 'osum' ) );
	}

	$format = get_post_format();


		$categories_list = get_the_category_list( _x( ', ', 'Used between list items, there is a space after the comma.', 'osum' ) );
		if ( $categories_list ) {
 				echo $categories_list;
		}

	if ( is_single() && ! post_password_required() && ( comments_open() || get_comments_number() ) ) {
		comments_popup_link( __( 'Leave a comment', 'osum' ), __( '1 Comment', 'osum' ), __( '% Comments', 'osum' ) );
	}
}
endif;

/**
 * Determine whether blog/site has more than one category.
 *

 *
 * @return bool True of there is more than one category, false otherwise.
 */

if ( ! function_exists( 'osum_post_thumbnail' ) ) :
/**
 * Display an optional post thumbnail.
 *
 * Wraps the post thumbnail in an anchor element on index views, or a div
 * element when on single views.
 *
 * @since Twenty Fifteen 1.0
 */
function osum_post_thumbnail( $size = '') {
	global $post;
	if ( post_password_required() || is_attachment() || ! has_post_thumbnail() ) {
		return;
	}
	if ( is_single() ) :
	?>

	<div class="post-thumbnail">
		<?php  the_post_thumbnail($size); ?>
	</div><!-- .post-thumbnail -->
	<?php else : ?>
     		<a class="post-thumbnail" href="<?php the_permalink(); ?>" aria-hidden="true">
			<?php
				the_post_thumbnail( $size, array( 'alt' => get_the_title() ) );
			?>
		</a>
	<?php 
	endif; // End is_singular()
}
endif;
if ( ! function_exists( 'osum_author_meta' ) ) :

function osum_author_meta() {
	global $post;
	?>
    <figure class="no-image">
        <a href="#">
        <img alt="" src="<?php echo get_template_directory_uri(); ?>/assets/images/light-logo.png">
        </a>
        <figcaption>
            <div class="author">
                <div class="thumb-img">
                	<?php echo get_avatar( get_the_author_meta( 'ID' ), 78 ); ?>
                </div>
                <h3>        	
					<?php
                    printf( '<span class="byline">
                    <span class="author vcard"><span class="screen-reader-text">%1ss$s </span>
                    <a class="url fn n" href="%2$s">%3$s</a></span></span>',
                    _e( 'Author:', 'osum' ),
                    esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ),
                    get_the_author()
                    );
                    ?>
                </h3>											
                <p>
				<?php 
					$format = get_post_format();
					if ( current_theme_supports( 'post-formats', $format ) ) {
						printf( '<span class="entry-format">%1$s<a href="%2$s">%3$s</a></span>',
						sprintf( '<span class="screen-reader-text">%s </span>', __( 'Format', 'osum' ) ),
						esc_url( get_post_format_link( $format ) ),
						get_post_format_string( $format )
						);
					}
					if ( in_array( get_post_type(), array( 'post', 'attachment' ) ) ) {
						$time_string = '<time class="entry-date published updated" datetime="%1$s">%2$s</time>';
					
					if ( get_the_time( 'U' ) !== get_the_modified_time( 'U' ) ) {
						$time_string = '<time class="entry-date published" datetime="%1$s">%2$s</time>';
					}
					
					$time_string = sprintf( $time_string,
					esc_attr( get_the_date( 'c' ) ),
					get_the_date()
					);
					
					printf( '<span class="posted-on"><a href="%2$s" rel="bookmark">%3$s</a></span>',
					_x( 'Posted on', 'Used before publish date.', 'osum' ),
					esc_url( get_permalink() ),
					$time_string
					);
					}
                ?>
                </p>										
            </div>
        </figcaption>
    </figure>
	<?php 
}
endif;
if ( ! function_exists( 'osum_portfolio_thumbnail' ) ) :
/**
 * Display an optional post thumbnail.
 *
 * Wraps the post thumbnail in an anchor element on index views, or a div
 * element when on single views.
 *
 * @since Twenty Fifteen 1.0
 */
function osum_portfolio_thumbnail( $size = '') {
	global $post;
	if ( post_password_required() || is_attachment() || ! has_post_thumbnail() ) {
		return;
	}

	if ( is_single() ) :
	?>

	<div class="post-thumbnail">
		<?php  the_post_thumbnail($size); ?>
        
	</div><!-- .post-thumbnail -->
	<?php else : ?>
    	<a class="post-thumbnail" href="<?php the_permalink(); ?>" aria-hidden="true">
			<?php
				the_post_thumbnail( $size, array( 'alt' => get_the_title() ) );
			?>
		</a>
        
	<?php 
	endif; // End is_singular()
}
endif;


if ( ! function_exists( 'osum_excerpt_more' ) && ! is_admin() ) :
/**
 *
 * @since Twenty Fifteen 1.0
 *
 */
function osum_excerpt_more( $more ) {
	/*$link = sprintf( '<a href="%1$s" class="readmore">%2$s</a>',
		esc_url( get_permalink( get_the_ID() ) ),
		sprintf( __( 'Read More', 'osum' ))
		);
	return ' &hellip; ' . $link;*/
}
add_filter( 'excerpt_more', 'osum_excerpt_more' );
endif;
if ( ! function_exists( 'osum_read_more' ) && ! is_admin() ) :
/**
 * Replaces "[...]" (appended to automatically generated excerpts) with ... and a 'Continue reading' link.
 *
 * @return string 'Continue reading' link prepended with an ellipsis.
 */
function osum_read_more( ) {
	$link = sprintf( '<a href="%1$s" class="readmore_btn">%2$s <i class="lnr lnr-chevron-right"></i><i class="lnr lnr-chevron-right"></i></a>',
		esc_url( get_permalink( get_the_ID() ) ),
		/* translators: %s: Name of current post */
		sprintf( __( 'Read More', 'osum' ))
		);
	return  $link;
}
//add_filter( 'excerpt_more', 'twentyfifteen_excerpt_more' );
endif;
if ( ! function_exists( 'osum_author_desc' )) :
/**
 * Replaces "[...]" (appended to automatically generated excerpts) with ... and a 'Continue reading' link.
 *
 * @since Twenty Fifteen 1.0
 *
 * @return string 'Continue reading' link prepended with an ellipsis.
 */
function osum_author_desc() {
	?>
<div class="author-details">
	<article>
        <figure>
            <?php echo get_avatar(get_the_author_meta('ID'), '274'); ?>
        </figure>
    	<div class="author-info">
        <h2><?php echo get_the_author(); ?></h2>
        <p><?php the_author_meta('description'); ?></p>
        <div class="social-sharing">
            <ul>
            	<?php
	            	$all_meta_for_user = get_user_meta( 'facebook' );
					print_r( $all_meta_for_user );
					
					$facebook = get_the_author_meta( 'facebook', $userdata->ID );
					$googleplus = get_the_author_meta( 'googleplus', $userdata->ID );
					$linkedin = get_the_author_meta( 'linkedin', $userdata->ID );
					$twitter = get_the_author_meta( 'twitter', $userdata->ID );
					$pinterest = get_the_author_meta( 'pinterest', $userdata->ID );
					$instagram = get_the_author_meta( 'instagram', $userdata->ID );
					
				?>
				<?php if(!empty($facebook)) { ?>
                	<li><a target="_blank" href="<?php echo $facebook; ?>"><i class="icon icon-facebook"></i></a></li>
				<?php } ?>
				<?php if(!empty($googleplus)) { ?>
                	<li><a target="_blank" href="<?php echo $googleplus; ?>"><i class="icon icon-google-plus"></i></a></li>
				<?php } ?>
				<?php if(!empty($linkedin)) { ?>
                	<li><a target="_blank" href="<?php echo $linkedin; ?>"><i class="icon icon-linkedin2"></i></a></li>
				<?php } ?>
				<?php if(!empty($twitter)) { ?>
                	<li><a target="_blank" href="<?php echo $twitter; ?>"><i class="icon icon-twitter"></i></a></li>
				<?php } ?>
				<?php if(!empty($pinterest)) { ?>
                	<li><a target="_blank" href="<?php echo $pinterest; ?>"><i class="icon icon-pinterest"></i></a></li>
				<?php } ?>
				<?php if(!empty($instagram)) { ?>
                	<li><a target="_blank" href="<?php echo $instagram; ?>"><i class="icon icon-instagram"></i></a></li>
				<?php } ?>
            </ul>
        </div>
    </div>
    </article>
</div>	
	<?php
}
//add_filter( 'excerpt_more', 'twentyfifteen_excerpt_more' );
endif;
/**
 *
 * @ Osum Get Post Date
 *
 */
function osum_get_date(){
	if ( get_the_time( 'U' ) !== get_the_modified_time( 'U' ) ) {
		$time_string = '<time class="entry-date published" datetime="%1$s">%2$s</time>';
	}
	$time_string = sprintf( $time_string,
	esc_attr( get_the_date( 'c' ) ),
	the_date()
	);
	printf( '<a href="%2$s" rel="bookmark">%3$s</a>',
	_x( 'Posted on', 'Used before publish date.', 'osum' ),
	esc_url( get_permalink() ),
	$time_string
	);
}

function getPostViews($postID){
    $count_key = 'post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
        return "0";
    }
    return $count.'';

    /*session_start();
	$count_key = 'post_views_count';
	$count = get_post_meta($postID, $count_key, true);
	if($count==''){
		$count = 0;
		delete_post_meta($postID, $count_key);
		add_post_meta($postID, $count_key, '0');
	}else{
		if(!isset($_SESSION['post_views_count-'. $postID])){
			$_SESSION['post_views_count-'. $postID]="si";
			$count++;
			update_post_meta($postID, $count_key, $count);
		}
	}*/
}
function setPostViews($postID) {
    $count_key = 'post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
        $count = 0;
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
    }else{
        $count++;
        update_post_meta($postID, $count_key, $count);
    }
}
// Remove issues with prefetching adding extra views
remove_action( 'wp_head', 'adjacent_posts_rel_link_wp_head', 10, 0);
/**
 *
 * @ Osum Social Share
 *
 */
function osum_social_share(){
	?>
	<div class="social-sharing">
        <ul>
        	<li>
            	<a href="https://www.facebook.com/sharer.php?u=<?php the_permalink(); ?>" class="post_share_facebook" onclick="javascript:window.open(this.href,
			      '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=220,width=600');return false;">
                  <i class="icon icon-facebook2"></i>
                </a>
             </li>
			<li>
            	<a href="https://twitter.com/share?url=<?php the_permalink(); ?>&text=<?php echo urlencode(get_the_title()); ?>" onclick="javascript:window.open(this.href,
			      '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=260,width=600');return false;" class="product_share_twitter">
                  <i class="icon icon-twitter"></i>
                </a>
			</li>
            <li>
            	<a href="https://plus.google.com/share?url=<?php the_permalink(); ?>" onclick="javascript:window.open(this.href,
			      '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;">
                  <i class="icon icon-google-plus"></i>
				 </a>
			</li>
			<li class="pinterest">
				<a href="https://pinterest.com/pin/create/button/?url=<?php the_permalink(); ?>&media=<?php if(function_exists('the_post_thumbnail')) echo wp_get_attachment_url(get_post_thumbnail_id()); ?>&description=<?php echo get_the_title(); ?>" onclick="javascript:window.open(this.href,
				'', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=320,width=600');return false;"><i class="icon icon-pinterest"></i></a>
			</li>
			<li>
				<a href="http://www.linkedin.com/shareArticle?mini=true&url=<?php the_permalink(); ?>&title=<?php echo get_the_title(); ?>&summary=<?php echo strip_tags(substr(get_the_excerpt(),'25')); ?>" onclick="javascript:window.open(this.href,
										'', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=320,width=600');return false;">
					<i class="icon icon-linkedin2"></i>
				</a>
			</li>
        </ul>
    </div>
<?php
}


/* =========================================
			Instagram API images
============================================*/
function instagram_data( $search_for, $cache_hours, $nr_images, $attachment ) {
	global $osum_options;
	$osum_instagramuser = (isset($osum_options['instagram_user']) and $osum_options['instagram_user'] <> '') ? $osum_options['instagram_user'] : '';

	if ( isset( $search_for ) && !empty( $search_for ) ) {
		$search = 'user';
		$search_string = $osum_instagramuser;
	} else {
		return __( 'Nothing to search for', 'jrinstaslider');
	}

	$opt_name  = 'osum_insta_' . md5( $search . '_' . $search_string );
	$instaData = get_transient( $opt_name );
	$user_opt  = (array) get_option( $opt_name );

	//if ( true === $instaData || $user_opt['search_string'] != $search_string || $user_opt['search'] != $search || $user_opt['cache_hours'] != $cache_hours || $user_opt['nr_images'] != $nr_images) {
		
		$instaData = array();
		$user_opt['search']        = $search;
		$user_opt['search_string'] = $search_string;
		$user_opt['cache_hours']   = $cache_hours;
		$user_opt['nr_images']     = $nr_images;
		$user_opt['attachment']    = $attachment;
		$response = wp_remote_get( 'http://instagram.com/' . trim( $search_string ), array( 'sslverify' => false, 'timeout' => 60 ) );
		if ( is_wp_error( $response ) ) {

			return $response->get_error_message();
		}
		
		if ( $response['response']['code'] == 200 ) {
			
			$json = str_replace( 'window._sharedData = ', '', strstr( $response['body'], 'window._sharedData = ' ) );
			
			// Compatibility for version of php where strstr() doesnt accept third parameter
			if ( version_compare( PHP_VERSION, '5.3.0', '>=' ) ) {
				$json = strstr( $json, '</script>', true );
			} else {
				$json = substr( $json, 0, strpos( $json, '</script>' ) );
			}

			$json = rtrim( $json, ';' );

			// Function json_last_error() is not available before PHP * 5.3.0 version
			if ( function_exists( 'json_last_error' ) ) {
				( $results = json_decode( $json, true ) ) && json_last_error() == JSON_ERROR_NONE;

			} else {
				$results = json_decode( $json, true );
			}

			if ( $results && is_array( $results ) ) {
				$entry_data = isset( $results['entry_data']['ProfilePage'][0]['user']['media']['nodes'] ) ? $results['entry_data']['ProfilePage'][0]['user']['media']['nodes'] : array();
				if ( empty( $entry_data ) ) {
					return __( 'No images found', 'jrinstaslider');
				}

				foreach ( $entry_data as $current => $result ) {
					if ( $result['is_video'] == true ) {
						$nr_images++;
						continue;
					}
					if ( $current >= $nr_images ) {
						break;
					}

					$image_data['code']       = $result['code'];
					$image_data['username']   = 'user' == $search ? $search_string : false;
					$image_data['user_id']    = $result['owner']['id'];
					$image_data['id']         = $result['id'];
					$image_data['link']       = 'https://instagram.com/p/'. $result['code'];
					$image_data['popularity'] = (int) ( $result['comments']['count'] ) + ( $result['likes']['count'] );
					$image_data['comment_count'] = (int) ( $result['comments']['count'] );
					$image_data['like_count'] = (int) ($result['likes']['count'] );
					$image_data['timestamp']  = (float) $result['date'];
					$image_data['url']        = $result['display_src'];

					// Image Sizes from instagram
					preg_match( '/([^\/]+$)/', $image_data['url'], $matches );
					if ( false === strpos( $matches[0], '_7.jpg' ) ) {
						$image_data['url_medium']    = str_replace( $matches[0], 's320x320/' . $matches[0], $image_data['url'] );
						$image_data['url_thumbnail'] = str_replace( $matches[0], 's150x150/' . $matches[0], $image_data['url'] );
					} else {
						$image_data['url_medium']    = str_replace( '_7.jpg', '_6.jpg', $image_data['url'] );
						$image_data['url_thumbnail'] = str_replace( '_7.jpg', '_5.jpg', $image_data['url'] );
					}

					if ( ( $search == 'hashtag' ) || ( $search == 'user' && !$attachment ) ) {
						$instaData[] = $image_data;
					}
					
				} // end -> foreach
				
			} // end -> ( $results ) && is_array( $results ) )
			
		} else { 

			return $response['response']['message'];

		} // end -> $response['response']['code'] === 200 )

		update_option( $opt_name, $user_opt );
		
		if ( is_array( $instaData ) && !empty( $instaData )  ) {

			set_transient( $opt_name, $instaData, $cache_hours * 60 * 60 );
		}
		
	//} // end -> false === $instaData
	
	return $instaData;
}
function get_insta_template( $template, $args ) {

	$link_to   = isset( $args['link_to'] ) ? $args['link_to'] : false;
	$username  = $args['username'];
	$image_url = $args['image'];
	
	$output = '';
	if($template == 'slider'){
		$output .= '<li>';
		$output .= '<img src="' . $image_url . '" alt=""  />';
		$output .= '</li>';
	}else{
		$comment_count 	= $args['comment_count'];
	$like_count 	= $args['like_count'];
		$output .= "<li>";
			$image_src = '<img src="' . $image_url . '" alt="" />';
			if ( $link_to ) {
				$image_output  = '<a href="' . $link_to . '" target="_blank">' . $image_src . '</a>';
			}		
			$output .= $image_output;

		$output .= "</li>";
	}
	return $output;
}
