<?php 

function osum_ajax_save(){
	echo 'saving data in progresss';
	$osum_opt = (isset($_POST['opt_name']) and $_POST['opt_name'] <> '') ? $_POST['opt_name'] : '';
	$options	=	array();
	parse_str($_POST['data'],$options);
	update_option($osum_opt,$options);
	die(0);
}
add_action('wp_ajax_osum_ajax_save','osum_ajax_save');

function osum_ajax_reset(){
	$osum_opt = (isset($_POST['opt_name']) and $_POST['opt_name'] <> '') ? $_POST['opt_name'] : '';
	$options	=	osum_option_default();
	//parse_str($_POST['data'],$options);
	delete_option($osum_opt);
	update_option($osum_opt,$options);
	
	die(0);
}
add_action('wp_ajax_osum_ajax_reset','osum_ajax_reset'); 
/*
* @ Dafaul theme options if theme not activated
*/
function osum_option_default(){
	$options = panel_fields();
	foreach($options as $option){
		if(isset($option['fields'])) {
			foreach($option['fields'] as $field) {
				if(isset($field['std'])) {
					$option_default[$field['name']] = $field['std'];
				}elseif($field['type'] == 'typography'){
				
					$option_default[$field['name']] = $field['option'];

				}
			}
		}
	}
	return $option_default;
	
}
function osum_get_catlist( $taxonomy = 'category' ){
	$output = array();
	$args = array(
		'type'                     => 'post',
		'child_of'                 => 0,
		'parent'                   => '',
		'orderby'                  => 'name',
		'order'                    => 'ASC',
		'hide_empty'               => 1,
		'hierarchical'             => 1,
		'exclude'                  => '',
		'include'                  => '',
		'number'                   => '',
		'taxonomy'                 => $taxonomy,
		'pad_counts'               => false 
	); 
 	$categories = get_categories( $args );
 	foreach($categories as $cat){
		$output[$cat->slug] = $cat->name; 
	}
	return $output;
}
?>