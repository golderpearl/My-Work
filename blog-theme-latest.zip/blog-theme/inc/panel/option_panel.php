<?php
	global $osum_options, $wp_registered_sidebars;

	osum_get_options();

add_action( 'admin_menu', 'osum_theme_menu' );
/*
* @ Dafaul theme options
*/
function osum_get_options(){
	global $osum_options;
	if(!get_option('osum_theme_options')){
		$osum_options	=	osum_option_default();
	}else{
		$osum_options	=	get_option('osum_theme_options');
	}
	return $osum_options;
}
/*
* @ Add menu in wordpress admin area
*/
function osum_theme_menu() {
	add_theme_page( 'Theme Options', 'Osum Options', 'read', 'osum-theme-options', 'osum_theme_options' );
	add_theme_page( "Import Demo" , "Import Demo" ,'read', 'osum-demo-importer' , 'osum_demo_importer');

}
/*
* @ Return theme admin logo
*/
function osum_admin_logo(){
	$logo =	get_template_directory_uri().'/inc/panel/images/logo.png';
	return $logo;
}

function osum_theme_options() {
	global $osum_options;
	if ( !current_user_can( 'manage_options' ) )  {
		wp_die( __( 'You do not have sufficient permissions to access this page.','osum' ) );
	}
	$osum_options = osum_get_options();

	?>
	<div class="main-container">
    	<form name="option-panel" id="option-panel" class="" method="post" action="">
        	<div class="top-header">
        		<div class="logo">
        			<a href="#">
        				<img src="<?php echo osum_admin_logo(); ?>" alt="">
        			</a>
        		</div>
				<div class="right-side">
                	<div id="osum-loading"><?php _e('loading','osum');?></div>
         				<ul>
        				<li>
        					<div class="color"></div>
        				</li>
        				<li>
        					<?php  submit_button( __( 'Reset', 'osum' ), 'reset', 'osum_reset', false  ); ?>
        				</li>
        				<li>
        					<?php submit_button( __( 'Save All Settings', 'osum' ), 'primary', 'osum_save', false  ); ?>
        				</li>
        			</ul>
        			</div>
                </div>
	        <div id="tabs">
	        	<div class="sidebar-nav">
	                <ul>
	                	<?php 
							$option	= 	panel_fields();
							osum_get_tab($option);
						?>

	        		</ul>
	        	</div>
	        	<div class="right-section"> 
	                 <?php 	echo panel_nav($option); ?>
	        	</div>
        	</div>
        </form>
    </div>
	<?php
}
function osum_get_tab($option){
	foreach($option as $value){
	$osum_icon =(isset($value['icon']) and $value['icon'] <> '') ? $value['icon'] : '';
	echo '<li><i class="icon '.$value['icon'].'"></i>';
		echo '<a href="#'.$value['id'].'">'.$value['name'].'</a>';
	echo '</li>';
	}

}
function panel_nav($option){
	$output	=	'';
	
	foreach($option as $values){
		$output = '';
		echo '<div class="tab-section" id="'.$values['id'].'">';
			echo  get_fields($values['fields']);
		echo '</div>';
	}
}
function get_fields( $fields = array() ){
	global $osum_form_field;
	$output	=	'<ul>';
	foreach($fields as $field){
		//if($field['type'] == 'select_sh'){}
		$output	.=	'<li class="'.$field['class'].'">';
			$t = 'osum_'.$field['type'].'_field';
			$output	.= call_user_func_array(array($osum_form_field, $t), array($field));
		$output	.=	'</li>';
		if(!empty($field['desc'])) {
			$output	.= '<p>'.$field['desc'].'</p>';
		}
		
		//$output .= '<li><div class="separator"></div></li>';
	}
	$output	.=	'</ul>';
	return $output;
}

function panel_fields(){
	global $osum_form_field,$option,$osum_options;
        $mail_chimp_list[]='';
        $osum_mc_key = (isset($osum_options['mc_key']) and $osum_options['mc_key'] <> '' ) ? $osum_options['mc_key'] : '';
		if($osum_mc_key){
            $mailchimp_option = $osum_options['mc_key'];
            if($mailchimp_option <> ''){
                $mc_list = osum_mailchimp_list($mailchimp_option);
                if(is_array($mc_list) && isset($mc_list['data'])){
                    foreach($mc_list['data'] as $list){
                        $mail_chimp_list[$list['id']]=$list['name'];
                    }
                }
            }
        }
	$option = array();
	$option['general_settings'] = array(
		'name'		=> 	'General Settings',
		'id'		=> 	'tab-general-setting',
		'class'		=> 	'',
		'icon'		=> 	'icon-cogs',				
		'desc'		=> 	'text',				
		'fields'	=>	array(
			array(
				'name'	=> 	'logo_heading',
				'id'	=> 	'logo_heading',
				'class'	=> 	'logo_heading',
				'label'	=>	'Logo / Fav Icon Setting',
				'desc'	=> 	'Add your logo and fav icon.',
				'type'	=> 	'heading',
			),
			array(
				'name'	=> 	'theme_color',
				'id'	=> 	'theme_color',
				'class'	=> 	'color',
				'desc'	=> 	'',
				'label'	=>	'Theme Color',
				'std'	=> 	'#000',
				'meta'	=> 	'false',
				'type'	=> 	'color',
			),
			// array(
			// 	'name'	=> 	'site_layout',
			// 	'id'	=> 	'site_layout',
			// 	'class'	=> 	'site-layout',
			// 	'desc'	=> 	'',
			// 	'label'	=>	'Layout',
			// 	'style'	=>  'image',
			// 	'std'	=> 	'full_width',
			// 	'meta'	=> 	'false',
			// 	'type'	=> 	'radio',
			// 	'option'=>	array(
			// 		'boxed'			=>	'Boxed',
			// 		'full_width'	=>	'full width',
			// 	)
			// ),
			array(
				'name'	=> 	'nav_color',
				'id'	=> 	'nav_color',
				'class'	=> 	'nav-color',
				'desc'	=> 	'',
				'label'	=>	'Nav BG Color',
				'std'	=> 	'#000',
				'meta'	=> 	'false',
				'type'	=> 	'color',
			),
			array(
				'name'	=> 	'logo',
				'id'	=> 	'logo',
				'class'	=> 	'logo',
				'desc'	=> 	'',
				'label'	=>	'logo',
				'std'	=> 	get_template_directory_uri().'/assets/images/logo.png',
				'meta'	=> 	'true',
				'type'	=> 	'media',
			),
			array(
				'name'	=> 	'logo_width',
				'id'	=> 	'width-parameter',
				'class'	=> 	'',
				'desc'	=> 	'',
				'label'	=>	'Logo Width',
				'min'	=> 	'5',
				'max'	=> 	'413',
				'step'	=> 	'1',
				'std'	=> 	'413',
				'meta'	=> 	'false',
				'type'	=> 	'range',
			),
			array(
				'name'	=> 	'mobile_logo',
				'id'	=> 	'mobile_logo',
				'class'	=> 	'mobile_logo',
				'desc'	=> 	'',
				'label'	=>	'Mobile logo',
				'std'	=> 	get_template_directory_uri().'/assets/images/mobile_logo.png',
				'meta'	=> 	'true',
				'type'	=> 	'media',
			),
			/* array(
				'name'	=> 	'logo_height',
				'id'	=> 	'height-parameter',
				'class'	=> 	'',
				'desc'	=> 	'',
				'label'	=>	'Logo Height',
				'min'	=> 	'0',
				'max'	=> 	'97',
				'step'	=> 	'1',
				'std'	=> 	'97',
				'meta'	=> 	'false',
				'type'	=> 	'range',
			), */
			array(
				'name'	=> 	'favicon',
				'id'	=> 	'favicon',
				'class'	=> 	'favicon',
				'desc'	=> 	'',
				'label'	=>	'favicon',
				'std'	=> 	get_template_directory_uri().'/assets/images/favicon.png',
				'meta'	=> 	'false',
				'type'	=> 	'media',
			),
			// array(
			// 	'name'	=> 	'background_heading',
			// 	'id'	=> 	'background_heading',
			// 	'class'	=> 	'background_heading',
			// 	'label'	=>	'Background Image/Color',
			// 	'desc'	=> 	'set background image/color.',
			// 	'type'	=> 	'sub_heading',
			// ),	
			// array(
			// 	'name'	=> 	'bg_color',
			// 	'id'	=> 	'bg_color',
			// 	'class'	=> 	'color',
			// 	'desc'	=> 	'',
			// 	'label'	=>	'Background Color',
			// 	'std'	=> 	'#fff',
			// 	'type'	=> 	'color',
			// ),	
			// array(
			// 	'name'	=> 	'pattern',
			// 	'id'	=> 	'pattern',
			// 	'class'	=> 	'pattern',
			// 	'desc'	=> 	'',
			// 	'label'	=>	'Background Pattern',
			// 	'std'	=> 	'pattern1',
			// 	'type'	=> 	'radio_bg',
			// 	'style'	=>	'image',
			// 	'meta'	=> 	'false',
			// 	'option'=>	array(
			// 		'pattern-1'		=>	'pattern1',
			// 		'pattern-2'		=>	'pattern2',
			// 		'pattern-3'		=>	'pattern3',
			// 		'pattern-4'		=>	'pattern4',
			// 		'pattern-5'		=>	'pattern5',
			// 		'pattern-6'		=>	'pattern6',
			// 		'pattern-7'		=>	'pattern7',
			// 		'pattern-8'		=>	'pattern8',
			// 	)
			// ),
			// array(
			// 	'name'	=> 	'showpattern',
			// 	'id'	=> 	'showpattern',
			// 	'class'	=> 	'show-pattern',
			// 	'desc'	=> 	'',
			// 	'label'	=>	'Show Pattern',
			// 	'std'	=> 	'true',
			// 	'meta'	=> 	'false',
			// 	'type'	=> 	'switch',
			// ),
			// array(
			// 	'name'	=> 	'body_bgimage',
			// 	'id'	=> 	'body_bgimage',
			// 	'class'	=> 	'body-bgimage',
			// 	'desc'	=> 	'upload body background',
			// 	'label'	=>	'Background Image',
			// 	'std'	=> 	'',
			// 	'meta'	=> 	'true',
			// 	'type'	=> 	'media',
			// ),
			// array(
			// 	'name'	=> 	'bg_repeat',
			// 	'id'	=> 	'bg_repeat',
			// 	'class'	=> 	'bg-repeat',
			// 	'desc'	=> 	'',
			// 	'label'	=>	'Background Repeat',
			// 	'std'	=> 	'repeat',
			// 	'type'	=> 	'select',
			// 	'style'	=>	'image',
			// 	'meta'	=> 	'false',
			// 	'option'=>	array(
			// 		'repeat'		=>	'repeat',
			// 		'no-repeat'		=>	'no-repeat',
			// 		'repeat-x'		=>	'repeat-x',
			// 		'repeat-y'		=>	'repeat-y'
			// 	)
			// ),			
			// array(
			// 	'name'	=> 	'bg_position',
			// 	'id'	=> 	'bg_position',
			// 	'class'	=> 	'bg-position',
			// 	'desc'	=> 	'',
			// 	'label'	=>	'Background Position',
			// 	'std'	=> 	'center',
			// 	'type'	=> 	'select',
			// 	'style'	=>	'image',
			// 	'meta'	=> 	'false',
			// 	'option'=>	array(
			// 		'left'			=>	'left',
			// 		'center'		=>	'center',
			// 		'top'			=>	'top',
			// 		'bottom'		=>	'bottom',
			// 		'left top'		=>	'left top',
			// 		'center top' 	=>	'center top',
			// 	)
			// ),			
			// array(
			// 	'name'	=> 	'bg_size',
			// 	'id'	=> 	'bg_size',
			// 	'class'	=> 	'bg-size',
			// 	'desc'	=> 	'',
			// 	'label'	=>	'Background Position',
			// 	'std'	=> 	'none',
			// 	'type'	=> 	'select',
			// 	'style'	=>	'image',
			// 	'meta'	=> 	'false',
			// 	'option'=>	array(
			// 		'contain'			=>	'Contain',
			// 		'cover'				=>	'Cover',
			// 		'none'				=>	'None',
			// 	)
			// ),
		)
	);
	$option['header_settings'] = array(
		'name'		=> 	'Header Settings',
		'id'		=> 	'tab-header-settings',
		'class'		=> 	'',
		'icon'		=> 	'icon-upload2',				
		'desc'		=> 	'text',				
		'fields'	=>	array(
			array(
				'name'	=> 	'logo_heading',
				'id'	=> 	'logo_heading',
				'class'	=> 	'logo_heading',
				'label'	=>	'Header Settings',
				'desc'	=> 	'',
				'type'	=> 	'heading',
			),	
			array(
				'name'	=> 	'search_box',
				'id'	=> 	'search-box',
				'class'	=> 	'search-box',
				'desc'	=> 	'',
				'label'	=>	'Search',
				'std'	=> 	'true',
				'meta'	=> 	'false',
				'type'	=> 	'switch',
			),
			/*array(
				'name'	=> 	'header_style',
				'id'	=> 	'header_style',
				'class'	=> 	'dropdown',
				'desc'	=> 	'',
				'label'	=>	'Header Style',
				'style'	=>	'image',
				'std'	=> 	'header1',
				'type'	=> 	'radio',
				'meta'	=> 	'false',
				'option'=>	array(
					'header1'	=>	'Header 1',
 				)
			),*/
			array(
				'name'	=> 	'social_network',
				'id'	=> 	'social_network',
				'class'	=> 	'social_network',
				'desc'	=> 	'',
				'label'	=>	'Social Network',
				'std'	=> 	'true',
				'meta'	=> 	'false',
				'type'	=> 	'switch',
			),
			array(
				'name'	=> 	'stickyheader',
				'id'	=> 	'stickyheader',
				'class'	=> 	'stickyheader',
				'desc'	=> 	'',
				'label'	=>	'Sticky Header',
				'std'	=> 	'true',
				'meta'	=> 	'false',
				'type'	=> 	'switch',
			)
		)
	);
	$option['home_slider'] = array(
		'name'		=> 	'Home Slider',
		'id'		=> 	'tab-slider-settings',
		'class'		=> 	'',
		'icon'		=> 	'icon-download3',				
		'desc'		=> 	'text',				
		'fields'	=>	array(
			array(
				'name'	=> 	'slider_heading',
				'id'	=> 	'slider_heading',
				'class'	=> 	'slider_heading',
				'label'	=>	'Sliders Settings',
				'desc'	=> 	'',
				'type'	=> 	'heading',
			),	
			
			array(
				'name'	=> 	'show_slider',
				'id'	=> 	'show_slider',
				'class'	=> 	'show-slider',
				'desc'	=> 	'',
				'label'	=>	'Show Slider',
				'std'	=> 	'true',
				'meta'	=> 	'false',
				'type'	=> 	'switch',
			),
			array(
				'name'	=> 	'slider_title',
				'id'	=> 	'slider-title',
				'class'	=> 	'slider-title',
				'label'	=>	'Sliders Title',
				'desc'	=> 	'Latest News',
				'type'	=> 	'text',
			),
			array(
				'name'	=> 	'slider_cat',
				'id'	=> 	'slider_cat',
				'class'	=> 	'slider-cat',
				'desc'	=> 	'',
				'label'	=>	'Select Category',
				'std'	=> 	'true',
				'meta'	=> 	'false',
				'type'	=> 	'select',
				'option'=>	osum_get_catlist()
				
			),	

			array(
				'name'	=> 	'show_posts',
				'id'	=> 	'show_posts',
				'class'	=> 	'show_posts',
				'desc'	=> 	'show total number of posts',
				'label'	=>	'Show Posts',
				'std'	=> 	'5',
				'meta'	=> 	'false',
				'type'	=> 	'text',
			)
		)
	);
	$option['footer_settings'] = array(
		'name'		=> 	'Footer Settings',
		'id'		=> 	'tab-footer-settings',
		'class'		=> 	'',
		'icon'		=> 	'icon-download3',				
		'desc'		=> 	'text',				
		'fields'	=>	array(
			array(
				'name'	=> 	'footer_heading',
				'id'	=> 	'footer_heading',
				'class'	=> 	'footer_heading',
				'label'	=>	'Footer Settings',
				'desc'	=> 	'',
				'type'	=> 	'heading',
			),
			array(
				'name'	=> 	'ftr_logo',
				'id'	=> 	'ftr-logo',
				'class'	=> 	'ftr-logo',
				'desc'	=> 	'upload footer logo',
				'label'	=>	'Footer Logo',
				'std'	=> 	get_template_directory_uri().'/assets/images/footer-logo.png',
				'meta'	=> 	'true',
				'type'	=> 	'media',
			),
			array(
				'name'	=> 	'ftr_logow',
				'id'	=> 	'width-parameter',
				'class'	=> 	'',
				'desc'	=> 	'',
				'label'	=>	'Logo Width',
				'min'	=> 	'5',
				'max'	=> 	'270',
				'step'	=> 	'1',
				'std'	=> 	'320',
				'meta'	=> 	'false',
				'type'	=> 	'range',
			),
			/* array(
				'name'	=> 	'ftr_logoh',
				'id'	=> 	'height-parameter',
				'class'	=> 	'',
				'desc'	=> 	'',
				'label'	=>	'Logo Height',
				'min'	=> 	'0',
				'max'	=> 	'50',
				'step'	=> 	'1',
				'std'	=> 	'82',
				'meta'	=> 	'false',
				'type'	=> 	'range',
			), */
			/* array(
				'name'	=> 	'instagram',
				'id'	=> 	'instagram',
				'class'	=> 	'instagram',
				'desc'	=> 	'',
				'label'	=>	'Instagram Images',
				'std'	=> 	'true',
				'meta'	=> 	'false',
				'type'	=> 	'switch',
			), */
			array(
				'name'	=> 	'instagram_user',
				'id'	=> 	'instagram-user',
				'class'	=> 	'instagram-user',
				'desc'	=> 	'<a href="http://instagram.pixelunion.net/" target="_blank">Click here</a> to get Instagram Access Token and paste it here.',
				'label'	=>	'Instagram Access Token',
				'std'	=> 	'aaital',
				'meta'	=> 	'false',
				'type'	=> 	'text',
			),
			array(
				'name'	=> 	'instagram_posts',
				'id'	=> 	'instagram-posts',
				'class'	=> 	'instagram-posts',
				'desc'	=> 	'',
				'label'	=>	'Instagram Posts Display',
				'std'	=> 	'6',
				'meta'	=> 	'false',
				'type'	=> 	'text',
			),
			array(
				'name'	=> 	'newsletter',
				'id'	=> 	'newsletter',
				'class'	=> 	'newsletter',
				'desc'	=> 	'',
				'label'	=>	'Newsletter',
				'std'	=> 	'true',
				'meta'	=> 	'false',
				'type'	=> 	'switch',
			),
			array(
				'name'	=> 	'newsletter_title',
				'id'	=> 	'newsletter_title',
				'class'	=> 	'newsletter_title',
				'desc'	=> 	'',
				'label'	=>	'Newsletter Title',
				'std'	=> 	'Subsribe our Newsletter',
				'meta'	=> 	'false',
				'type'	=> 	'text',
			),
			array(
				'name'	=> 	'newsletter_text',
				'id'	=> 	'newsletter_text',
				'class'	=> 	'newsletter_text',
				'desc'	=> 	'',
				'label'	=>	'Newsletter Text',
				'std'	=> 	'Get the latest creative news from osummedia about art, design and pop-culture.',
				'meta'	=> 	'false',
				'type'	=> 	'textarea',
			),
			array(
				'name'	=> 	'copyright',
				'id'	=> 	'copyright',
				'class'	=> 	'copyright',
				'desc'	=> 	'',
				'label'	=>	'Copyright',
				'std'	=> 	'All rights reserved.',
				'meta'	=> 	'false',
				'type'	=> 	'text',
			),
			array(
				'name'	=> 	'footer_color',
				'id'	=> 	'footer_color',
				'class'	=> 	'footer_color',
				'label'	=>	'Footer Colors',
				'desc'	=> 	'',
				'type'	=> 	'sub_heading',
			),	
			array(
				'name'	=> 	'ft_bgcolor',
				'id'	=> 	'ft_bgcolor',
				'class'	=> 	'color',
				'desc'	=> 	'',
				'label'	=>	'Background Color',
				'std'	=> 	'',
				'meta'	=> 	'false',
				'type'	=> 	'color',
			),
		)
	);
	$option['social_profile'] = array(
		'name'		=> 	'Social Profiles',
		'id'		=> 	'tab-social-settings',
		'class'		=> 	'',
		'icon'		=> 	'icon-share2',				
		'desc'		=> 	'text',				
		'fields'	=>	array(
			array(
				'name'	=> 	'social_profile',
				'id'	=> 	'social_profile',
				'class'	=> 	'social_profile',
				'label'	=>	'Social Profiles',
				'desc'	=> 	'',
				'type'	=> 	'heading',
			),	
			array(
				'name'	=> 	'facebook_url',
				'id'	=> 	'facebook-url',
				'class'	=> 	'facebook-url',
				'desc'	=> 	'',
				'label'	=>	'Facebook',
				'std'	=> 	'http://facebook.com/',
				'meta'	=> 	'false',
				'type'	=> 	'text',
			),
			array(
				'name'	=> 	'instagram_url',
				'id'	=> 	'instagram-url',
				'class'	=> 	'instagram-url',
				'desc'	=> 	'',
				'label'	=>	'Instagram',
				'std'	=> 	'http://instagram.com/aaital',
				'meta'	=> 	'false',
				'type'	=> 	'text',
			),		
		)
	);
	$option['other_settings'] = array(
		'name'		=> 	'Other Settings',
		'id'		=> 	'tab-othersetting',
		'class'		=> 	'',
		'icon'		=> 	'icon-share2',				
		'desc'		=> 	'text',				
		'fields'	=>	array(
			array(
				'name'	=> 	'other_settings',
				'id'	=> 	'other-settings',
				'class'	=> 	'other-settings',
				'label'	=>	'Other Settings',
				'desc'	=> 	'',
				'type'	=> 	'heading',
			),
			array(
				'name'	=> 	'responsive_switch',
				'id'	=> 	'responsive-switch',
				'class'	=> 	'responsive-switch',
				'desc'	=> 	'',
				'label'	=>	'Responsive',
				'std'	=> 	'true',
				'meta'	=> 	'false',
				'type'	=> 	'switch',
			),
			array(
				'name'	=> 	'category_posts',
				'id'	=> 	'category-posts',
				'class'	=> 	'category-posts',
				'desc'	=> 	'',
				'label'	=>	'Category Posts',
				'std'	=> 	'true',
				'meta'	=> 	'false',
				'type'	=> 	'switch',
			),		
		)
	);
	/* $option['typography'] = array(
		'name'		=> 	'Typography',
		'id'		=> 	'tab-typo-settings',
		'class'		=> 	'',
		'icon'		=> 	'icon-pencil',				
		'desc'		=> 	'text',				
		'fields'	=>	array(
			array(
				'name'	=> 	'typography',
				'id'	=> 	'typography',
				'class'	=> 	'typography',
				'label'	=>	'Typography',
				'desc'	=> 	'typography settings',
				'type'	=> 	'heading',
			),	
			array(
				'name'	=> 	'content',
				'id'	=> 	'content',
				'class'	=> 	'content',
				'desc'	=> 	'',
				'label'	=>	'Content',
				'type'	=> 	'typography',
				'meta'	=> 	'false',
				'option'=>	array(
                    'font-family' 	=> 	'',
					'font-style'  	=> 	'',
                    'font-size'   	=> 	'',
					'font-color'	=>	'#000',
				)
			),			
			array(
				'name'	=> 	'heading1',
				'id'	=> 	'heading1',
				'class'	=> 	'heading1',
				'desc'	=> 	'',
				'label'	=>	'Heading1',
				'meta'	=> 	'false',
				'type'	=> 	'typography',
				'option'=>	array(
                    'font-family' 	=> 	'',
					'font-style'  	=> 	'',
                    'font-size'   	=> 	'',
					'font-color'	=>	'#000',
				)
			),
			array(
				'name'	=> 	'heading2',
				'id'	=> 	'heading2',
				'class'	=> 	'heading2',
				'desc'	=> 	'',
				'label'	=>	'Heading2',
				'meta'	=> 	'false',
				'type'	=> 	'typography',
				'option'=>	array(
                    'font-family' 	=> 	'',
					'font-style'  	=> 	'',
                    'font-size'   	=> 	'',
					'font-color'	=>	'#000',
				)
			),			
			array(
				'name'	=> 	'heading3',
				'id'	=> 	'heading3',
				'class'	=> 	'heading3',
				'desc'	=> 	'',
				'label'	=>	'Heading3',
				'meta'	=> 	'false',
				'type'	=> 	'typography',
				'option'=>	array(
                    'font-family' 	=> 	'',
					'font-style'  	=> 	'',
                    'font-size'   	=> 	'',
					'font-color'	=>	'#000',
				)
			),			
			array(
				'name'	=> 	'heading4',
				'id'	=> 	'heading4',
				'class'	=> 	'heading4',
				'desc'	=> 	'',
				'label'	=>	'Heading4',
				'meta'	=> 	'false',
				'type'	=> 	'typography',
				'option'=>	array(
                    'font-family' 	=> 	'',
					'font-style'  	=> 	'',
                    'font-size'   	=> 	'',
					'font-color'	=>	'#000',
				)
			),			
			array(
				'name'	=> 	'heading5',
				'id'	=> 	'heading5',
				'class'	=> 	'heading5',
				'desc'	=> 	'',
				'label'	=>	'Heading5',
				'meta'	=> 	'false',
				'type'	=> 	'typography',
				'option'=>	array(
                    'font-family' 	=> 	'',
					'font-style'  	=> 	'',
                    'font-size'   	=> 	'',
					'font-color'	=>	'#000',
				)
			),			
			array(
				'name'	=> 	'heading6',
				'id'	=> 	'heading6',
				'class'	=> 	'heading6',
				'desc'	=> 	'',
				'label'	=>	'Heading6',
				'meta'	=> 	'false',
				'type'	=> 	'typography',
				'option'=>	array(
                    'font-family' 	=> 	'',
					'font-style'  	=> 	'',
                    'font-size'   	=> 	'',
					'font-color'	=>	'#000',
				)
			),		 
		)
	); */
	$option['default_pages'] = array(
		'name'		=> 	'Default Pages',
		'id'		=> 	'tab-default-pages-settings',
		'class'		=> 	'',
		'icon'		=> 	'icon-files-empty',				
		'desc'		=> 	'text',				
		'fields'	=>	array(
			array(
				'name'	=> 	'custom_sidebar',
				'id'	=> 	'custom_sidebar',
				'class'	=> 	'custom_sidebar',
				'label'	=>	'Add Custom Sidebar',
				'desc'	=> 	'',
				'type'	=> 	'heading',
			),	
			array(
				'name'	=> 	'sidebar_list',
				'id'	=> 	'sidebar_list',
				'class'	=> 	'sidebar-layout',
				'desc'	=> 	'',
				'label'	=>	'Create Sidebar',
				'std'	=> 	'',
				'meta'	=> 	'false',
				'type'	=> 	'sidebar',
				'option'=>	array(
					'blog'			=>	'Blog',
				)
			),			
			array(
				'name'	=> 	'default_page',
				'id'	=> 	'default_page',
				'class'	=> 	'default_pages',
				'label'	=>	'Default Pages Setting',
				'desc'	=> 	'',
				'type'	=> 	'heading',
			),			
			array(
				'name'	=> 	'pagination',
				'id'	=> 	'pagination',
				'class'	=> 	'pagination',
				'desc'	=> 	'',
				'label'	=>	'Pagination',
				'std'	=> 	'true',
				'meta'	=> 	'false',
				'type'	=> 	'switch',
			),
			array(
				'name'	=> 	'sidebar_layout',
				'id'	=> 	'sidebar_layout',
				'class'	=> 	'sidebar-layout',
				'desc'	=> 	'',
				'label'	=>	'Layout',
				'style'	=>  'image',
				'std'	=> 	'full_width',
				'meta'	=> 	'false',
				'type'	=> 	'radio',
				'option'=>	array(
					'left_sidebar'	=>	'left sidebar',
					'full_width'	=>	'full width',
					'right_sidebar'	=>	'right sidebar',
				)
			),
			array(
				'name'	=> 	'sidebar',
				'id'	=> 	'layout',
				'class'	=> 	'layout',
				'desc'	=> 	'',
				'label'	=>	'Sidebar',
				'std'	=> 	'',
				'meta'	=> 	'false',
				'type'	=> 	'select',
				'option'=>	osum_sidebars_list()
			)
 		)
	);
	$option['api_setting'] = array(
		'name'		=> 	'API Settings',
		'id'		=> 	'tab-api-settings',
		'class'		=> 	'',
		'icon'		=> 	'icon-sphere',				
		'desc'		=> 	'text',				
		'fields'	=>	array(
			array(
				'name'	=> 	'api_setting',
				'id'	=> 	'api_setting',
				'class'	=> 	'api_setting',
				'label'	=>	'API Setting',
				'desc'	=> 	'',
				'type'	=> 	'heading',
			),	
			array(
				'name'	=> 	'sub_heading',
				'id'	=> 	'sub_heading',
				'class'	=> 	'sub_heading',
				'label'	=>	'Facebook',
				'desc'	=> 	'sub heading',
				'meta'	=> 	'false',
				'type'	=> 	'sub_heading',
			),	
			array(
				'name'	=> 	'facebook_key',
				'id'	=> 	'',
				'class'	=> 	'',
				'desc'	=> 	'',
				'label'	=>	'Facebook Key',
				'std'	=> 	'text',
				'meta'	=> 	'false',
				'type'	=> 	'text',
			),
			array(
				'name'	=> 	'sub_heading',
				'id'	=> 	'sub_heading',
				'class'	=> 	'sub_heading',
				'label'	=>	'Twitter',
				'desc'	=> 	'sub heading',
				'type'	=> 	'sub_heading',
			),
			array(
				'name'	=> 	'consumer_key',
				'id'	=> 	'',
				'class'	=> 	'',
				'desc'	=> 	'',
				'label'	=>	'Consumer Key',
				'std'	=> 	'text',
				'meta'	=> 	'false',
				'type'	=> 	'text',
			),			
			array(
				'name'	=> 	'consumer_secret',
				'id'	=> 	'',
				'class'	=> 	'',
				'desc'	=> 	'',
				'label'	=>	'Consumer Secret',
				'std'	=> 	'text',
				'meta'	=> 	'false',
				'type'	=> 	'text',
			),			
			array(
				'name'	=> 	'access_token',
				'id'	=> 	'',
				'class'	=> 	'',
				'desc'	=> 	'',
				'label'	=>	'Access Token',
				'std'	=> 	'text',
				'meta'	=> 	'false',
				'type'	=> 	'text',
			),			
			array(
				'name'	=> 	'access_token_secret',
				'id'	=> 	'',
				'class'	=> 	'',
				'desc'	=> 	'',
				'label'	=>	'Access Token Secret',
				'std'	=> 	'text',
				'meta'	=> 	'false',
				'type'	=> 	'text',
			),			
			array(
				'name'	=> 	'sub_heading',
				'id'	=> 	'sub_heading',
				'class'	=> 	'sub_heading',
				'label'	=>	'Google',
				'desc'	=> 	'sub heading',
				'type'	=> 	'sub_heading',
			),
			array(
				'name'	=> 	'google_key',
				'id'	=> 	'',
				'class'	=> 	'',
				'desc'	=> 	'',
				'label'	=>	'Google Key',
				'std'	=> 	'text',
				'meta'	=> 	'false',
				'type'	=> 	'text',
			),			
			array(
				'name'	=> 	'sub_heading',
				'id'	=> 	'sub_heading',
				'class'	=> 	'sub_heading',
				'label'	=>	'MailChimps',
				'desc'	=> 	'sub heading',
				'meta'	=> 	'false',
				'type'	=> 	'sub_heading',
			),
			array(
				'name'	=> 	'mc_key',
				'id'	=> 	'osum_mc_key',
				'class'	=> 	'',
				'desc'	=> 	'',
				'label'	=>	'MailChimp  Key',
				'std'	=> 	'',
				'meta'	=> 	'false',
				'type'	=> 	'text',
			),		
			array(
				'name'	=> 	'mc_list',
				'id'	=> 	'mc_list',
				'class'	=> 	'layout',
				'desc'	=> 	'',
				'label'	=>	'Mailchimp List',
				'std'	=> 	'',
				'meta'	=> 	'false',
				'type'	=> 	'select',
				'option'=>	$mail_chimp_list
			)	
					
		)
	);
	$option['social_share'] = array(
		'name'		=> 	'Social Shares',
		'id'		=> 	'tab-socialshare',
		'class'		=> 	'',
		'icon'		=> 	'icon-share2',				
		'desc'		=> 	'text',				
		'fields'	=>	array(
			array(
				'name'	=> 	'social_Share',
				'id'	=> 	'social_Share',
				'class'	=> 	'social_Share',
				'label'	=>	'Social Share',
				'desc'	=> 	'',
				'type'	=> 	'heading',
			),	
			array(
				'name'	=> 	'facebook_share',
				'id'	=> 	'',
				'class'	=> 	'',
				'desc'	=> 	'',
				'label'	=>	'Facebook',
				'std'	=> 	'true',
				'meta'	=> 	'false',
				'type'	=> 	'switch',
			),
 			array(
				'name'	=> 	'twitter_share',
				'id'	=> 	'',
				'class'	=> 	'',
				'desc'	=> 	'',
				'label'	=>	'Twitter',
				'std'	=> 	'true',
				'meta'	=> 	'false',
				'type'	=> 	'switch',
			),			
			array(
				'name'	=> 	'linkedin_share',
				'id'	=> 	'',
				'class'	=> 	'',
				'desc'	=> 	'',
				'label'	=>	'LinkedIn',
				'std'	=> 	'true',
				'meta'	=> 	'false',
				'type'	=> 	'switch',
			),
		)
	);
	$option['google_ads'] = array(
		'name'		=> 	'Google AdSense',
		'id'		=> 	'tab-adsense',
		'class'		=> 	'',
		'icon'		=> 	'icon-sphere',
		'desc'		=> 	'text',
		'fields'	=>	array(
			array(
				'name'	=> 	'google_adsense',
				'id'	=> 	'google_adsense',
				'class'	=> 	'google-adsense',
				'label'	=>	'Google AdSense',
				'desc'	=> 	'',
				'type'	=> 	'heading',
			),
			array(
				'name'	=> 	'footer_ad_switch',
				'id'	=> 	'footer-ad-switch',
				'class'	=> 	'footer-ad-switch',
				'desc'	=> 	'',
				'label'	=>	'Footer Ad',
				'std'	=> 	'true',
				'meta'	=> 	'false',
				'type'	=> 	'switch',
			),
			array(
				'name'	=> 	'footer_ad_box',
				'id'	=> 	'',
				'class'	=> 	'',
				'desc'	=> 	'',
				'label'	=>	'Footer Ad Box',
				'std'	=> 	get_template_directory_uri().'/assets/images/ad.jpg',
				'meta'	=> 	'false',
				'type'	=> 	'textarea',
			),
		)
	);
	return	$option;
}
function osum_sidebars_list() {
	global $wp_registered_sidebars;
	$sidebars = array();
	foreach ( $wp_registered_sidebars as $sidebar ) {
		$sidebars[$sidebar['id']] = $sidebar['name'];
	}
	return $sidebars;
}
?>