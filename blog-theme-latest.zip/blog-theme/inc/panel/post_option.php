<?php
/**
 * Calls the class on the post edit screen.
 */
	


function post_options(){
	global $osum_form_field;
 
	$post_meta = array();
	$post_meta['general_settings'] 	= array(
		'name'		=> 	'General Settings',
		'id'		=> 	'tab-general-setting',
		'class'		=> 	'',
		'icon'		=> 	'icon-cogs',				
		'desc'		=> 	'text',				
		'fields'	=>	array(
		
			array(
				'name'	=> 	'post_heading',
				'id'	=> 	'post_heading',
				'class'	=> 	'post-heading',
				'desc'	=> 	'',
				'label'	=>	'Post Heading',
				'std'	=> 	'true',
				'meta'	=> 	'true',
				'type'	=> 	'switch',
			),	
			array(
				'name'	=> 	'post_tags',
				'id'	=> 	'post_tags',
				'class'	=> 	'post-tags',
				'desc'	=> 	'',
				'label'	=>	'Post Tags',
				'std'	=> 	'true',
				'meta'	=> 	'true',
				'type'	=> 	'switch',
			),		
			array(
				'name'	=> 	'post_cat',
				'id'	=> 	'post_cat',
				'class'	=> 	'post-cat',
				'desc'	=> 	'',
				'label'	=>	'Post Categories',
				'std'	=> 	'true',
				'meta'	=> 	'true',
				'type'	=> 	'switch',
			),		
	
			array(
				'name'	=> 	'comments',
				'id'	=> 	'comments',
				'class'	=> 	'comments',
				'desc'	=> 	'',
				'label'	=>	'Comments',
				'std'	=> 	'true',
				'meta'	=> 	'true',
				'type'	=> 	'switch',
			),		
			array(
				'name'	=> 	'post_nav',
				'id'	=> 	'post_nav',
				'class'	=> 	'post-nav',
				'desc'	=> 	'',
				'label'	=>	'Post Navigation',
				'std'	=> 	'true',
				'meta'	=> 	'true',
				'type'	=> 	'switch',
			),		
		)
			
	);
	$post_meta['subheader_settings'] = array(
		'name'		=> 	'Sub Header Settings',
		'id'		=> 	'tab-subheader-settings',
		'class'		=> 	'',
		'icon'		=> 	'icon-upload2',				
		'desc'		=> 	'text',				
		'fields'	=>	array(

			array(
				'name'	=> 	'header_style',
				'id'	=> 	'header_style',
				'class'	=> 	'dropdown',
				'desc'	=> 	'',
				'label'	=>	'Sub Header',
				'style'	=>	'image',
				'std'	=> 	'header1',
				'meta'	=> 	'true',
				'type'	=> 	'select',
				'option'=>	array(
					'default'		=>	'Default',
					'breadcrumb'	=>	'Breadcrumb',
					'no_subheader'	=>	'NO Subheader',
 				)
			),

		)
			
	);

	$post_meta['post_sidebar'] = array(
		'name'		=> 	'Sidebar',
		'id'		=> 	'tab-post-sidebar-settings',
		'class'		=> 	'',
		'icon'		=> 	'icon-files-empty',				
		'desc'		=> 	'text',				
		'fields'	=>	array(
			array(
				'name'	=> 	'osum_sidebar_layout',
				'id'	=> 	'sidebar_layout',
				'class'	=> 	'sidebar-layout',
				'desc'	=> 	'',
				'label'	=>	'Layout',
				'style'	=>  'image',
				'std'	=> 	'right_sidebar',
				'meta'	=> 	'true',
				'type'	=> 	'radio',
				'option'=>	array(
					'left_sidebar'	=>	'left sidebar',
					'full_width'	=>	'full width',
					'right_sidebar'	=>	'right sidebar',
				)
			),
			array(
				'name'	=> 	'osum_sidebar',
				'id'	=> 	'sidebar',
				'class'	=> 	'sidebar',
				'desc'	=> 	'',
				'label'	=>	'Sidebar',
				'std'	=> 	'sidebar-1',
				'meta'	=> 	'true',
				'type'	=> 	'select',
				'option'=>	osum_sidebars_list()
			)
 		)
	);
	if(function_exists('fw') and function_exists('get_populated_sliders_choices')){
		$choices = fw()->extensions->get('slider')->get_populated_sliders_choices();
	}else{
		$choices = '';
	}
	$post_meta['post_options'] = array(
		'name'		=> 	'Post Options',
		'id'		=> 	'tab-post-options-settings',
		'class'		=> 	'',
		'icon'		=> 	'icon-files-empty',				
		'desc'		=> 	'text',				
		'fields'	=>	array(
			array(
				'name'	=> 	'osum_post_options',
				'id'	=> 	'osum_post_options',
				'class'	=> 	'post-options',
				'desc'	=> 	'',
				'label'	=>	'Post Options',
				'std'	=> 	'image',
				'meta'	=> 	'true',
				'type'	=> 	'select_sh',
				'option'=>	array(
					'audio'	=>	'Audio',
					'video'	=>	'Video',
					'image'	=>	'Image',
					'slider' =>	'Slider/Gallery',
				)
			),
			array(
				'name'	=> 	'osum_audio_url',
				'id'	=> 	'audio-url',
				'class'	=> 	'audio-url audio hide',
				'desc'	=> 	'',
				'label'	=>	'Audio URL',
				'std'	=> 	'',
				'meta'	=> 	'true',
				'type'	=> 	'text',
			),
			array(
				'name'	=> 	'osum_video_url',
				'id'	=> 	'video-url',
				'class'	=> 	'video-url video hide',
				'desc'	=> 	'',
				'label'	=>	'Video URL',
				'std'	=> 	'',
				'meta'	=> 	'true',
				'type'	=> 	'text',
			),
			array(
				'name'	=> 	'osum_post_gallery',
				'id'	=> 	'post-gallery',
				'class'	=> 	'post-gallery slider hide',
				'desc'	=> 	'',
				'label'	=>	'Post Gallery',
				'std'	=> 	'',
				'meta'	=> 	'true',
				'type'	=> 	'select',
				'option' => $choices
			)
 		)
	);

	return	$post_meta;
}


function osum_get_fields($post_meta){
	$post_fields = array();
	foreach($post_meta as $meta){
		foreach($meta['fields'] as $field){
			if(isset($field['std']))
			$post_fields[$field['name']] = $field['std'];
		}
	}
	return $post_fields;
}

function add_post_metabox($post_meta) {
	$post_meta = post_options();
	 $post_action = array(
		'name'		=> 	__('Post Meta','osum'),
		'id'		=> 	'post_meta_box',
		'type'		=>	'post',
	);
	 $post_fields = osum_get_fields($post_meta);
	 new someClass($post_fields,$post_action,$post_meta);
}
	add_action( 'admin_init', 'add_post_metabox' );
