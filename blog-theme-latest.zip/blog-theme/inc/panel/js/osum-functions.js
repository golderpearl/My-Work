function save_main_options_ajax() {
	"use strict"
	 jQuery('#option-panel').submit( function (e) { 
	   	    e.preventDefault();

         /*   var b       =  jQuery(this).serialize(),
                optdata =  { action : "options.php", data: b };

            $.post( ajaxurl, b, function (response) {
                if (response == 1 ) { alert('sucess'); }
                else { alert(optdata);}
            });*/
			 var overlay = jQuery( document.getElementById( 'osum-loading' ) );
			 overlay.fadeIn();
       	var data = jQuery('#option-panel input,#option-panel select,#option-panel textarea[name!=export]').serialize();

	    jQuery.ajax(
            {
                type: "post",
               	dataType: "json",
                url: ajaxurl, 
               	data: {
					action: 'osum_ajax_save',
                 //   nonce: $nonce,
                    'opt_name': 'osum_theme_options',
                    data: jQuery('#option-panel').serialize()
                },
                error: function( response ) {
                    if ( !window.console ) console = {};
                    console.log = console.log || function( name, data ) {
                    };
                   // console.log( redux.ajax.console );
                    console.log( response.responseText );
                    jQuery( '.redux-action_bar input' ).removeAttr( 'disabled' );
                    overlay.fadeOut( 'fast' );
                    jQuery( '.redux-action_bar .spinner' ).fadeOut( 'fast' );
                   // alert( redux.ajax.alert );
                },
                success: function( response ) {
                    if ( response.action && response.action == "reload" ) {
                        location.reload(true);
                    } else if ( response.status == "success" ) {
                        jQuery( '.redux-action_bar input' ).removeAttr( 'disabled' );
                        overlay.fadeOut( 'fast' );
                        jQuery( '.redux-action_bar .spinner' ).fadeOut( 'fast' );
                        redux.options = response.options;
                        //redux.defaults = response.defaults;
                        redux.errors = response.errors;
                        redux.warnings = response.warnings;

                        $notification_bar.html( response.notification_bar ).slideDown( 'fast' );
                        if ( response.errors !== null || response.warnings !== null ) {
                            $.redux.notices();
                        }
                        var $save_notice = $( document.getElementById( 'redux_notification_bar' ) ).find( '.saved_notice' );
                        $save_notice.slideDown();
                        $save_notice.delay( 4000 ).slideUp();
                    } else {
                        jQuery( '.redux-action_bar input' ).removeAttr( 'disabled' );
                        jQuery( '.redux-action_bar .spinner' ).fadeOut( 'fast' );
                        overlay.fadeOut( 'fast' );
                        jQuery( '.wrap h2:first' ).parent().append( '<div class="error redux_ajax_save_error" style="display:none;"><p>' + response.status + '</p></div>' );
                        jQuery( '.redux_ajax_save_error' ).slideDown();
                        jQuery( "html, body" ).animate( {scrollTop: 0}, "slow" );
                    }
                }
            }
        );
	        return false;               
        });
      
    }
function reset_main_options_ajax() {
	"use strict"
	 jQuery('#option-panel').submit( function (e) { 
	  	e.preventDefault();
         /*   var b       =  jQuery(this).serialize(),
                optdata =  { action : "options.php", data: b };

            $.post( ajaxurl, b, function (response) {
                if (response == 1 ) { alert('sucess'); }
                else { alert(optdata);}
            });*/
		var overlay = jQuery( document.getElementById( 'osum-loading' ) );
		overlay.fadeIn();
       	var data = jQuery('#option-panel').serialize();

	    jQuery.ajax({
                type: "post",
               	dataType: "json",
                url: ajaxurl, 
               	data: {
					action: 'osum_ajax_reset',
                 //   nonce: $nonce,
                    'opt_name': 'osum_theme_options',
                    data: jQuery('#option-panel').serialize()
                },
                error: function( response ) {
                    if ( !window.console ) console = {};
                    console.log = console.log || function( name, data ) {
                    };
                   // console.log( redux.ajax.console );
                    console.log( response.responseText );
                    jQuery( '.redux-action_bar input' ).removeAttr( 'disabled' );
                    overlay.fadeOut( 'fast' );
                    jQuery( '.redux-action_bar .spinner' ).fadeOut( 'fast' );
                   // alert( redux.ajax.alert );
                },
                success: function( response ) {
					location.reload(true);

                    if ( response.status == "success" ) {
                        location.reload(true);
                    } else if ( response.status == "success" ) {
                        jQuery( '.redux-action_bar input' ).removeAttr( 'disabled' );
                        overlay.fadeOut( 'fast' );
                        jQuery( '.redux-action_bar .spinner' ).fadeOut( 'fast' );
                        redux.options = response.options;
                        //redux.defaults = response.defaults;
                        redux.errors = response.errors;
                        redux.warnings = response.warnings;

                        $notification_bar.html( response.notification_bar ).slideDown( 'fast' );
                        if ( response.errors !== null || response.warnings !== null ) {
                            $.redux.notices();
                        }
                        var $save_notice = $( document.getElementById( 'redux_notification_bar' ) ).find( '.saved_notice' );
                        $save_notice.slideDown();
                        $save_notice.delay( 4000 ).slideUp();
                    } else {
                        jQuery( '.redux-action_bar input' ).removeAttr( 'disabled' );
                        jQuery( '.redux-action_bar .spinner' ).fadeOut( 'fast' );
                        overlay.fadeOut( 'fast' );
                        jQuery( '.wrap h2:first' ).parent().append( '<div class="error redux_ajax_save_error" style="display:none;"><p>' + response.status + '</p></div>' );
                        jQuery( '.redux_ajax_save_error' ).slideDown();
                        jQuery( "html, body" ).animate( {scrollTop: 0}, "slow" );
                    }
                }
            }
        );
	        return false;               
        });
      
    }

jQuery(document).ready(function($){
    var slctn = jQuery('#osum_post_options');
    var vdo = jQuery('#video-url');
    var ado = jQuery('#audio-url');
    var gal = jQuery('#osum_post_gallery');

    if ( slctn == 'video' ) {
        if( jQuery(vdo).length() > 0 ) {
            jQuery(this).parent('li').css('display', 'list-item');
        }
    }
    if ( slctn == 'audio' ) {
        if( jQuery(ado).length() > 0 ) {
            jQuery(this).parent('li').css('display', 'list-item');
        }
    }
    if ( slctn == 'slider' ) {
        if( jQuery(gal).length() > 0 ) {
            jQuery(this).parent('li').css('display', 'list-item');
        }
    }

	jQuery(".right-side input").click(function(e) {
		if($( this ).attr( 'name' ) == "osum_reset"){
			if(confirm("Are you sure you want to reset custom changes!")){
				reset_main_options_ajax();
			
			}else{
				return false;
			}
		}else if($( this ).attr( 'name' ) == "osum_save"){
      		save_main_options_ajax();	
		}

    });
	
	var $b = jQuery('body');
  // Radio
    $b.on('click', '.option input[type="radio"]', function () {
        var $opt = jQuery(this);
        $opt.parent('.option').addClass('checked').siblings('.option').removeClass('checked');
    });
	    // Checkbox
    $b.on('click', '.option input[type="checkbox"]', function () {
        var $opt = jQuery(this);
        $opt.parent('.option').toggleClass('checked');
    });
	var myOptions = {
        // you can declare a default color here,
        // or in the data-default-color attribute on the input
        defaultColor: false,
        // a callback to fire whenever the color changes to a valid color
        change: function(event, ui){},
        // a callback to fire when the input is emptied or an invalid color
        clear: function() {},
        // hide the color picker controls on load
        hide: true,
    	//width : 200,
        // show a group of common colors beneath the square
        // or, supply an array of colors to customize further
        palettes: true
    };
	jQuery('.my-color-field').wpColorPicker(myOptions);
	jQuery( "#meta-tab" ).tabs().removeClass("ui-widget-content");
    jQuery( "#tabs" ).tabs().removeClass("ui-tabs ui-widget ui-corner-all ui-widget-content").addClass( "ui-tabs-vertical ui-helper-clearfix" ); 
	jQuery( "#tabs li" ).removeClass( "ui-state-default ui-state-hover  ui-corner-top" ).addClass( "ui-corner-left" );
	jQuery(".right-section").removeClass("tab-section ui-tabs-panel ui-widget-content ui-corner-bottom");

    jQuery(".js-example-basic-single").select2({
        placeholder: "Arial, Helvetica, SanSerif",
        allowClear: true
    });
     
    jQuery('a.delete').click(function(event) {
        jQuery(this).next('img').remove();
        if (jQuery(this).val() == "search")
            jQuery(this).val("");
        jQuery('input#logo_url')
        return false
    });
});
function osum_showhide(id,value) {
	jQuery('.hide').hide('200');
	jQuery('.' +value).show('200');
}