jQuery(document).ready(function($) {
	/*$('#colorSelector').ColorPicker({
		color: '#0000ff',
		onShow: function (colpkr) {
			$(colpkr).fadeIn(500);
			return false;
		},
		onHide: function (colpkr) {
			$(colpkr).fadeOut(500);
			return false;
		},
		onChange: function (hsb, hex, rgb) {
			$('#colorSelector div').css('backgroundColor', '#' + hex);
		}
	});*/

    var $b = $('body');

    // Radio
    $b.on('change', '.formui-radio input[type="radio"]', function () {
        var $opt = $(this);
        $opt.parent('.option').addClass('checked').siblings('.option').removeClass('checked');
    });

    // Checkbox
    $b.on('change', '.formui-checkbox input[type="checkbox"]', function () {
        var $opt = $(this);
        $opt.parent('.option').toggleClass('checked');
    });

    /*$( "#option-panel" ).tabs();
    $( "#option-panel" ).tabs().addClass( "ui-tabs-vertical ui-helper-clearfix" );
    $( "#option-panel li" ).removeClass( "ui-corner-top" ).addClass( "ui-corner-left" );*/


    //$( "#slider" ).slider();
    /*$("#slider").slider({
	    range: "min",
	    value: 3,
	    min: 1,
	    max: 15000,
	    //this gets a live reading of the value and prints it on the page
	    slide: function(event, ui) {
	      $("#ratingResult").text(ui.value);
	    },
	    //this updates the value of your hidden field when user stops dragging
	    change: function(event, ui) {
	      $('#rateToPost').attr('value', ui.value);
	    }
	});*/
});