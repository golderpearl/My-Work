jQuery(document).ready(function(){
	"use strict";
/*	jQuery('#upload_image_button').click(function(){
		wp.media.editor.send.attachment = function(props, attachment){
			jQuery('#upload_image').val(attachment.url);
		}
	
		wp.media.editor.open(this);
	
		return false;
	});*/
	
	jQuery("#upload_image_button").live('click', function($) {
	"use strict";
	var id = jQuery(this).attr("name");
	var custom_uploader = wp.media({
		title: 'Select Media File',
		button: {
			text: 'Add Media'
		},
		multiple: false
	})
		.on('select', function() {
			var attachment = custom_uploader.state().get('selection').first().toJSON();
			jQuery('#' + id + '_url').val(attachment.url);
			jQuery('#' + id + '_src').attr('src', attachment.url);
			jQuery('#' + id + '_wrap').show();
		}).open();
		
});
});