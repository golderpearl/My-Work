<?php
/**
 * Calls the class on the post edit screen.
 */

function page_options(){
	global $osum_form_field,$page_meta;
	$page_meta = array();
	$page_meta['subheader_settings'] = array(
		'name'		=> 	'Sub Header Settings',
		'id'		=> 	'tab-subheader-settings',
		'class'		=> 	'',
		'icon'		=> 	'icon-upload2',				
		'desc'		=> 	'text',				
		'fields'	=>	array(

			array(
				'name'	=> 	'osum_header_style',
				'id'	=> 	'header_style',
				'class'	=> 	'dropdown',
				'desc'	=> 	'',
				'label'	=>	'Sub Header',
				'style'	=>	'image',
				'std'	=> 	'header1',
				'meta'	=> 	'true',
				'type'	=> 	'select',
				'option'=>	array(
					'default'		=>	'Default',
					'breadcrumb'	=>	'Breadcrumb',
					'no_subheader'	=>	'NO Subheader',
 				)
			),

		array(
				'name'	=> 	'osum_header_subtitle',
				'id'	=> 	'header-subtitle',
				'class'	=> 	'header-subtitle',
				'desc'	=> 	'',
				'label'	=>	'Sub Title',
				'std'	=> 	'test',
				'meta'	=> 	'true',
				'type'	=> 	'textarea'
			),			
/*			array(
				'name'	=> 	'text1',
				'id'	=> 	'',
				'class'	=> 	'',
				'desc'	=> 	'',
				'label'	=>	'text field 1',
				'std'	=> 	'text',
				'type'	=> 	'text',
			),
			
			array(
				'name'	=> 	'gender',
				'id'	=> 	'gender',
				'class'	=> 	'gender',
				'desc'	=> 	'',
				'label'	=>	'radio button',
				'std'	=> 	'abc',
				'type'	=> 	'radio',
				'option'=>	array(
					'male'		=>	'Male',
					'female'	=>	'Female',
				)
			),

			array(
				'name'	=> 	'checkbox1',
				'id'	=> 	'checkbox',
				'class'	=> 	'',
				'desc'	=> 	'',
				'label'	=>	'checkbox',
				'std'	=> 	'1',
				'type'	=> 	'checkbox',
			),			
			array(
				'name'	=> 	'dropdown',
				'id'	=> 	'dropdown',
				'class'	=> 	'dropdown',
				'desc'	=> 	'',
				'label'	=>	'dropdown list',
				'std'	=> 	'option1',
				'type'	=> 	'select',
				'option'=>	array(
					'option1'	=>	'Option 1',
					'option2'	=>	'Option 2',
					'option3'	=>	'Option 3',
					'option4'	=>	'Option 4',
				)
			),		
			array(
				'name'	=> 	'color',
				'id'	=> 	'color',
				'class'	=> 	'color',
				'desc'	=> 	'',
				'label'	=>	'color',
				'std'	=> 	'#000',
				'type'	=> 	'color',
			),			
			array(
				'name'	=> 	'pattern',
				'id'	=> 	'pattern',
				'class'	=> 	'pattern',
				'desc'	=> 	'',
				'label'	=>	'Background Pattern',
				'std'	=> 	'pattern1.jpeg',
				'type'	=> 	'radio_bg',
				'option'=>	array(
					'male'		=>	'Male',
					'male'		=>	'Male',
					'male'		=>	'Male',
					'male'		=>	'Male',
					'masdle'	=>	'Male',
					'maasdsale'	=>	'Male',
					'asdsad'	=>	'Male',
					'female'	=>	'Female',
				)
			),
			*/	
		)
			
	);
	/*
	$page_meta['seo_settings'] = array(
		'name'		=> 	'Seo Settings',
		'id'		=> 	'tab-seo-settings',
		'class'		=> 	'',
		'icon'		=> 	'icon-download3',				
		'desc'		=> 	'text',				
		'fields'	=>	array(

			array(
				'name'	=> 	'copyright',
				'id'	=> 	'copyright',
				'class'	=> 	'copyright',
				'desc'	=> 	'',
				'label'	=>	'Copyright',
				'std'	=> 	'&copy 2001 - 2015 Konstructions, LCC. All rights reserved.',
				'type'	=> 	'text',
			),	
		
					array(
				'name'	=> 	'text1',
				'id'	=> 	'',
				'class'	=> 	'',
				'desc'	=> 	'',
				'label'	=>	'text field 1',
				'std'	=> 	'text',
				'type'	=> 	'text',
			),
			array(
				'name'	=> 	'textarea',
				'id'	=> 	'textarea',
				'class'	=> 	'',
				'desc'	=> 	'',
				'label'	=>	'text area',
				'std'	=> 	'textarea',
				'type'	=> 	'textarea',
			),

			array(
				'name'	=> 	'dropdown',
				'id'	=> 	'dropdown',
				'class'	=> 	'dropdown',
				'desc'	=> 	'',
				'label'	=>	'dropdown list',
				'std'	=> 	'option1',
				'type'	=> 	'select',
				'option'=>	array(
					'option1'	=>	'Option 1',
					'option2'	=>	'Option 2',
					'option3'	=>	'Option 3',
					'option4'	=>	'Option 4',
				)
			),			

			array(
				'name'	=> 	'color',
				'id'	=> 	'color',
				'class'	=> 	'color',
				'desc'	=> 	'',
				'label'	=>	'color',
				'std'	=> 	'#000',
				'type'	=> 	'color',
			),			
			array(
				'name'	=> 	'pattern',
				'id'	=> 	'pattern',
				'class'	=> 	'pattern',
				'desc'	=> 	'',
				'label'	=>	'Background Pattern',
				'std'	=> 	'pattern1.jpeg',
				'type'	=> 	'radio_bg',
				'option'=>	array(
					'male'		=>	'Male',
					'male'		=>	'Male',
					'male'		=>	'Male',
					'male'		=>	'Male',
					'masdle'		=>	'Male',
					'maasdsale'		=>	'Male',
					'asdsad'		=>	'Male',
					'female'	=>	'Female',
				)
			),
		)
			
	); 			*/

	$page_meta['page_sidebar'] = array(
		'name'		=> 	'Sidebar',
		'id'		=> 	'tab-page-sidebar-settings',
		'class'		=> 	'',
		'icon'		=> 	'icon-files-empty',				
		'desc'		=> 	'text',				
		'fields'	=>	array(
			array(
				'name'	=> 	'osum_sidebar_layout',
				'id'	=> 	'sidebar_layout',
				'class'	=> 	'sidebar-layout',
				'desc'	=> 	'',
				'label'	=>	'Layout',
				'style'	=>  'image',
				'std'	=> 	'full_width',
				'meta'	=> 	'true',
				'type'	=> 	'radio',
				'option'=>	array(
					'left_sidebar'	=>	'left sidebar',
					'full_width'	=>	'full width',
					'right_sidebar'	=>	'right sidebar',
				)
			),
			array(
				'name'	=> 	'osum_sidebar',
				'id'	=> 	'layout',
				'class'	=> 	'layout',
				'desc'	=> 	'',
				'label'	=>	'Sidebar',
				'std'	=> 	'',
				'meta'	=> 	'true',
				'type'	=> 	'select',
				'option'=>	osum_sidebars_list()
			)
 		)
			
	);

	return	$page_meta;
}
	
/*
function osum_get_fields($post_meta){
	$post_fields = array();
	foreach($post_meta as $meta){
		foreach($meta['fields'] as $field){
			if(isset($field['std']))
			$post_fields[$field['name']] = $field['std'];
		}
	}
	return $post_fields;
}*/

function add_page_metabox() {
	$page_meta = page_options();
	 $page_action = array(
		'name'		=> 	__('Page Meta','osum'),
		'id'		=> 	'page_meta_box',
		'type'		=>	'page',
	);
	 $page_fields = osum_get_fields($page_meta);
	 new someClass($page_fields,$page_action,$page_meta);
}
	add_action( 'admin_init', 'add_page_metabox' );
?>