<?php
// Prevent loading this file directly
    defined( 'ABSPATH' ) || exit;

// Meta Box Class
    if ( ! class_exists( 'someClass' ) )
    {/**
 * The Class.
 */
class someClass {
 
    /**
     * Hook into the appropriate actions when the class is constructed.
     */
	public $post_fields;
	public $osum_post_meta;
	public $type;
	public $meta_array;
    public function __construct($post_fields,$meta_action,$meta_array) {
		if ( ! is_admin() )
			return;	
		$this->meta_action = $meta_action;	
		$this->abc = $post_fields;
		$this->osum_post_meta = 'osum_meta_key';
		$this->meta_array = $meta_array;
       	add_action( 'add_meta_boxes', array( $this, 'add_meta_box' ) );
       	add_action( 'save_post',      array( $this, 'save'         ) );
    }
 
    /**
     * Adds the meta box container.
     */
    public function add_meta_box( $post_type ) {
        // Limit meta box to certain post types.
        $type = array( 'post' );
 
            add_meta_box(
                $this->meta_action['id'],
                $this->meta_action['name'],
                array( $this, 'render_meta_box_content' ),
                $this->meta_action['type'],
                'normal',
                'high'
            );
    }
 
    /**
     * Save the meta when the post is saved.
     *
     * @param int $post_id The ID of the post being saved.
     */
    public function save( $post_id  ='') {
		global $post;
		if(defined( 'DOING_AUTOSAVE') && DOING_AUTOSAVE) {
			return;
		}
		$meta_data = array();
		$osum_post_meta= $this->osum_post_meta;
		
        /*
         * We need to verify this came from the our screen and with proper authorization,
         * because save_post can be triggered at other times.
         */
        // Check if our nonce is set.
		if(isset($_POST) and $_POST <> ''){
			foreach($_POST as $key => $value){
				if( strstr( $key, 'osum_' ) ) {
					$meta_data[$key]  = $value;
					update_post_meta( $post_id, $key,$value );
				}
			}
			update_post_meta( $post_id, $osum_post_meta, $meta_data );
		}

   /* OK, it's safe for us to save the data now. */
 
        // Sanitize the user input.
 		
        // Update the meta field.
    }
 
 
    /**
     * Render Meta Box content.
     *
     * @param WP_Post $post The post object.
     */
     public function render_meta_box_content( $post ) {
 
        // Add an nonce field so we can check for it later.
        wp_nonce_field( 'myplugin_inner_custom_box', 'myplugin_inner_custom_box_nonce' );
 
        // Use get_post_meta to retrieve an existing value from the database.

        // Display the form, using the current value.
       	$meta_array = $this->meta_array;
		echo '<div id="meta-tab" class="main-container">';
		echo '<ul>';
			osum_get_tab($meta_array);
		echo '</ul>';
		echo '<div id="osum-tab-content">';
			echo panel_nav($meta_array);
		echo '</div>';
		echo '</div>';
    }
}
}