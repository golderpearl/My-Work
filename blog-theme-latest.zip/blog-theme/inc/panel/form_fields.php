<?php 

if(! class_exists('osumFields')){
	class osumFields{
		 private static $_instance;
 		 public static function get_instance() {
    		if ( ! isset( self::$_instance ) ) {
      			self::$_instance = new self;
    		}
  	  		return self::$_instance;
  		}
 		private function __construct(){
			add_action('do_feed_osum_theme_options', array(&$this, '_download_options'), 1, 1);

		}
		public function osum_label($label = ''){
			if(isset($label) and $label <> ''){
				return '<label>'.$label.'</label>';
			}
		}
		public function osum_heading_field($field_pram = array()){
 			extract($field_pram);
			$output = '<div class="main-title">';
				$output .= '<h1>'.$label.'</h1>';
				$output .= '<h2>'.$desc.'</h2>';
			$output .= '</div>';
			return $output;
		}
		public function osum_sub_heading_field($field_pram = array()){
			extract($field_pram);
			$output = '<h3>'.$label.'</h3>';
			return $output;
		}
		public function osum_hinttext(){
			echo '<span>hint text</span>';
		}
		public function osum_link(){
			echo '<a href="" class="" id="" target="_blank">link text</a>';
		}
		public function osum_text_field($field_pram = array()){
 			extract($field_pram);
			$std	= $this->osum_validate_option($name,$std,$meta);
			$output = $this->osum_label($label);
			$output .='<input type="text" name="'.$name.'" id="'.$id.'" class="'.$id.' '.$type.'-field" value="'.$std.'">';
			return $output;
		}
		public function osum_textarea_field($field_pram = array()){
			global $osum_options;
 			extract($field_pram);
			$std	= $this->osum_validate_option($name,$std);
			$output = $this->osum_label($label);
			$output .='<textarea name="'.$name.'" id="'.$id.'" class="'.$id.' '.$type.'-field" rows="5" cols="70">'.$std.'</textarea>';
			return $output;
		}
		public function osum_checkbox_field($field_pram = array()){
 			extract($field_pram);
			$output = $this->osum_label($label);
			$std	= $this->osum_validate_option($name,$std);
			$checked = (isset($std) and $std == 'on') ? 'checked' : '';
			$output .= '<div class="checkbox-section"><lable class="formui-checkbox option '.$checked.'">';
				$output .='<input type="checkbox" name="'.$name.'" id="'.$id.'" class="'.$id.' '.$type.'-field" '.checked( $std, 'on', false ).' >';
			$output .= '</label></div>';
			return $output;
		}
		public function osum_switch_field($field_pram = array()){
 			extract($field_pram);
			$output = $this->osum_label($label);
			$std	= $this->osum_validate_option($name,$std,$meta);
			$true = $false = '';
			if($std == 'true') { $true = 'checked="checked"';}else{ $false = 'checked="checked"';}
			$output .= '<div class="on-off">';
				$output .='<input type="radio" name="'.$name.'" id="toggle-on" '.$true.' class="'.$class.' toggle toggle-left" value="true" >';
				$output .= '<label class="btn" for="toggle-on">On</label>';
				$output .='<input type="radio" name="'.$name.'" id="toggle-off" '.$false.' class="'.$class.' toggle toggle-right" value="false" >';
				$output .= '<label class="btn" for="toggle-off">Off</label>';
			$output .= '</div>';
			return $output;
		}
		public function osum_radio_field($field_pram = array()){
 			$counter = 0;
 			extract($field_pram);
			$output = $this->osum_label($label);
			$std	= $this->osum_validate_option($name,$std,$meta);
			$style	= (isset($style) and $style <> '') ? $style : 'normal';
			if($style == 'image'){
				$style_class =  'layout-bg';
				$signal	= true;
				
			}else{
				$style_class =  'radio-bullets';
				$signal	= false;
			}
			$output .='<div class="'.$style_class.'">';
			foreach($option as $key => $val){
 				$counter++;
				$checked = ($std == $key) ? 'checked' : '';
				$output .= '<label class="formui-radio option '.$checked.'">';
					if($signal)
					$output .= '<img src="'.get_template_directory_uri().'/inc/panel/images/'.$key.'.png" />';
					$output .= '<input type="radio"  name="'.$name.'" id="'.$id.'-'.$counter.'" class="'.$class.'" value="'.$key.'" '.checked( $std, $key, false ).'>';
					$output .= $val;
				$output .= '</label>';
			}
			$output .= '</div>';
			return $output;
		}
		public function osum_radio_bg_field($field_pram = array()){
 			$counter = 0;
			extract($field_pram);
			$output = $this->osum_label($label);
			$std	= $this->osum_validate_option($name,$std);
			$output .='<div class="checkbox-section">';
			foreach($option as $key => $val){
				$counter++;
				$checked = ($std == $key) ? 'checked' : '';
				$output .= '<label class="formui-checkbox option '.$checked.'">';
					$output .=  '<img src="'.get_template_directory_uri().'/inc/panel/images/patterns/'.$key.'.jpg" />';
					$output .= '<input type="radio"  name="'.$name.'" id="'.$id.'-'.$counter.'" class="'.$class.'" value="'.$key.'" '.checked( $std, $key, false ).'>';
				$output .= '</label>';
			}
			$output .= '</div>';
			return $output;
		}
		public function osum_button_field( $field_pram = array(), $value = ''){
			echo '<button type="'.$field_pram['type'].'" name="'.$field_pram['name'].'" id="'.$field_pram['name'].'" class="'.$field_pram['name'].'" value="'.$field_pram['default'].'">'.$field_pram['default'].'</button>';
		}
		public function osum_hidden_field(){
			echo '<input type="hidden" name="" value="" id="" class="" >';
		}
		public function osum_editor_field(){
			$content	= 'osum sample content';
			$editor_id 	= 'osum_editor_id';
			$settings	=  array();
			echo wp_editor( $content, $editor_id, $settings = array() );
		}
		public function osum_editor_small(){
			$content	= 'osum sample content';
			$editor_id 	= 'osum_editor_id';
			$settings	=  array();
			echo wp_editor( $content, $editor_id, $settings = array() );
		}
		public function osum_select_field($field_pram = array()){
 			extract($field_pram);
			$std	= $this->osum_validate_option($name,$std,$meta);
			$output = $this->osum_label($label);
			$output .='<div class="formui-dropdown">';
				$output .='<select name="'.$name.'" id="'.$name.'" class="'.$name.' js-example-basic-single">';
					foreach($option as $key => $val){
						$output .='<option value="'.$key.'" '.selected($key,$std,false).'>'.$val.'</option>';
					}
				$output .='</select>';
			$output .='</div>';
			return $output;

		}
		public function osum_select_sh_field($field_pram = array()){
 			extract($field_pram);
			$std	= $this->osum_validate_option($name,$std,$meta);
			$output = $this->osum_label($label);
			$output .='<div class="formui-dropdown">';
				$output .='<select name="'.$name.'" id="'.$name.'" class="'.$name.' '.$type.'-field js-example-basic-single" onchange="javascript:osum_showhide('.$name.',this.value)">';
					foreach($option as $key => $val){
						$output .='<option value="'.$key.'" '.selected($key,$std,false).'>'.$val.'</option>';
					}
				$output .='</select>';
			$output .='</div>';
			return $output;

		}
		public function osum_multiselect_field(){
			echo '<select name="" id="" class="js-example-basic-single" multiple="multiple">
				<option value="option1"></option>
				<option value="option2"></option>
			</select>';
		}
		public function osum_media_field($field_pram = array()){
			extract($field_pram);
			$std	= $this->osum_validate_option($name,$std);
			$output = $this->osum_label($label);
			$output .= '<div class="logo-upload media-upload">';
				$output .= '<input type="text" name="'.$name.'" id="'.$id.'_url" class="'.$class.'" value="'.$std.'" >';
				$output .= '<input type="button" name="'.$name.'" id="upload_image_button" class="'.$class.'" value="upload" >';
			$output .= '</div>';
			if(isset($std) and $std <> ''){
				$output .= '<div class="logo-placed" id="'.$id.'_wrap">';
					$output .= '<a class="delete" href="#"><img alt="" src="'.get_template_directory_uri().'/inc/panel/images/delete.png"></a>';
					$output .= '<img alt="" src="'.$std.'" id="'.$id.'_src" >';
				$output .= '</div>';
			}
			return $output;
		}
		public function osum_file_field(){
			echo '<input type="file" name="" id="" class="" value="" >';
		}
		public function osum_range_field($field_pram = array()){
			extract($field_pram);
			$output = $this->osum_label($label);
			$std	= $this->osum_validate_option($name,$std);
			$output .='<div class="slider slider-range-val" id="slider-'.$id.'" data-min="'.$min.'" data-max="'.$max.'" data-step="'.$step.'" data-value="'.$std.'"></div>';
			$output .='<input type="text" name="'.$name.'" id="'.$id.'" class="input-small" value="'.$std.'" >';
			$output .='<script type="text/javascript">
							jQuery(document).ready(function($){
							   jQuery( "#slider-'.$id.'" ).each(function($){
								jQuery( "#slider-'.$id.'").slider({
							      	range: "min",
							      	value: jQuery(this).data("value"),
							      	min: jQuery(this).data("min"),
							      	max: jQuery(this).data("max"),
									step:jQuery(this).data("step"),
							      	slide: function( event, ui ) {
							        	jQuery( "#'.$id.'").val(ui.value );
							      	}
							    });
							   });
							});
						</script>';
			return $output;
		}
		public function osum_color_field($field_pram = array()){
 			extract($field_pram);
			$std	= $this->osum_validate_option($name,$std);
			$output = $this->osum_label($label);
			$output .= '<input type="text" name="'.$name.'" id="'.$id.'" class="my-color-field" value="'.$std.'" >';
			return $output;
		}
		public function osum_typography_field($field_pram = array()){
			global $osum_options;
			$default_fonts = array(
				"Arial, Helvetica, sans-serif"                         => "Arial, Helvetica, sans-serif",
				"'Arial Black', Gadget, sans-serif"                    => "'Arial Black', Gadget, sans-serif",
				"'Bookman Old Style', serif"                           => "'Bookman Old Style', serif",
				"'Comic Sans MS', cursive"                             => "'Comic Sans MS', cursive",
				"Courier, monospace"                                   => "Courier, monospace",
				"Garamond, serif"                                      => "Garamond, serif",
				"Georgia, serif"                                       => "Georgia, serif",
				"Impact, Charcoal, sans-serif"                         => "Impact, Charcoal, sans-serif",
				"'Lucida Console', Monaco, monospace"                  => "'Lucida Console', Monaco, monospace",
				"'Lucida Sans Unicode', 'Lucida Grande', sans-serif"   => "'Lucida Sans Unicode', 'Lucida Grande', sans-serif",
				"'MS Sans Serif', Geneva, sans-serif"                  => "'MS Sans Serif', Geneva, sans-serif",
				"'MS Serif', 'New York', sans-serif"                   => "'MS Serif', 'New York', sans-serif",
				"'Palatino Linotype', 'Book Antiqua', Palatino, serif" => "'Palatino Linotype', 'Book Antiqua', Palatino, serif",
				"Tahoma,Geneva, sans-serif"                            => "Tahoma, Geneva, sans-serif",
				"'Times New Roman', Times,serif"                       => "'Times New Roman', Times, serif",
				"'Trebuchet MS', Helvetica, sans-serif"                => "'Trebuchet MS', Helvetica, sans-serif",
				"Verdana, Geneva, sans-serif"                          => "Verdana, Geneva, sans-serif",
			);
			$font_style = array(
				'lighter'	=> 'Lighter',
				'normal'	=> 'Normal',
				'bold' 		=> 'Bold',
				'bolder' 	=> 'Bolder'
			);
 			extract($field_pram);
			// $std = wp_parse_args( $osum_options[$name], $std );

			$std	= $this->osum_validate_option($name,$option);

			$output = $this->osum_label($label);
			$output .='<div class="typo-wrapper">';
			$output .= '<label>'.__('Font Family','osum').'</label>';
			$output .='<div class="formui-dropdown">';
				$output .='<select name="'.$name.'[font-family]" id="'.$id.'-font-family" class="js-example-basic-single">';
					foreach($default_fonts as $key => $val){
						$output .='<option value="'.$key.'" '.selected($key,$std['font-family'],false).'>'.$val.'</option>';
					}
				$output .='</select>';
			$output .='</div>';
			$output .= '<label>'.__('Font Weight','osum').'</label>';
			$output .='<div class="formui-dropdown">';
				$output .='<select name="'.$name.'[font-style]" id="'.$id.'-font-style" class="js-example-basic-single">';
					foreach($font_style as $key => $val){
						$output .='<option value="'.$key.'" '.selected($key,$std['font-style'],false).'>'.$val.'</option>';
					}
				$output .='</select>';
			$output .='</div>';
			//$output .= '<input type="text" name="'.$name.'[]" id="'.$id.'" class="my-color-field" value="'.$std.'" >';
			$output .= '<label>'.__('Font Size','osum').'</label>';
			$output .='<div class="slider slider-range-val" id="slider-'.$id.'" data-min="8" data-max="50" data-step="1" 
			data-value="'.$std['font-size'].'"></div>';
			
			$output .= '<input type="text" name="'.$name.'[font-size]" id="'.$id.'-font-size" class="input-small" value="'.$std['font-size'].'" >';							
			$output .='<script type="text/javascript">
							jQuery(document).ready(function($){
							   jQuery( "#slider-'.$id.'" ).each(function($){
								jQuery( "#slider-'.$id.'").slider({
							      	range: "min",
							      	value: jQuery(this).data("value"),
							      	min: jQuery(this).data("min"),
							      	max: jQuery(this).data("max"),
									step:jQuery(this).data("step"),
							      	slide: function( event, ui ) {
							        	jQuery( "#'.$id.'-font-size").val(ui.value );
							      	}
							    });
							   });
							});
						</script>';
			$output .= '<label>'.__('Font Color','osum').'</label>';
			$output .= '<input type="text" name="'.$name.'[font-color]" id="'.$id.'-font-color" class="my-color-field" value="'.$std['font-color'].'" >';
			$output .='</div>';

			return $output;
		}
		
		public function osum_password_field(){
			echo '<input type="password" name="" id="" class="" value="" >';
		}
		public function osum_date_field(){
			echo '<input type="date" name="" id="" class="" value="" >';
		}
		public function osum_datetime_field(){
			echo '<input type="date" name="" id="" class="" value="" >';
		}
		public function osum_sidebar_field($field_pram = array()){
			global $osum_options;
			extract($field_pram);

			//$sidebar_list = isset($osum_options['sidebar_list']) and sizeof($osum_options['sidebar_list'] > 0) ? $osum_options['sidebar_list'] : '';
			$sidebar_list	= $this->osum_validate_option($name,$option);
			$output = "<script type='text/javascript'>";
			$output .= '
                var $ = jQuery;
                $(document).ready(function(){
                    $(".sidebar_management").on("click", ".delete", function(){
                        $(this).parent().remove();
                    });
                    $("#add_sidebar").click(function(){
                        $(".sidebar_management ul").append("<li>"+$("#new_sidebar_name").val()+" <a href=\'#\' class=\'delete\'>'.__("delete", 'osum').'</a> <input type=\'hidden\' name=\'sidebar_list[]\' value=\'"+$("#new_sidebar_name").val()+"\' /></li>");
                        $("#new_sidebar_name").val("");
                    })
                })';
    		$output .= "</script>";
   		 	$output .= "<div class='sidebar_management'>";
    		$output .= "<p><input type='text' id='new_sidebar_name' /> <input class='button-primary' type='button' id='add_sidebar' value='".__("add", 'osum')."' /></p>";
    		$output .= '<ul class="sidebar-list">';
		if(isset($osum_options['sidebar_list']))
		{
        $i = 0;
        foreach($sidebar_list as $sidebar)
        {
            $output .= "<li>".$sidebar." <a href='#' class='delete'>".__("delete", 'osum')."</a> 
			<input type='hidden' name='sidebar_list[]' value='".$sidebar."' /></li>";
            $i++;
        }
    }
     
    $output .= '</ul>';
     
    $output .= "</div>";
     
    return $output;
		}
		public function osum_import_field($field_pram = array()){
 			extract($field_pram);
			$std	= $this->osum_validate_option($name,$std);
			$output = $this->osum_label($label);
			$output .= '<input type="submit" name="'.$name.'" id="'.$id.'" class="button-primary '.$name.'" value="Import" >';
			return $output;
		}		
		public function osum_export_field($field_pram = array()){
 			extract($field_pram);
			//$std	= $this->osum_validate_option($name,$std);
			$output = $this->osum_label($label);
			$output .= '<textarea type="text" id="'.$id.'" class="'.$name.'" rows="6" >'.serialize(osum_get_options()).'</textarea>';
			$output .= '<a href="'.add_query_arg(array('feed' => 'osum_theme_options', 'action' => 'download_options', 'secret' => md5(AUTH_KEY.SECURE_AUTH_KEY)), site_url()).'" id="redux-opts-export-code-dl" class="button-primary">Download</a>';
			return $output;
		}
		public function _download_options() {
            //-'.$this->args['opt_name']
            if(!isset($_GET['secret']) || $_GET['secret'] != md5(AUTH_KEY.SECURE_AUTH_KEY)) {
                wp_die('Invalid Secret for options use');
                exit;
            }

            if(!isset($_GET['feed'])){
                wp_die('No Feed Defined');
                exit;
            }

            $backup_options = get_option('osum_theme_options');
            //$backup_options['redux-opts-backup'] = '1';
            $content = '###' . serialize($backup_options) . '###';

            if(isset($_GET['action']) && $_GET['action'] == 'download_options') {
                header('Content-Description: File Transfer');
                header('Content-type: application/txt');
                header('Content-Disposition: attachment; filename="osum_theme_options' . date('d-m-Y') . '.txt"');
                header('Content-Transfer-Encoding: binary');
                header('Expires: 0');
                header('Cache-Control: must-revalidate');
                header('Pragma: public');
                echo $content;
                exit;
            } else {
                echo $content;
                exit;
            }
        }
				
		public function osum_validate_option($name,$std,$meta = 'false'){
			global $post,$osum_options;
			if($meta == 'true'){
				$meta_value = get_post_meta($post->ID,$name,true);
				$std = (isset($meta_value) and $meta_value <> '') ? $meta_value : $std;
			}elseif($meta == 'false'){
				$std = (isset($osum_options[$name]) and $osum_options[$name] <> '') ? $osum_options[$name] : $std;
			}
			return $std;
		
		}
	
	}
}
global $osum_form_field;
$osum_form_field = osumFields::get_instance();
?>