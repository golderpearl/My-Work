<?php ?>
    <div class="item">
        <div class="testimonials-text">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/images/comma.png" alt="">
				<?php echo apply_filters('the_content', substr(get_the_content(), 0,350) ); ?></p>
        </div>
    </div>

