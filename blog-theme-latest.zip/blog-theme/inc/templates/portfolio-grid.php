<?php global $post;
$cat_list = '';
 $categories_list = get_the_terms( $post->ID, 'portfolio-category' );
 //print_r($categories_list);
 foreach($categories_list as $cat){
	 $cat_list = $cat->slug.' '; 
	};
 ?>
    <li class="mix <?php echo sanitize_html_class($cat_list) ?>" data-my-order="<?php echo esc_attr($cat_list); ?>">
        <article> 
            <figure>
                <?php echo osum_portfolio_thumbnail('size-568x404'); ?>
                <figcaption>
                    <?php the_title( '<h2 class="page-title">', '</h2>' ); ?>
                    <p><?php echo apply_filters('the_content', substr(get_the_excerpt(), 0, 90) ); ?></p>
                    <a href="<?php echo esc_url( get_permalink() ); ?>" class="reaadmore"><?php _e('View Project','osum'); ?></a>
                </figcaption>
            </figure>
        </article>
    </li>
