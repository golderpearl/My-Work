<?php
/**
 * The default template for displaying content
 *
 * Used for both single and index/archive/search.
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */
?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<?php
		// Post thumbnail.
		if(is_single()){
			osum_post_thumbnail('size-1170x495');
			the_title( '<h1 class="page-title">', '</h1>' );
			?>
            <div class="post-options">
                <div class="category-section">
					<?php osum_post_meta(); ?>
    				<?php edit_post_link( __( 'Edit', 'osum' ), '<span class="edit-link">', '</span>' ); ?>
               	</div>
                <div class="social-sharing">
                    <ul>
                        <li><a href="#"><i class="icon icon-facebook"></i></a></li>
                        <li><a href="#"><i class="icon icon-google-plus"></i></a></li>
                        <li><a href="#"><i class="icon icon-linkedin2"></i></a></li>
                        <li><a href="#"><i class="icon icon-twitter"></i></a></li>
                    </ul>
                </div>
            </div>
            <div class="post-text">
                <?php
                    /* translators: %s: Name of current post */
                    the_content( sprintf(
                        __( 'Continue reading %s', 'osum' ),
                        the_title( '<span class="screen-reader-text">', '</span>', false )
                    ) );
                    wp_link_pages( array(
                        'before'      => '<div class="page-links"><span class="page-links-title">' . __( 'Pages:', 'osum' ) . '</span>',
                        'after'       => '</div>',
                        'link_before' => '<span>',
                        'link_after'  => '</span>',
                        'pagelink'    => '<span class="screen-reader-text">' . __( 'Page', 'osum' ) . ' </span>%',
                        'separator'   => '<span class="screen-reader-text">, </span>',
                    ) );
                ?>
            </div>
            <div class="social-sharing">
                <ul>
                    <li><a href="#"><i class="icon icon-facebook"></i></a></li>
                    <li><a href="#"><i class="icon icon-google-plus"></i></a></li>
                    <li><a href="#"><i class="icon icon-linkedin2"></i></a></li>
                    <li><a href="#"><i class="icon icon-twitter"></i></a></li>
                </ul>
            </div>
            
           <?php
		}else{
			$size = 'size-570x455';
			echo '<figure>';
				the_post_thumbnail(array(150,150), array( 'alt' => get_the_title() ) );
			echo '</figure>';
			$jobtitle = get_post_meta($post->ID,'jobtitle',true);
			?>
			<div class="text-section">
            	<?php the_title( sprintf( '<h2 class="post-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' );
				?>
				<p>We aim to eliminate the task of dividing your project between different architecture and construction company.</p>
               <div class="social-network">
                    <ul>
                        <li><a href="#"><i class="icon icon-facebook"></i></a></li>
                        <li><a href="#"><i class="icon icon-google-plus"></i></a></li>
                        <li><a href="#"><i class="icon icon-linkedin2"></i></a></li>
                        <li><a href="#"><i class="icon icon-twitter"></i></a></li>
                    </ul>
                </div>
            </div>
        <?php
		}
	?>
</article><!-- #post-## -->