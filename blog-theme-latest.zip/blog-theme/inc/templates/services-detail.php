<?php ?>
<article>
    <figure>
		<?php echo osum_portfolio_thumbnail('size-568x404'); ?>

    </figure>
    <div class="tabs_details">
			<?php the_title( '<h3 class="post-title">', '</h3>' ); ?>
		<?php the_content(); ?>
    </div>
    
</article>