<div class="featured">
    <figure>
            <?php echo osum_portfolio_thumbnail('size-568x404'); ?>
        <figcaption>
            <a href="<?php the_permalink();?>" class="os_btn"><?php _e('View Project','osum'); ?></a>
        </figcaption>
    </figure>
</div>