<?php //global $loopcount; ?>
<article>
    <figure>
        <?php echo osum_portfolio_thumbnail('size-569x184'); ?>
        <figcaption>
            <a href="<?php the_permalink();?>" class="os_btn"><?php _e('View Project','osum'); ?></a>
        </figcaption>
    </figure>
</article>
