<?php ?>
<div id="post-<?php the_ID(); ?>" class="item">
    <div class="post-thumb">
    	<?php the_post_thumbnail('size-370x226');?>
     </div>
    <div class="post-details">
    	<div class="post-options">
         	<ul>
				<li>
					<?php 
						$categories_list = get_the_category_list( _x( ', ', 'Used between list items, there is a space after the comma.', 'osum' ) );
						if ( $categories_list ) {
							echo $categories_list;
						}
					?>
                    <li><i class="fa fa-eye"></i><?php echo getPostViews(get_the_ID()); ?></li>		
        		</li>
      		</ul>

        </div>
		<h3 class="post-title"><a href="<?php the_permalink(); ?>"><?php echo substr(get_the_title(),0,50 ); ?></a></h3>
 		<?php echo osum_read_more(); ?>
	</div>    
</div>