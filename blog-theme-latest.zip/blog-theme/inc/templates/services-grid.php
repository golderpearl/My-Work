<?php ?>
<div class="columns">
    <div class="thumb_img">
        <?php echo osum_portfolio_thumbnail('size-370x237'); ?>
    </div>
    <div class="details">
        <div class="inner_column">
			<?php the_title( '<h2 class="post-title">', '</h2>' ); ?>
			<?php  echo apply_filters('the_content', substr(get_the_content(), 0, 90) ); ?>
            <a href="<?php echo esc_url( get_permalink() ); ?>"><?php _e('Read More','osum'); ?></a>
        </div>
    </div>
</div>