<?php
/**
 * The template for displaying all single posts and attachments
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */
	osum_view_count($post->ID);
	get_header(); 
	$post_metadata = get_post_meta($post->ID,'osum_meta_key',true);
	$osum_post_options = isset($post_metadata['osum_post_options'])? $post_metadata['osum_post_options'] : '';
	$osum_post_gallery = isset($post_metadata['osum_post_gallery'])? $post_metadata['osum_post_gallery'] : '';
	$oms_sidebar = isset($post_metadata['osum_sidebar'])? $post_metadata['osum_sidebar'] : '';
	$oms_layout  = isset($post_metadata['osum_sidebar_layout'])? $post_metadata['osum_sidebar_layout'] : 'full_width';
	$oms_layout_cls	= ($oms_layout == 'full_width') ? 'fw-col-lg-12 fw-col-md-12 fw-col-sm-12 fw-col-xs-12' : 'fw-col-lg-8 fw-col-md-8 fw-col-sm-8 fw-col-xs-12';
	//$oms_layout_cls	= ($oms_layout != 'full_width') ? 'fw-col-md-12' : 'fw-col-md-12';
	if($oms_layout == 'full_width'){
		$osum_postcount = '3';
	}else{
		$osum_postcount = '2';
	}
	
	
	?>
	<div class="post-details">
		<div class="fw-row">
            <div class="fw-col-lg-8 fw-col-md-8 fw-col-sm-8 fw-col-xs-12">
				<div class="content-section">
					<div class="entry-content">
						<!-- Blog Section -->
						<?php
						if(have_posts()) {
							// Start the loop.
							while ( have_posts() ) : the_post();
								if($osum_post_options == 'audio'){
									$osum_audio_url = isset($post_metadata['osum_audio_url'])? $post_metadata['osum_audio_url'] : '';
									echo $video	= wp_oembed_get($osum_audio_url,array('width'=>850));
								}elseif($osum_post_options == 'video'){
									$osum_video_url = isset($post_metadata['osum_video_url'])? $post_metadata['osum_video_url'] : '';
									echo $video	= wp_oembed_get($osum_video_url,array('width'=>850));
								}elseif($osum_post_options == 'slider'){
									echo $slider =  fw()->extensions->get('slider')->render_slider($osum_post_gallery, array('width'  =>'750','height' => '480'));
								}else{
									osum_post_thumbnail('size-850x542');
								}
								?>
								<div class="post-options">
									<ul>
										<li>
											<?php 
												$categories_list = get_the_category_list( _x( ', ', 'Used between list items, there is a space after the comma.', 'osum' ) );
												if ( $categories_list ) {
													echo $categories_list;
												}
											?>
										</li>
										<?php
											if ( is_single() && ! post_password_required() && ( comments_open() || get_comments_number() ) ) {
												echo '<li>';
												comments_popup_link( __( 'Leave a comment', 'osum' ), __( '1 Comment', 'osum' ), __( '% Comments', 'osum' ) );
												echo '</li>';
											}
										?>
										<li></li>
									</ul>
								</div>
								<?php the_title( '<div class="page-title"><h2>', '</h2></div>' );?>
								<div class="post-options">
									<ul>
										<li> <?php echo get_the_date('F j, Y'); ?></li>
									</ul>
								</div>
								<div class="post-content">
									<?php
										/* translators: %s: Name of current post */
										the_content( sprintf(
											__( 'Continue reading %s', 'osum' ),
											the_title( '<span class="screen-reader-text">', '</span>', false )
										) );
										wp_link_pages( array(
											'before'      => '<div class="page-links"><span class="page-links-title">' . __( 'Pages:', 'osum' ) . '</span>',
											'after'       => '</div>',
											'link_before' => '<span>',
											'link_after'  => '</span>',
											'pagelink'    => '<span class="screen-reader-text">' . __( 'Page', 'osum' ) . ' </span>%',
											'separator'   => '<span class="screen-reader-text">, </span>',
										) );
									?>
								</div>
								<div class="tags-social-area">
									<?php 
										osum_taglist(); 
										osum_social_share();
									?>
								</div>
								<?php
									$post_categories	= wp_get_post_categories($post->ID);
									$post_tags 			= wp_get_post_tags($post->ID);
									$args = array(
										'post_status' => 'publish',
										'posts_per_page' => $osum_postcount,
										'orderby' => 'DESC',
										'tax_query' => array(
												'relation' => 'OR',
											array(
												'taxonomy' => 'category',
												'field' => 'id',
												'terms' => $post_categories
											),
											array(
												'taxonomy' => 'tag',
												'field' => 'id',
												'terms' => $post_tags
											)
										),
										'post__not_in' => array ($post->ID),
									);
									$osum_query = new WP_Query( $args );
									if($osum_query->have_posts() ) {
										?>
										<div class="recent-posts">
											<div class="section-title">
												<h2><?php _e('Related Posts','osum'); ?></h2>
											</div> 
											<script type="text/javascript">
												/* jQuery(document).ready(function($) {
													osum_related_posts(<?php echo $osum_postcount; ?>);
												}); */
											</script>
											<div id="related-posts" class="category-section">
												<?php
													
													while ( $osum_query->have_posts() ) : $osum_query->the_post();
														get_template_part( 'inc/templates/related', 'post' );
													endwhile;
													wp_reset_postdata();
												?>
											</div>
										</div>
									<?php } ?>
								<?php
							// End the loop.
							endwhile;
							wp_reset_postdata();
						}
						echo osum_author_desc();
						// If comments are open or we have at least one comment, load up the comment template.
						if ( comments_open() || get_comments_number() ) :
							comments_template();
						endif;
						?>                
	                </div>
	            </div>
            </div>
			<div class="fw-col-lg-4 fw-col-md-4 fw-col-sm-4 fw-col-xs-12">
				<div class="sidebar-widgets">
					<?php dynamic_sidebar( 'sidebar-1' ); ?>
				</div>
			</div>
        </div>
        <div class="divider"></div>
   </div><!-- .content-area -->  	
<?php get_footer(); ?>
