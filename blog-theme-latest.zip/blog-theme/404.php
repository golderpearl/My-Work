<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */

get_header(); ?>
	<div class="error-page">
		<div class="fw-container">
    		<!-- Team Starts -->
    		<div class="error-404 error-page not-found">
				<img src="<?php echo get_template_directory_uri();?>/assets/images/404.png" alt="">
	            <div class="search-section">
            		<?php get_search_form(); ?>
            	</div>
    		</div>
		</div>
   </div>
<?php get_footer(); ?>