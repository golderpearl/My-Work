<?php ?>
<form action="<?php home_url( '/' ); ?>" id="searchform" method="get" class="osum-sf">
			<input type="text" id="s" name="s" value="<?php if(!empty($_GET['s'])) echo get_search_query(); ?>" placeholder='<?php _e('Search','osum'); ?>' />
        <i class="lnr lnr-magnifier"></i>
        	<input type="submit" value="Search" id="searchsubmit" class="search" />

</form>