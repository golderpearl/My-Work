<?php
/**
 * The template for displaying the header
 *
 */
 global $osum_options;
 $bg_color = isset($osum_options['bg_color']) ? $osum_options['bg_color'] : '';
 $osum_bg = isset($osum_options['pattern']) ? $osum_options['pattern'] : '#fff';
 $showpattern = isset($osum_options['showpattern']) ? $osum_options['showpattern'] : '';
	if($showpattern != 'true' ){
		$osum_bg = isset($osum_options['body_bgimage']) ? $osum_options['body_bgimage'] : '';
	}else{
		$osum_bg = get_template_directory_uri().'/inc/panel/images/patterns/'.$osum_bg.'.jpg';
	}
 $osum_bgrepeat = isset($osum_options['bg_repeat']) ? $osum_options['bg_repeat'] : 'repeat';
 $osum_bgposition = isset($osum_options['bg_position']) ? $osum_options['bg_position'] : 'center top';
 $osum_bgsize = isset($osum_options['bg_size']) ? $osum_options['bg_size'] : 'cover';

 $osum_favicon = isset($osum_options['favicon']) ? $osum_options['favicon'] : '';
 $osum_header_style = isset($osum_options['header_style']) ? $osum_options['header_style'] : 'header1';
 $osum_header_cls = ($osum_header_style == 'header1') ? 'header-v3' : 'header-v2';
 $osum_header_cls = ($osum_header_style == 'header2') ? 'header-v2' : $osum_header_cls;

 $osum_layout = isset($osum_options['site_layout']) ? $osum_options['site_layout'] : ''; 
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js">
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
	<!--[if lt IE 9]>
	<script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/html5.js"></script>
	<![endif]-->
            <link rel="shortcut icon" href="<?php echo esc_url($osum_favicon); ?>">

	<?php wp_head(); ?>
	<style>
		body {
			/* background-color:<?php echo esc_attr($bg_color); ?>;
			background-image: url("<?php echo esc_url($osum_bg); ?>");
			background-repeat: <?php echo esc_attr($osum_bgrepeat); ?>;
			background-position: <?php echo esc_attr($osum_bgposition); ?>;
			background-size: <?php echo esc_attr($osum_bgsize); ?>; */
		}
	</style>
	<?php osum_theme_color(); ?>

</head>
<body <?php body_class(); ?>>



<?php
/**
* Supply a user id and an access token
* Jelled explains how to obtain a user id and access token in the link provided
* @link http://jelled.com/instagram/access-token
*/
$userid = "333522836";
$accessToken = "6950361203.1677ed0.1bf7bb4e781c43a98dd1a6fe0fb2ccdf";
// Get our data
function fetchData($url){
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_TIMEOUT, 20);
	$result = curl_exec($ch);
	curl_close($ch);
	return $result;
}
// Pull and parse data.
$result = fetchData("https://api.instagram.com/v1/users/{$userid}/media/recent/?access_token={$accessToken}");
$result = json_decode($result);
?>

<?php $limit = 8; // Amount of images to show ?>
<?php $i = 0; ?>

<?php foreach ($result->data as $post): ?>
	<?php if ($i < $limit ): ?>
		<a href="<?= $post->images->standard_resolution->url ?>"><img src="<?= $post->images->standard_resolution->url ?>" width="500" height="500"></a>
		<?php $i ++; ?>
	<?php endif; ?>
<?php endforeach; ?>




	<!-- <div class="loading-page">
		<img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/loader.gif" alt="">
	</div> -->
	<div class="wrapper <?php echo sanitize_html_class($osum_layout); ?>">
    	<div class="fw-container">
    		<div class="fw-row">
				<header id="header" class="hide-mobile <?php echo sanitize_html_class($osum_header_cls); ?>">
					<div class="fw-row">
						<?php 
						/* $search_box = (isset($osum_options['search_box']) and $osum_options['search_box'] <> '') ? $osum_options['search_box'] : '';
						if( $search_box == 'true'){
						?>
							<div class="search-section">
								<form action="<?php home_url( '/' ); ?>" id="searchform" method="get">
									<input type="text" name="s" id="s" value="Search" onfocus="if (this.value == 'Search') (this.value='')" onblur="if (this.value == '') (this.value='Search')">
									<i class="lnr lnr-magnifier"></i>
									<input type="submit" value="s">
								</form>
							</div>
						<?php } */ ?>
						<div class="fw-col-md-4 fw-col-sm-4 fw-col xs-12">
							<div class="email-contact">
								<img src="<?php echo get_template_directory_uri(); ?>/assets/images/email.png" alt="">
								<div class="text">
									<p>Collaboration / Brand Partnership: <a href="mailto:aaitalkhosla@gmail.com">aaitalkhosla@gmail.com</a></p>
								</div>
							</div>
						</div>
						<?php 
							$osum_logo 			= (isset($osum_options['logo']) and $osum_options['logo'] <> '') ? $osum_options['logo'] : '';
							$osum_logo_width 	= (isset($osum_options['logo_width']) and $osum_options['logo_width'] <> '') ? $osum_options['logo_width'] : '';
							$osum_logo_height 	= (isset($osum_options['logo_height']) and $osum_options['logo_height'] <> '') ? $osum_options['logo_height'] : '';
							if($osum_logo <> ''){?>
								<div class="fw-col-md-4 fw-col-sm-4 fw-col xs-12">
									<div class="logo">
										<a href="<?php echo esc_url( home_url( '/' ) ); ?>">
											<img src="<?php echo esc_url($osum_logo); ?>" alt="<?php bloginfo( 'name' ); ?>" width="<?php echo absint($osum_logo_width); ?>" > <!-- height="<?php //echo absint($osum_logo_height); ?>" -->
										</a>
									</div>
								</div>
						<?php } ?>
						<?php 
						$social_network = (isset($osum_options['social_network']) and $osum_options['social_network'] <> '') ? $osum_options['social_network'] : '';
						if($social_network == 'true'){
							$facebook_url = (isset($osum_options['facebook_url']) and $osum_options['facebook_url'] <> '') ? $osum_options['facebook_url'] : '';
							$instagram_url = (isset($osum_options['instagram_url']) and $osum_options['instagram_url'] <> '') ? $osum_options['instagram_url'] : '';
							?>
							<div class="fw-col-md-4 fw-col-sm-4 fw-col xs-12">
								<div class="social-network">
									<ul>
										<?php
											if($facebook_url <> ''){
												echo '<li><a href="'.$facebook_url.'" target="_blank"><img src="'.get_template_directory_uri().'/assets/images/fb.png" alt=""></a></li>';
											}
											if($instagram_url <> ''){
												echo '<li><a href="'.$instagram_url.'" target="_blank"><img src="'.get_template_directory_uri().'/assets/images/insta.png" alt=""></a></li>';
											}						
										?>
									</ul>
								</div>
							</div>
						<?php } ?>
					</div>
    				<nav class="mobile-menu cat_menu">
		    			<a href="#" class="menu-toggle"><span></span></a>
	    				<div class="menu-items">
	    					<?php
							if ( has_nav_menu( 'main-menu' ) ) {
								$osum_args = array(
									'theme_location'  => 'main-menu',
									'menu'            => '',
									'container'       => 'div',
									'container_class' => 'menu-items',
									'container_id'    => '',
									'menu_class'      => 'menu-items',
									'menu_id'         => '',
									'echo'            => true,
									'fallback_cb'     => 'wp_page_menu',
									'before'          => '',
									'after'           => '',
									'link_before'     => '',
									'link_after'      => '',
									'items_wrap'      => '<a href="#" id="close-menu"><i class="lnr lnr-cross"></i></a><ul id="%1$s" class="%2$s">%3$s</ul>',
									'depth'           => 0,
									'walker'          => ''
								);
							}else{
								$osum_args = array(
									'menu_class'  => 'menu-items',
			    					'container'   => 'div',
									'echo'            => true,
									'fallback_cb'     => 'wp_page_menu',
									'before'          => '',
									'after'           => '',
									'link_before'     => '',
									'link_after'      => '',
									'items_wrap'      => '<a href="#" id="close-menu"><i class="lnr lnr-cross"></i></a><ul id="%1$s" class="%2$s">%3$s</ul>',
									'depth'           => 0,
									'walker'          => ''
								);
							}
							wp_nav_menu( $osum_args );
						?>
						<?php 
							$social_network = (isset($osum_options['social_network']) and $osum_options['social_network'] <> '') ? $osum_options['social_network'] : '';
							if($social_network == 'true'){
								$facebook_url = (isset($osum_options['facebook_url']) and $osum_options['facebook_url'] <> '') ? $osum_options['facebook_url'] : '';
								$instagram_url = (isset($osum_options['instagram_url']) and $osum_options['instagram_url'] <> '') ? $osum_options['instagram_url'] : '';
								?>
			    				<div class="social-network">
			    					<ul>
			    						<?php
											if($facebook_url <> ''){
												echo '<li><a href="'.$facebook_url.'" target="_blank"><img src="'.get_template_directory_uri().'/assets/images/fb.png" alt=""></a></li>';
											}
											if($instagram_url <> ''){
												echo '<li><a href="'.$instagram_url.'" target="_blank"><img src="'.get_template_directory_uri().'/assets/images/insta.png" alt=""></a></li>';
											}						
										?>
			    					</ul>
			    				</div>
		    				<?php } ?>
	    				</div>
	    			</nav>
    			</header>
				<!-- Mobile Header -->
				<header id="header" class="mobile-header <?php echo sanitize_html_class($osum_header_cls); ?>">
					<div class="top-header">
						<div class="fw-col-xs-4">
							<nav class="mobile-menu cat_menu">
								<a href="#" class="menu-toggle"><span></span></a>
								<div class="menu-items">
									<?php
									if ( has_nav_menu( 'main-menu' ) ) {
										$osum_args = array(
											'theme_location'  => 'main-menu',
											'menu'            => '',
											'container'       => 'div',
											'container_class' => 'menu-items',
											'container_id'    => '',
											'menu_class'      => 'menu-items',
											'menu_id'         => '',
											'echo'            => true,
											'fallback_cb'     => 'wp_page_menu',
											'before'          => '',
											'after'           => '',
											'link_before'     => '',
											'link_after'      => '',
											'items_wrap'      => '<a href="#" id="close-menu"><i class="lnr lnr-cross"></i></a><ul id="%1$s" class="%2$s">%3$s</ul>',
											'depth'           => 0,
											'walker'          => ''
										);
									}else{
										$osum_args = array(
											'menu_class'  => 'menu-items',
											'container'   => 'div',
											'echo'            => true,
											'fallback_cb'     => 'wp_page_menu',
											'before'          => '',
											'after'           => '',
											'link_before'     => '',
											'link_after'      => '',
											'items_wrap'      => '<a href="#" id="close-menu"><i class="lnr lnr-cross"></i></a><ul id="%1$s" class="%2$s">%3$s</ul>',
											'depth'           => 0,
											'walker'          => ''
										);
									}
									wp_nav_menu( $osum_args );
									?>
									<?php 
									$social_network = (isset($osum_options['social_network']) and $osum_options['social_network'] <> '') ? $osum_options['social_network'] : '';
									if($social_network == 'true'){
										$facebook_url = (isset($osum_options['facebook_url']) and $osum_options['facebook_url'] <> '') ? $osum_options['facebook_url'] : '';
										$instagram_url = (isset($osum_options['instagram_url']) and $osum_options['instagram_url'] <> '') ? $osum_options['instagram_url'] : '';
										?>
										<div class="social-network">
											<ul>
												<?php
													if($facebook_url <> ''){
														echo '<li><a href="'.$facebook_url.'" target="_blank"><img src="'.get_template_directory_uri().'/assets/images/fb.png" alt=""></a></li>';
													}
													if($instagram_url <> ''){
														echo '<li><a href="'.$instagram_url.'" target="_blank"><img src="'.get_template_directory_uri().'/assets/images/insta.png" alt=""></a></li>';
													}						
												?>
											</ul>
										</div>
									<?php } ?>
								</div>
							</nav>
						</div>
						<div class="fw-col-xs-8">
							<?php 
								$osum_mobile_logo = (isset($osum_options['mobile_logo']) and $osum_options['mobile_logo'] <> '') ? $osum_options['mobile_logo'] : '';
								if($osum_mobile_logo <> ''){?>
									<div class="logo">
										<a href="<?php echo esc_url( home_url( '/' ) ); ?>">
											<img src="<?php echo esc_url($osum_mobile_logo); ?>" alt="<?php bloginfo( 'name' ); ?>" width="250" >
										</a>
									</div>
							<?php } ?>
						</div>
					</div>
					<div class="bottom-header">
						<div class="fw-col-xs-8">
							<div class="email-contact">
								<img src="<?php echo get_template_directory_uri(); ?>/assets/images/email.png" alt="">
								<div class="text">
									<p>Collaboration / Brand Partnership: <a href="mailto:aaitalkhosla@gmail.com">aaitalkhosla@gmail.com</a></p>
								</div>
							</div>
						</div>
						<?php
							$social_network = (isset($osum_options['social_network']) and $osum_options['social_network'] <> '') ? $osum_options['social_network'] : '';
							if($social_network == 'true'){
								$facebook_url = (isset($osum_options['facebook_url']) and $osum_options['facebook_url'] <> '') ? $osum_options['facebook_url'] : '';
								$instagram_url = (isset($osum_options['instagram_url']) and $osum_options['instagram_url'] <> '') ? $osum_options['instagram_url'] : '';
								?>
								<div class="fw-col-xs-4">
									<div class="social-network">
										<ul>
											<?php
												if($facebook_url <> ''){
													echo '<li><a href="'.$facebook_url.'" target="_blank"><img src="'.get_template_directory_uri().'/assets/images/fb.png" alt=""></a></li>';
												}
												if($instagram_url <> ''){
													echo '<li><a href="'.$instagram_url.'" target="_blank"><img src="'.get_template_directory_uri().'/assets/images/insta.png" alt=""></a></li>';
												}						
											?>
										</ul>
									</div>
								</div>
								<?php
							}
						?>
					</div>
				</header>
				
    			<nav class="cat_menu">
    				<a href="#" class="menu-toggle"><span></span></a>
    				<div class="menu-items">
    					<?php
						if ( has_nav_menu( 'main-menu' ) ) {
							$osum_args = array(
								'theme_location'  => 'main-menu',
								'menu'            => '',
								'container'       => 'div',
								'container_class' => 'menu-items',
								'container_id'    => '',
								'menu_class'      => 'menu-items',
								'menu_id'         => '',
								'echo'            => true,
								'fallback_cb'     => 'wp_page_menu',
								'before'          => '',
								'after'           => '',
								'link_before'     => '',
								'link_after'      => '',
								'items_wrap'      => '<a href="#" id="close-menu"><i class="lnr lnr-cross"></i></a><ul id="%1$s" class="%2$s">%3$s</ul>',
								'depth'           => 0,
								'walker'          => ''
							);
						}else{
							$osum_args = array(
								'menu_class'  => 'menu-items',
		    					'container'   => 'div',
								'echo'            => true,
								'fallback_cb'     => 'wp_page_menu',
								'before'          => '',
								'after'           => '',
								'link_before'     => '',
								'link_after'      => '',
								'items_wrap'      => '<a href="#" id="close-menu"><i class="lnr lnr-cross"></i></a><ul id="%1$s" class="%2$s">%3$s</ul>',
								'depth'           => 0,
								'walker'          => ''
							);
						}
	        				wp_nav_menu( $osum_args );
					?>
    				</div>
				</nav>

				<?php
				/* $userid = "333522836";
				$accessToken = "6950361203.1677ed0.1bf7bb4e781c43a98dd1a6fe0fb2ccdf";

				// Get our data
				function fetchData($url){
					$ch = curl_init();
					curl_setopt($ch, CURLOPT_URL, $url);
					curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
					curl_setopt($ch, CURLOPT_TIMEOUT, 20);
					$result = curl_exec($ch);
					curl_close($ch);
					return $result;
				}

				// Pull and parse data.
				$result = fetchData("https://api.instagram.com/v1/users/{$userid}/media/recent/?access_token={$accessToken}");
				$result = json_decode($result); */
				?>

				<?php /* $limit = 8; // Amount of images to show ?>
				<?php $i = 0; */ ?>

				<?php /* foreach ($result->data as $post) { ?>
					<?php if ($i < $limit ) { */
						// $thumbnail_url = $post->images->thumbnail->url;
						// $thumbnail_url = str_replace('640x800/', '320x320/', $pic_src);
						// $thumbnail_url = preg_replace('/vp\/[^\/]*/', 'hphotos-xfp1', $thumbnail_url); ?>
						<!-- <a href="<?= $post->images->standard_resolution->url ?>"> -->
							<!-- <img src="<?= $post->images->standard_resolution->url ?>" width="320" height="320"> -->
						<!-- </a> -->
						<?php
						/* $i ++;
					}
				} */

				$osum_instagram = (isset($osum_options['instagram']) and $osum_options['instagram'] <> '') ? $osum_options['instagram'] : '';
				$osum_instagramuser = (isset($osum_options['instagram_user']) and $osum_options['instagram_user'] <> '') ? $osum_options['instagram_user'] : '';
				$instagram_posts = (isset($osum_options['instagram_posts']) and $osum_options['instagram_posts'] <> '') ? $osum_options['instagram_posts'] : '';

				// use this instagram access token generator http://instagram.pixelunion.net/
				//$access_token="6950361203.1677ed0.1bf7bb4e781c43a98dd1a6fe0fb2ccdf";
				//$access_token="333522836.1677ed0.0d9c918bb65d4b8e8fe2c1a97b17b25a";
				//$access_token="1925294251.1677ed0.4ec5783e1ea84a408cfe358e5d9139cb";
				$access_token = $osum_instagramuser;
				$photo_count = $instagram_posts;

				$json_link="https://api.instagram.com/v1/users/self/media/recent/?";
				$json_link.="access_token={$access_token}&count={$photo_count}";

				$json = file_get_contents($json_link);
				$obj = json_decode($json, true, 512, JSON_BIGINT_AS_STRING);
				//var_dump( $obj['data'] );

				if(!is_front_page() || is_category() || is_archive() || is_single() ) :
					if( !empty( $obj['data'] ) ) { ?>
						<div class="instagram-posts">
							<div class="fw-container">
								<div class="small_grid_view">
									<ul>
										<?php
											foreach ($obj['data'] as $post) {
												$pic_text=$post['caption']['text'];
												$pic_link=$post['link'];
												$pic_alt=$post['tags'][0];
												$pic_like_count=$post['likes']['count'];
												$pic_comment_count=$post['comments']['count'];
												$pic_src=str_replace("http://", "https://", $post['images']['standard_resolution']['url']);

												$thumbnail_url = $post->images->thumbnail->url;
												$thumbnail_url = str_replace('150x150/', '320x320/', $thumbnail_url);
												$thumbnail_url = preg_replace('/vp\/[^\/]*/', 'hphotos-xfp1', $thumbnail_url);

												//echo $post['images']['standard_resolution']['url'];

												$pic_created_time=date("F j, Y", $post['caption']['created_time']);
												$pic_created_time=date("F j, Y", strtotime($pic_created_time . " +1 days"));
												?>
												<li>
													<a href="<?php echo $pic_link; ?>" target="_blank">
														<img class='img-responsive photo-thumb' src="<?php echo $pic_src; ?>" alt="<?php echo $pic_alt; ?>">
													</a>
												</li>
												<?php
											}
										?>
									</ul>
									<div class="insta-title absolute">
										<h3><a href="https://www.instagram.com/aaital/" target="_blank">FOLLOW ME ON INSTAGRAM <img width="30" src="<?php echo get_template_directory_uri(); ?>/assets/images/insta.png" alt=""> @aaital</a></h3>
									</div>
								</div>
							</div>
						</div>
					<?php }
				endif; ?>
    			<?php 
	    			if(is_front_page() || is_category() || is_archive() || is_single()) {

					} else {
						if(has_post_thumbnail()): ?>
							<div class="inner-banner">
								<?php echo the_post_thumbnail('size-1170x484'); ?>
							</div>
	    					<?php
						endif;
						
					}
	    		?>