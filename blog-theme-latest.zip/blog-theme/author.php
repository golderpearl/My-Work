<?php
/**
 * The template for displaying archive pages
 *
 * Used to display archive-type pages if nothing more specific matches a query.
 * For example, puts together date-based pages if no date.php file exists.
 *
 * If you'd like to further customize these archive views, you may create a
 * new template file for each one. For example, tag.php (Tag archives),
 * category.php (Category archives), author.php (Author archives), etc.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */

get_header(); 
	$osum_layout = isset($osum_options['sidebar_layout']) ? $osum_options['sidebar_layout'] : 'full_width';
	$osum_sidebar  = isset($osum_options['sidebar'])? $osum_options['sidebar'] : '';
	$oms_layout_cls	= ($osum_layout == 'full_width') ? 'col-lg-12 col-md-12 col-sm-12 col-xs-12' : 'col-lg-8 col-md-8 col-sm-8 col-xs-12';
	$user_post_count = count_user_posts( $userid);
?>
	<div class="search-listing fw-container category-area">
     	<div class="row">
			<?php /*?><?php if ( is_active_sidebar( $osum_sidebar ) and $osum_layout == 'left_sidebar' ) { ?>
                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                    <div class="sidebar">
                    <?php dynamic_sidebar( $osum_sidebar ); ?>
                </div>
                </div>
            <?php } ?><?php */?>

		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="page-title"><h2>Posts (<?php echo $user_post_count; ?>)</h2></div>
				<div class="blog-section categories-section">
                	<div class="cat_posts">
					<?php if ( have_posts() ) :
                            // Start the Loop.
                            while ( have_posts() ) : the_post();
                        
                            /*
                            * Include the Post-Format-specific template for the content.
                            * If you want to override this in a child theme, then include a file
                            * called content-___.php (where ___ is the Post Format name) and that will be used instead.
                            */
                                get_template_part( 'content', get_post_format() );
                            // End the loop.
                            endwhile;
                           // Previous/next page navigation.
                            /*the_posts_pagination( array(
								'type'	=>	'list',
								'prev_text'          => __( 'Previous page', 'osum' ),
                                'next_text'          => __( 'Next page', 'osum' ),
                                'before_page_number' => '',
                            ) );*/
                        
                            // If no content, include the "No posts found" template.
                        else :
		                    get_template_part( 'content', 'none' );
							
						endif;
                    ?>
                    	</div>      	
                </div>
            </div>
    		
        
           <?php /*?> <?php if ( is_active_sidebar( $osum_sidebar )  and $osum_layout == 'right_sidebar') { ?>
                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                    <div class="sidebar">
                    <?php dynamic_sidebar( $osum_sidebar ); ?>
                </div>
                </div>
            <?php } ?><?php */?>
            </div>
    </div>	
<?php get_footer(); ?>
