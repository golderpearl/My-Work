<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the "site-content" div and all content after.
 *
 */
global $osum_options;
		$footer_ad_switch = (isset($osum_options['footer_ad_switch']) and $osum_options['footer_ad_switch'] <> '') ? $osum_options['footer_ad_switch'] : '';
		$footer_ad_box = (isset($osum_options['footer_ad_box']) and $osum_options['footer_ad_box'] <> '') ? $osum_options['footer_ad_box'] : '';
		?>
	</div>
</div>
<?php /* if ( $footer_ad_switch == 'true' ) :?>
	<div class="ad-section">
		<div class="container">
			<?php 
			if (!empty($footer_ad_box)) {
				echo '<img src="'. $footer_ad_box .'" alt="Ad Image">';
			}
			?>
		</div>
	</div>
<?php endif; */ ?>
<?php $osum_bgcolor = (isset($osum_options['ft_bgcolor']) and $osum_options['ft_bgcolor'] <> '') ? $osum_options['ft_bgcolor'] : '';?>
		<footer id="footer" class="footer-fixed" style="background-color:<?php echo $osum_bgcolor; ?>;">
			<?php $osum_instagram = (isset($osum_options['instagram']) and $osum_options['instagram'] <> '') ? $osum_options['instagram'] : '';?>
			<!-- <div class="instagram-posts">
			 	<?php   
				 	/* $osum_instagramuser = (isset($osum_options['instagram_user']) and $osum_options['instagram_user'] <> '') ? $osum_options['instagram_user'] : '';					
					$refresh_hour = 1;
					$images_number = 6;
					$images_data = instagram_data( 'user', $refresh_hour, $images_number, false );
					if ( is_array( $images_data ) && !empty( $images_data ) ) {
						shuffle( $images_data );
						$output = '<ul>';
						foreach ( $images_data as $image_data ) {
							$template_args['link_to'] = 'http://instagram.com/aaital'; //. $osum_instagramuser;
							$template_args['image'] 		= $image_data['url_medium'];
							$template_args['username']      = 'aaital';
							//$template_args['comment_count'] = $image_data['comment_count'];
							//$template_args['like_count'] 	= $image_data['like_count'];
							$output .= get_insta_template( 'list', $template_args );
						}
						$output .= "</ul>";
					}
				 
					echo $output; */
				?>
			</div> -->
	        <div class="fw-container">
	            <?php $osum_newsletter = (isset($osum_options['newsletter']) and $osum_options['newsletter'] <> '') ? $osum_options['newsletter'] : '';?>
				<?php if($osum_newsletter == 'true'){?>
	 				<?php  if ( function_exists( 'osum_mailchimp' ) ) { echo osum_mailchimp(); }?>
	            <?php } ?>
	        	<?php
					if ( has_nav_menu( 'footer-menu' ) ) {
						$osum_args = array(
							'theme_location'  => 'footer-menu',
							'menu'            => '',
							'container'       => 'nav',
							'container_class' => 'footer-menu',
							'container_id'    => '',
							'menu_class'      => '',
							'menu_id'         => '',
							'echo'            => true,
							'fallback_cb'     => 'wp_page_menu',
							'before'          => '',
							'after'           => '',
							'link_before'     => '',
							'link_after'      => '',
							'items_wrap'      => '<ul id="%1$s" class="%2$s">%3$s</ul>',
							'depth'           => 0,
							'walker'          => ''
						);
					}else{
						$osum_args = array(
							'menu_class'  	  => 'footer-menu',
							'menu'            => '',
	    					'container'   	  => 'nav',
							'container_class' => 'footer-menu',
							'container_id'    => '',
							'menu_class'      => '',
							'menu_id'         => '',
							'echo'            => true,
							'fallback_cb'     => 'wp_page_menu',
							'before'          => '',
							'after'           => '',
							'link_before'     => '',
							'link_after'      => '',
							'items_wrap'      => '<div class="footer-menu"><ul id="%1$s" class="%2$s">%3$s</ul></div>',
							'depth'           => 0,
							'walker'          => ''
						);
			
					}
	        		wp_nav_menu( $osum_args );
				?>				
				<div class="copyrights">
					<?php $copyright = (isset($osum_options['copyright']) and $osum_options['copyright'] <>'') ? $osum_options['copyright'] : ''; ?>
					<p><?php echo  $copyright; ?></p>
	                <div class="footer-logo">
						<?php 
							$osum_ftr_logo 			= (isset($osum_options['ftr_logo']) and $osum_options['ftr_logo'] <> '') ? $osum_options['ftr_logo'] : '';
							$osum_ftr_logow 	= (isset($osum_options['ftr_logow']) and $osum_options['ftr_logow'] <> '') ? $osum_options['ftr_logow'] : '';
							$osum_ftr_logoh  	= (isset($osum_options['ftr_logoh']) and $osum_options['ftr_logoh'] <> '') ? $osum_options['ftr_logoh'] : '';
							if($osum_ftr_logo <> ''){?>
								<a href="<?php echo esc_url( home_url( '/' ) ); ?>">
									<img src="<?php echo esc_url($osum_ftr_logo); ?>" alt="<?php bloginfo( 'name' ); ?>" width="<?php echo absint($osum_ftr_logow); ?>"> <!-- height="<?php //echo absint($osum_ftr_logoh); ?>" -->
								</a>
						<?php } ?>
					</div>
	            	<div class="social-network">
	                    <ul>
	                    <?php 
	                        $facebook_url = (isset($osum_options['facebook_url']) and $osum_options['facebook_url'] <> '') ? $osum_options['facebook_url'] : '';
	                        $twitter_url = (isset($osum_options['twitter_url']) and $osum_options['twitter_url'] <> '') ? $osum_options['twitter_url'] : '';
	                        $linkedin_url = (isset($osum_options['linkedin_url']) and $osum_options['linkedin_url'] <> '') ? $osum_options['linkedin_url'] : '';
	                        $googleplus_url = (isset($osum_options['googleplus_url']) and $osum_options['googleplus_url'] <> '') ? $osum_options['googleplus_url'] : '';
	                        $pintrest_url = (isset($osum_options['pintrest_url']) and $osum_options['pintrest_url'] <> '') ? $osum_options['pintrest_url'] : '';
	                        $instagram_url = (isset($osum_options['instagram_url']) and $osum_options['instagram_url'] <> '') ? $osum_options['instagram_url'] : '';

	                        if($facebook_url <> ''){
	                            echo '<li><a href="'.$facebook_url.'" target="_blank"><i class="icon icon-facebook"></i></a></li>';
	                        }
	                        if($googleplus_url <> ''){
	                            echo '<li><a href="'.$googleplus_url.'" target="_blank"><i class="icon icon-google-plus"></i></a></li>';
	                        }
	                        if($linkedin_url <> ''){
	                            echo '<li><a href="'.$linkedin_url.'" target="_blank"><i class="icon icon-linkedin2"></i></a></li>';
	                        }
	                        if($twitter_url <> ''){
	                            echo '<li><a href="'.$twitter_url.'" target="_blank"><i class="icon icon-twitter"></i></a></li>';
	                        }
	                        if($pintrest_url <> ''){
	                            echo '<li><a href="'.$pintrest_url.'" target="_blank"><i class="icon icon-pinterest"></i></a></li>';
	                        }                        
	                        if($instagram_url <> ''){
	                            echo '<li><a href="'.$instagram_url.'" target="_blank"><i class="icon icon-instagram"></i></a></li>';
	                        }						
	                    ?>

	                    </ul>
					</div>
				</div>
	     	</div>
		</footer>
	</div>
	<!-- Wrapper End -->
	<?php wp_footer(); ?>
</body>
</html>
