<?php 
	$post_metadata = get_post_meta($post->ID,'osum_meta_key',true);
	$osum_post_options = isset($post_metadata['osum_post_options'])? $post_metadata['osum_post_options'] : '';

?>
<div id="post-<?php the_ID(); ?>" <?php post_class('post'); ?>>
    <div class="post-thumb">
    	<?php the_post_thumbnail('size-280x230');?>
        <?php if($osum_post_options == 'video'):?>
            <a class="play" href="<?php the_permalink(); ?>">
                <img alt="" src="<?php echo get_template_directory_uri();?>/assets/images/play-img.png">
            </a>
        <?php endif; ?>
        <div class="caption">
        <?php $categories_list = get_the_category_list( _x( ', ', 'Used between list items, there is a space after the comma.', 'osum' ) );
		if ( $categories_list ) {
 				echo $categories_list;
		}
		?>

    <div class="bottom-section">
		<div class="date"><?php echo osum_get_date(); ?></div>
		<h3><a href="<?php the_permalink(); ?>"><?php echo substr(get_the_title(),0,50 ); ?></a></h3>
	</div>    
        </div>
    </div>
 </div>