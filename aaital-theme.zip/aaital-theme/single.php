<?php
/**
 * The template for displaying all single posts
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 */

get_header();
instagram();
?>
	<div class="fashion-sec">
		<div class="container">
			<div class="category-articles">
				<?php while ( have_posts() ) : the_post();
					$post_type = get_field('post_type');
					$gallery = get_field('gallery');
					$video_url = get_field('video_url'); ?>
					<article class="article">
						<figure class="fashion-post-thumbnail">
							<?php if ($post_type == 'Gallery') { ?>
								<div class="banner-sec">
									<?php
									$size = 'image-770x514';
									if( $gallery ): ?>
										<div id="owl-demo" class="owl-carousel">
											<?php foreach( $gallery as $image ): ?>
												<div class="item">
													<?php echo wp_get_attachment_image( $image['ID'], $size ); ?>
												</div>
											<?php endforeach; ?>
										</div>
									<?php endif; ?>
								</div>
							<?php } elseif ($post_type == 'Video') {
								$url = $video_url;
								parse_str( parse_url( $url, PHP_URL_QUERY ), $my_array_of_vars ); ?>
								<iframe width="770" height="514" src="https://www.youtube.com/embed/<?php echo $my_array_of_vars['v']; ?>" frameborder="0" allow="accelerometer; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

							<?php } elseif ($post_type == 'Image') { ?>
								<?php echo get_the_post_thumbnail( $post->ID, 'image-770x514' ); ?>

							<?php }	?>
						</figure>
						<div class="description">
							<?php
								$categories = get_the_category();
								if ( ! empty( $categories ) ) {
									echo '
									<a class="cat" href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '">
										' . esc_html( $categories[0]->name ) . '
									</a>';
								}
							?>
							<h2><?php echo get_the_title(); ?></h2>
							<span class="date"><?php echo get_the_date( 'F j, Y' ); ?></span>
							<?php the_content(); ?>
						</div>
					</article>
					<?php
					// If comments are open or we have at least one comment, load up the comment template.
					if ( comments_open() || get_comments_number() ) :
						comments_template();
					endif;
				endwhile; ?>
			</div>
			<sidebar class="sidebar category">
				<?php dynamic_sidebar( 'sidebar' ); ?>
			</sidebar>
		</div>
	</div>
	<?php
get_footer();