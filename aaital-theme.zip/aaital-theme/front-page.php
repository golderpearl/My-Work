<?php
/**
 * The front page template file
 */

get_header();

global $theme_options;

$instagram = $theme_options['instagram'];

// Page Fields
$images = get_field('homepage_slider');
$slider_text = get_field('slider_text');
$button_text = get_field('button_text');
$button_url = get_field('button_url');
$instagram_shortcode = get_field('instagram_shortcode');
?>
<div class="banner-sec">
	<?php
	$size = 'image-1110x600';
	if( $images ): ?>
		<div class="container">
			<div id="owl-demo" class="owl-carousel">
				<?php foreach( $images as $image ): ?>
					<div class="item">
						<?php echo wp_get_attachment_image( $image['ID'], $size ); ?>
						<div class="holder">
							<div class="holder-1">
								<div class="holder-2">
									<h1><?php echo $slider_text; ?></h1>
									<a href="<?php echo $button_url; ?>" class="btn read-story"><?php echo $button_text; ?></a>
								</div>
							</div>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
	<?php endif; ?>
	<div class="instagram-sec">
		<div class="container">
			<div class="head-area">
				<h2>@aaital</h2>
				<strong>Follow Me & Share Your Love</strong>
				<a href="<?php echo $instagram; ?>" class="btn-follow">Follow</a>
			</div>
			<?php echo do_shortcode( $instagram_shortcode ); ?>
		</div>
	</div>
</div>
<?php
$args = array(
	'post_type'   => 'post',
	'post_status' => 'publish',
	'posts_per_page' => 5,
);

$posts = new WP_Query( $args );
if($posts->have_posts()) { ?>
	<div class="articles-sec">
		<div class="container">
			<?php while ($posts->have_posts()) : $posts->the_post();
				$post_type = get_field('post_type');
				$gallery = get_field('gallery');
				$video_url = get_field('video_url');
				global $post; ?>
				<article class="article">
					<figure>
						<?php echo get_the_post_thumbnail( $post->ID, 'image-450x675' ); ?>
						<figcaption>
							<?php
								if ($post_type == 'Gallery') {
									echo '<i class="fa fa-slideshare"></i>';

								} elseif ($post_type == 'Video') {
									echo '<i class="fa fa-file-video-o"></i>';

								} elseif ($post_type == 'Image') {
									echo '<i class="fa fa-file-image-o"></i>';
								}
							?>
						</figcaption>
					</figure>
					<div class="description">
						<?php
							$categories = get_the_category();
							if ( ! empty( $categories ) ) {
								echo '<a class="cat" href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '">
									' . esc_html( $categories[0]->name ) . '
								</a>';
							}
						?>
						<h2>
							<a href="<?php echo get_the_permalink(); ?>">
								<?php echo get_the_title(); ?>
							</a>
						</h2>
						<span class="date"><?php echo get_the_date( 'F j, Y' ); ?></span>
						<p><?php echo substr( get_the_content(), 0, 133 ); ?></p>
						<a href="<?php echo get_the_permalink(); ?>" class="read-story">Read Story</a>
					</div>
				</article>
				<?php
			endwhile;
			wp_reset_postdata(); ?>
		</div>
	</div>
	<?php
}
get_footer();