<?php
/**
 * The header for our theme
 *
 */
global $theme_options;

$logo = $theme_options['primary_logo']['url'];
$favicon = $theme_options['theme_favicon']['url'];
$headerMailTxt = $theme_options['header_mail_text'];
$headerMail = $theme_options['header_mail'];
$facebook = $theme_options['facebook'];
$instagram = $theme_options['instagram'];
?><!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js no-svg">
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<link rel="shortcut icon" href="<?php echo $favicon; ?>" type="image/x-icon">
	<link rel="icon" href="<?php echo $favicon; ?>" type="image/x-icon">

	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<div id="wrapper">
	<header id="header">
        <div class="container">
          	<div class="email-sec">
				<div class="email-icon">
					<img src="<?php echo get_template_directory_uri(); ?>/images/email-icon.png" alt="">
				</div>
				<div class="description">
				<strong><?php echo $headerMailTxt; ?></strong>
					<a href="mailto:<?php echo $headerMail; ?>"><?php echo $headerMail; ?></a>
				</div>
          	</div>
			<div class="social-area">
				<ul>
					<li class="facebook"><a href="<?php echo $facebook; ?>">Facebook</a></li>
					<li class="instagram"><a href="<?php echo $instagram; ?>">Instagram</a></li>
				</ul>
			</div>
          	<div class="logo">
				<a href="<?php echo esc_url( home_url('/') ); ?>">
					<img src="<?php echo $logo; ?>" alt="Logo" />
				</a>
			</div>
        </div>
	</header>
	<nav id="main-nav">
		<?php
			if ( has_nav_menu( 'primary' ) ) {
				$args = array(
					'theme_location'  => 'primary',
					'menu'            => '',
					'container'       => 'div',
					'container_class' => 'container',
					'container_id'    => '',
					'menu_class'      => '',
					'menu_id'         => '',
					'echo'            => true,
					'fallback_cb'     => 'wp_page_menu',
					'before'          => '',
					'after'           => '',
					'link_before'     => '',
					'link_after'      => '',
					'items_wrap'      => '<a href="#" id="close-menu"><i class="lnr lnr-cross"></i></a><ul id="%1$s" class="%2$s">%3$s</ul>',
					'depth'           => 0,
					'walker'          => ''
				);
			}else{
				$args = array(
					'menu_class'  	  => 'container',
					'container'   	  => 'div',
					'container_class' => 'container',
					'echo'            => true,
					'fallback_cb'     => 'wp_page_menu',
					'before'          => '',
					'after'           => '',
					'link_before'     => '',
					'link_after'      => '',
					'items_wrap'      => '<a href="#" id="close-menu"><i class="lnr lnr-cross"></i></a><ul id="%1$s" class="%2$s">%3$s</ul>',
					'depth'           => 0,
					'walker'          => ''
				);
			}
			wp_nav_menu( $args );
		?>
	</nav>
	<main class="main-sec">
		<?php
			/* if ( ( is_single() || ( is_page() && ! twentyseventeen_is_frontpage() ) ) && has_post_thumbnail( get_queried_object_id() ) ) :
				echo get_the_post_thumbnail( get_queried_object_id(), 'twentyseventeen-featured-image' );
			endif; */
		?>