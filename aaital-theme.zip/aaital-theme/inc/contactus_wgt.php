<?php

	class contactus_wgt extends WP_Widget{
	    function contactus_wgt() {
			$widget_ops = array( 'classname' => 'example', 'description' => __('A widget that displays the contact information ', 'osum') );
			$control_ops = array( 'width' => 300, 'height' => 350, 'id_base' => 'example-widget' );
			$this->__construct( 'example-widget', __('Contact Info Widget', 'osum'), $widget_ops, $control_ops );
    	}
		function widget( $args, $instance ){
			extract( $args );
			$title = apply_filters('widget_title', $instance['title'] );
			$address = $instance['address'];
			$phone 	= $instance['phone'];
			$email 	= $instance['email'];
			$time 	= $instance['time'];
			echo $before_widget;
 
			// Display the widget title 
			if ( $title )
				echo $before_title . $title . $after_title;
			echo '<div class="custom_links">';
				echo '<div class="map-area">
						  <img src="'.get_template_directory_uri().'/assets/images/map.jpg" alt="">
						  <div class="caption_info">
							  <p>'.$address.'</p>
						  </div>
					  </div>';
				echo '<div class="contact_info">
						<ul>
							<li><i class="icon icon-phone"></i>'.$phone.'</li>
							<li><i class="icon icon-mail2"></i><a href="mailto:'.$email.'">'.$email.'</a></li>
							<li><i class="icon icon-clock"></i>'.$time.'</li>
						</ul>
					</div>';
			echo '</div>';
				 
			//Display the name 
			if ( $show_info )
				printf( $name );
			 
			echo $after_widget;
		}
		function update( $new_instance, $old_instance ) {
			$instance = $old_instance;
		 
			//Strip tags from title and name to remove HTML
			$instance['title'] 	= strip_tags( $new_instance['title'] );
			$instance['address'] = strip_tags( $new_instance['address'] );
			$instance['phone'] = strip_tags( $new_instance['phone'] );
			$instance['email'] = strip_tags( $new_instance['email'] );
			$instance['time'] = strip_tags( $new_instance['time'] );
		 
			return $instance;
		}
				/* Widget settings */
		function form( $instance ) {
			//Set up some default widget settings.
			$defaults = array( 'title' => '','address' => '', 'phone' => '', 'email' => '', 'time' => '', 'show_info' => true );
			$instance = wp_parse_args( (array) $instance, $defaults );
			?>
            <p>
				<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e('Title:', 'osum'); ?></label>
				<input id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" type="text" style="width:100%;" />
			</p>
 			<p>
				<label for="<?php echo $this->get_field_id( 'address' ); ?>"><?php _e('Address:', 'osum'); ?></label>
                <textarea id="<?php echo $this->get_field_id( 'address' ); ?>" name="<?php echo $this->get_field_name( 'address' ); ?>" style="width:100%;"  ><?php echo $instance['address']; ?></textarea>
			</p>
            <p>
				<label for="<?php echo $this->get_field_id( 'phone' ); ?>"><?php _e('Phone:', 'osum'); ?></label>
				<input id="<?php echo $this->get_field_id( 'phone' ); ?>" name="<?php echo $this->get_field_name( 'phone' ); ?>" value="<?php echo $instance['phone']; ?>" type="text"style="width:100%;" />
			</p> 
 			<p>
				<label for="<?php echo $this->get_field_id( 'email' ); ?>"><?php _e('Email:', 'osum'); ?></label>
				<input id="<?php echo $this->get_field_id( 'email' ); ?>" name="<?php echo $this->get_field_name( 'email' ); ?>" value="<?php echo $instance['email']; ?>" type="email" style="width:100%;" />
			</p>
 			<p>
				<label for="<?php echo $this->get_field_id( 'time' ); ?>"><?php _e('Time:', 'osum'); ?></label>
				<input id="<?php echo $this->get_field_id( 'time' ); ?>" name="<?php echo $this->get_field_name( 'time' ); ?>" value="<?php echo $instance['time']; ?>" type="text" style="width:100%;" />
			</p>
  			
            <?php
		
		
		}
	} 

?>