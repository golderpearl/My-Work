<?php

	class author_wgt extends WP_Widget{
	    function author_wgt() {
			$widget_ops = array( 'classname' => 'widget-author', 'description' => __('A widget that displays author profile', 'osum') );
			$control_ops = array( 'width' => 300, 'height' => 350, 'id_base' => 'author-widget' );
			$this->__construct( 'author-widget', __('Author Widget', 'osum'), $widget_ops, $control_ops );

	        add_action('admin_enqueue_scripts', array($this, 'upload_scripts'));
    	}

	    /**
	     * Upload the Javascripts for the media uploader
	     */
	    public function upload_scripts() {
			wp_enqueue_media();
	        //wp_enqueue_script('media-upload');
	        wp_enqueue_script('thickbox');
	        //wp_enqueue_script('upload_media_widget', get_template_directory_uri().'/inc/panel/js/media.js', array('jquery'));

	        wp_enqueue_style('thickbox');
	    }

		function widget( $args, $instance ){
			extract( $args );
			$title = apply_filters('widget_title', $instance['title'] );
			$image = '';
	        if(isset($instance['image'])) {
	            $image = $instance['image'];
	        }
			$description 	= $instance['description'];
			$gotopage 	= $instance['gotopage'];
			echo $before_widget;
			/*echo "<code><pre>";
			var_dump($instance);
			echo "</pre></code>";*/
			$img_id = attachment_url_to_postid($image);
			$medium_image = wp_get_attachment_image_src( $img_id, 'image-292x292');
			$medium_image_link = $medium_image[0];
 
			// Display the widget title 
			if ( $title )
				echo $before_title . $title . $after_title;
			echo '<article>
					<figure>
						<img src="'.$medium_image_link.'" alt="Author Image">
					</figure>
					<p>'.$description.'</p>
					<a class="readmore_btn" href="'.$gotopage.'">Read More</a>
				</article>';
				 
			//Display the name 
			 
			echo $after_widget;
		}
		function update( $new_instance, $old_instance ) {
			$instance = $old_instance;
		 
			//Strip tags from title and name to remove HTML
			$instance['title'] 	= strip_tags( $new_instance['title'] );
			$instance['img_id'] 	= strip_tags( $new_instance['img_id'] );
			$instance['image'] 	= strip_tags( $new_instance['image'] );
			$instance['description'] = strip_tags( $new_instance['description'] );
			$instance['gotopage'] = strip_tags( $new_instance['gotopage'] );

			$instance = $new_instance;

			return $instance;
		}
				/* Widget settings */
		function form( $instance ) {
			//Set up some default widget settings.
			$defaults = array( 'title' => '', 'image' => '','description' => '', 'gotopage' => '' );
			$instance = wp_parse_args( (array) $instance, $defaults );
			//var_dump($instance);
			$image = '';
	        if(isset($instance['image'])) {
	            $image = $instance['image'];
	        }
			?>
            <p>
				<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e('Title:', 'osum'); ?></label>
				<input id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" type="text" style="width:100%;" />
			</p>
			<p>
				<label for="<?php echo $this->get_field_name( 'image' ); ?>"><?php _e( 'Image:' ); ?></label><br>
				<img width="150" src="<?php echo $instance['image']; ?>" alt="<?php _e('Author Image:', 'osum'); ?>" id="wp_elearn_file_preview"><br>
	            <input name="<?php echo $this->get_field_name( 'image' ); ?>" id="<?php echo $this->get_field_id( 'image' ); ?>" class="meta_image_url widefat" type="text" size="36"  value="<?php echo esc_url( $image ); ?>" /><br>
	            <input class="upload_image_button button button-primary" type="button" value="Upload Image" />
	        </p>
 			<p>
				<label for="<?php echo $this->get_field_id( 'description' ); ?>"><?php _e('Description:', 'osum'); ?></label>
                <textarea id="<?php echo $this->get_field_id( 'description' ); ?>" name="<?php echo $this->get_field_name( 'description' ); ?>" style="width:100%;"  ><?php echo $instance['description']; ?></textarea>
			</p>
            <p>
				<label for="<?php echo $this->get_field_id( 'gotopage' ); ?>"><?php _e('Add Readmore Link:', 'osum'); ?></label>
				<input id="<?php echo $this->get_field_id( 'gotopage' ); ?>" name="<?php echo $this->get_field_name( 'gotopage' ); ?>" value="<?php echo $instance['gotopage']; ?>" type="text"style="width:100%;" />
			</p>
			<script language="JavaScript">
				jQuery(document).ready(function($) {
				    $(document).on("click", ".upload_image_button", function() {

						jQuery.data(document.body, 'prevElement', $(this).prev());
						
						var send_attachment_bkp = wp.media.editor.send.attachment;
						wp.media.editor.send.attachment = function(props, attachment) {
							jQuery('input.meta_image_url').val(attachment.url);

							jQuery('#wp_elearn_file_preview').attr('src',attachment.url);
							wp.media.editor.send.attachment = send_attachment_bkp;
						}
						wp.media.editor.open();

				        /* window.send_to_editor = function(html) {
				            var imgurl = jQuery('img',html).attr('src');
				            var inputText = jQuery.data(document.body, 'prevElement');

				            if(inputText != undefined && inputText != '') {
				                inputText.val(imgurl);
				            }
				            tb_remove();
				        };

				        tb_show('', 'media-upload.php?type=image&TB_iframe=true'); */
				        return false;
				    });
				});
			</script>
            <?php
		}
	}
?>