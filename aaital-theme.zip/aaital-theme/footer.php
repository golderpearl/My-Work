<?php
/**
 * The template for displaying the footer
 *
 */
global $theme_options;

$footerLogo = $theme_options['footer_logo']['url'];
$footer_text = $theme_options['footer_text'];
$facebook = $theme_options['facebook'];
$instagram = $theme_options['instagram'];
?>
	</main>
	<footer id="footer">
		<div class="container">
			<nav class="footer-menu">
				<?php
					if ( has_nav_menu( 'footer' ) ) {
						$args = array(
							'theme_location'  => 'footer',
							'menu'            => '',
							'container'       => false,
							'container_class' => '',
							'container_id'    => '',
							'menu_class'      => '',
							'menu_id'         => '',
							'echo'            => true,
							'fallback_cb'     => 'wp_page_menu',
							'before'          => '',
							'after'           => '',
							'link_before'     => '',
							'link_after'      => '',
							'items_wrap'      => '<a href="#" id="close-menu"><i class="lnr lnr-cross"></i></a><ul id="%1$s" class="%2$s">%3$s</ul>',
							'depth'           => 0,
							'walker'          => ''
						);
					}else{
						$args = array(
							'menu_class'  	  => '',
							'container'   	  => false,
							'container_class' => '',
							'echo'            => true,
							'fallback_cb'     => 'wp_page_menu',
							'before'          => '',
							'after'           => '',
							'link_before'     => '',
							'link_after'      => '',
							'items_wrap'      => '<a href="#" id="close-menu"><i class="lnr lnr-cross"></i></a><ul id="%1$s" class="%2$s">%3$s</ul>',
							'depth'           => 0,
							'walker'          => ''
						);
					}
					wp_nav_menu( $args );
				?>
			</nav>
			<div class="bottom-footer">
				<p><?php echo $footer_text; ?></p>
				<div class="footer-logo">
					<a href="<?php echo esc_url( home_url('/') ); ?>"><img src="<?php echo $footerLogo; ?>" alt="" /></a>
				</div>
				<div class="social-area">
					<ul>
						<li><a href="<?php echo $facebook; ?>"><img src="<?php echo get_template_directory_uri(); ?>/images/facebook-icon.png" alt="" /></a></li>
						<li><a href="<?php echo $instagram; ?>"><img src="<?php echo get_template_directory_uri(); ?>/images/instagram-icon.png" alt="" /></a></li>
					</ul>
				</div>
			</div>
		</div>
	</footer>
</div>
<?php wp_footer(); ?>
</body>
</html>