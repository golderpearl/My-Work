<?php
/**
 * The template for displaying archive pages
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 */

get_header();
global $post;

instagram();
?>
<?php if ( have_posts() ) : ?>
	<div class="category-sec">
		<div class="container">
			<div class="category-articles">
				<?php while ( have_posts() ) : the_post();
					$post_type = get_field('post_type');
					$gallery = get_field('gallery');
					$video_url = get_field('video_url'); ?>
					<article class="article">
						<figure class="fashion-post-thumbnail">
							<?php echo get_the_post_thumbnail( $post->ID, 'image-770x514' ); ?>
							<figcaption>
								<?php
									if ($post_type == 'Gallery') {
										echo '<i class="fa fa-slideshare"></i>';

									} elseif ($post_type == 'Video') {
										echo '<i class="fa fa-file-video-o"></i>';

									} elseif ($post_type == 'Image') {
										echo '<i class="fa fa-file-image-o"></i>';
									}
								?>
							</figcaption>
						</figure>
						<div class="description">
							<?php
								$categories = get_the_category();
								if ( ! empty( $categories ) ) {
									echo '<a class="cat" href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '">
										' . esc_html( $categories[0]->name ) . '
									</a>';
								}
							?>
							<h2>
								<a href="<?php echo get_the_permalink(); ?>">
									<?php echo get_the_title(); ?>
								</a>
							</h2>
							<span class="date"><?php echo get_the_date( 'F j, Y' ); ?></span>
							<p><?php echo substr( get_the_content(), 0, 133 ); ?></p>
							<a href="<?php echo get_the_permalink(); ?>" class="read-story">Read Story</a>
						</div>
					</article>
				<?php endwhile; ?>
			</div>
			<sidebar class="sidebar category">
				<?php dynamic_sidebar( 'sidebar' ); ?>
			</sidebar>
		</div>
	</div>
<?php endif;
get_footer();
