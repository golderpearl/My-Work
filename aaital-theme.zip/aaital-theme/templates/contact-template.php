<?php
/* 
    Template Name: Contact Us
*/
get_header();

global $theme_options;

$instagram = $theme_options['instagram'];

// Page Fields
$inner_page_instagram_shortcode = get_field('inner_page_instagram_shortcode');
$contact_page_title = get_field('contact_page_title');
$contact_promotional_text = get_field('contact_promotional_text');
$contact_text = get_field('contact_text');
$form_title = get_field('form_title');
$contact_left_fields = get_field('contact_left_fields');
$download_button_link = get_field('download_button_link');
$form_shortcode = get_field('form_shortcode');
$instagram_shortcode = get_field('instagram_shortcode');

instagram();
?>
<div class="contact-sec">
    <div class="container">
        <h2 class="contact-title"><?php echo $contact_page_title; ?></h2>
        <div class="description">
            <strong class="promotion-title"><?php echo $contact_promotional_text; ?></strong>
            <p><?php echo $contact_text; ?></p>
        </div>
        <div class="contact-image">
            <?php echo get_the_post_thumbnail( $post->ID, 'image-1110x600' ); ?>
        </div>
    </div>
</div>
<div class="contact-sec">
    <div class="container">
        <h2 class="contact-title add"><?php echo $form_title; ?></h2>
        <sidebar class="sidebar contact">
            <ul>
                <?php
                if( have_rows('contact_left_fields') ) { 
                    while( have_rows('contact_left_fields') ): the_row();
                        $left_column_text = get_sub_field('left_column_text');
                        ?>
                        <li><?php echo $left_column_text; ?></li>
                    <?php endwhile;
                } ?>
            </ul>
            <a href="<?php echo $download_button_link; ?>" class="btn media-kit">Download my Media Kit</a>
        </sidebar>
        <?php echo do_shortcode( $form_shortcode ); ?>
    </div>
</div>
<div class="instagram-sec">
    <div class="container">
        <?php echo do_shortcode( $instagram_shortcode ); ?>
    </div>
</div>
<?php get_footer();