<?php
/* 
    Template Name: Home
*/
get_header();

global $theme_options;

$instagram = $theme_options['instagram'];

// Page Fields
$images = get_field('homepage_slider');
$slider_text = get_field('slider_text');
$button_text = get_field('button_text');
$button_url = get_field('button_url');
$instagram_shortcode = get_field('instagram_shortcode');
$select_blog_category = get_field('select_blog_category');

var_dump($images);
?>
<div class="banner-sec">
    <?php
    $size = 'image-1110x600';
    if( $images ): ?>
        <div class="container">
            <div id="owl-demo" class="owl-carousel">
                <?php foreach( $images as $image ): ?>
                    <div class="item">
                        <?php echo wp_get_attachment_image( $image['ID'], $size ); ?>
                        <div class="holder">
                            <div class="holder-1">
                                <div class="holder-2">
                                    <h1><?php echo $slider_text; ?></h1>
                                    <a href="<?php echo $button_url; ?>" class="btn read-story"><?php echo $button_text; ?></a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    <?php endif; ?>
    <div class="instagram-sec">
        <div class="container">
            <div class="head-area">
                <h2>@aaital</h2>
                <strong>Follow Me & Share Your Love</strong>
                <a href="<?php echo $instagram; ?>" class="btn-follow">Follow</a>
            </div>
            <ul>
                <li><a href="#"><img src="images/insta-photo.jpg" alt="" /></a></li>
                <li><a href="#"><img src="images/insta-photo.jpg" alt="" /></a></li>
                <li><a href="#"><img src="images/insta-photo.jpg" alt="" /></a></li>
                <li><a href="#"><img src="images/insta-photo.jpg" alt="" /></a></li>
                <li><a href="#"><img src="images/insta-photo.jpg" alt="" /></a></li>
                <li><a href="#"><img src="images/insta-photo.jpg" alt="" /></a></li>
                <li><a href="#"><img src="images/insta-photo.jpg" alt="" /></a></li>
                <li><a href="#"><img src="images/insta-photo.jpg" alt="" /></a></li>
            </ul>
        </div>
    </div>
<div class="articles-sec">
    <div class="container">
        <article class="article">
            <figure>
                <img src="images/article-img.jpg" alt="">
            </figure>
            <div class="description">
                <a href="#" class="cat">Fashion</a>
                <h2>Oh Christmas Tree – Holiday Family Traditions Before Christmas</h2>
                <span class="date">February 8, 2019</span>
                <p>All white glamour ! On the behest of my own fear of wearing white I pushed myself beyond my comfort clothing and wore white one day. </p>
                <a href="#" class="read-story">Read Story</a>
            </div>
        </article>
    </div>
</div>
<?php get_footer();