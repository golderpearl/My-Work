<?php
/* 
    Template Name: About Us
*/
get_header();

global $theme_options;

$instagram = $theme_options['instagram'];

// Page Fields
$inner_page_instagram_shortcode = get_field('inner_page_instagram_shortcode');
$about_title = get_field('about_title');
$about_secondary_title = get_field('about_secondary_title');
$about_text = get_field('about_text');
$about_promotional_text = get_field('about_promotional_text');
$button_text = get_field('button_text');
$button_link = get_field('button_link');
$instagram_shortcode = get_field('instagram_shortcode');

instagram();
?>
<div class="about-sec">
    <div class="container">
        <h2 class="about-title"><?php echo $about_title; ?></h2>
        <div class="about-image">
            <?php echo get_the_post_thumbnail( $post->ID, 'image-1110x600' ); ?>
        </div>
        <div class="description">
            <h3><?php echo $about_secondary_title; ?></h3>
            <p><?php echo $about_text; ?></p>
            <strong class="promotion-title"><?php echo $about_promotional_text; ?></strong>
            <a href="<?php echo $button_link; ?>" class="btn-hire"><?php echo $button_text; ?></a>
        </div>
    </div>
</div>
<div class="instagram-sec">
    <div class="container">
        <?php echo do_shortcode( $instagram_shortcode ); ?>
    </div>
</div>
<?php get_footer();