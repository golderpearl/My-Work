
jQuery(document).ready(function($) {
   $("#owl-demo").owlCarousel({
     navigation : true,
     slideSpeed : 300,
     paginationSpeed : 400,
     autoPlay : true,
     slideSpeed: 2000,
     singleItem : true,
   });
 });
